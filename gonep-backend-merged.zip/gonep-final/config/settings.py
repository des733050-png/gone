"""
Django settings for Gonep backend.
Django 4.2.7 (requirements.txt) — do NOT upgrade without full test run.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _split_env_list(name, default=""):
    raw = os.getenv(name, default)
    return [item.strip() for item in raw.split(",") if item.strip()]


# ── Security ──────────────────────────────────────────────────────────────────
SECRET_KEY = os.getenv(
    "DJANGO_SECRET_KEY",
    "django-insecure-x3__fb505knw7r+uj_mr1^1n!m#1)=*v0zbkgpwj7c2@ye#2n=",
)

# Default False — only set DJANGO_DEBUG=True in local .env
DEBUG = os.getenv("DJANGO_DEBUG", "False").lower() in {"1", "true", "yes", "on"}

ALLOWED_HOSTS = _split_env_list(
    "DJANGO_ALLOWED_HOSTS",
    "127.0.0.1,localhost,vsifdd.pythonanywhere.com,.vercel.app",
)

CSRF_TRUSTED_ORIGINS = _split_env_list(
    "DJANGO_CSRF_TRUSTED_ORIGINS",
    (
        "http://127.0.0.1,http://localhost,"
        "http://127.0.0.1:8081,http://localhost:8081,"
        "http://127.0.0.1:8082,http://localhost:8082,"
        "http://127.0.0.1:8083,http://localhost:8083,"
        "https://vsifdd.pythonanywhere.com,"
        "https://*.vercel.app"
    ),
)

CORS_ALLOWED_ORIGINS = _split_env_list(
    "DJANGO_CORS_ALLOWED_ORIGINS",
    (
        "http://127.0.0.1:8081,http://localhost:8081,"
        "http://127.0.0.1:8082,http://localhost:8082,"
        "http://127.0.0.1:8083,http://localhost:8083,"
        "https://patient-rosy.vercel.app,"
        "https://gone-gules.vercel.app"
    ),
)

CORS_ALLOW_CREDENTIALS = True

# ── Applications ──────────────────────────────────────────────────────────────
INSTALLED_APPS = [
    "jazzmin",
    "corsheaders",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "rest_framework.authtoken",
    "core",
    "portal_api",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

if DEBUG and os.getenv("DJANGO_FAST_LOGIN", "1").lower() in {"1", "true", "yes", "on"}:
    PASSWORD_HASHERS = [
        "django.contrib.auth.hashers.MD5PasswordHasher",
        "django.contrib.auth.hashers.PBKDF2PasswordHasher",
    ]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

# Django 4.2+ API — replaces deprecated STATICFILES_STORAGE string
STORAGES = {
    "default": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
    },
    "staticfiles": {
        "BACKEND": (
            "django.contrib.staticfiles.storage.StaticFilesStorage"
            if DEBUG
            else "whitenoise.storage.CompressedStaticFilesStorage"
        ),
    },
}

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "rest_framework.authentication.TokenAuthentication",
        "rest_framework.authentication.SessionAuthentication",
    ),
    "DEFAULT_PERMISSION_CLASSES": (
        "rest_framework.permissions.IsAuthenticated",
    ),
}

JAZZMIN_SETTINGS = {
    "site_title": "GONEP Command Centre",
    "site_header": "GONEP Command Centre",
    "site_brand": "GONEP Command Centre",
    "welcome_sign": "Internal operations, data stewardship, and system control",
    "site_logo": "core/branding/favicon.svg",
    "login_logo": "core/branding/favicon.svg",
    "login_logo_dark": "core/branding/favicon.svg",
    "site_logo_classes": "elevation-0",
    "site_icon": "core/branding/favicon.svg",
    "search_model": "auth.User",
    "show_sidebar": True,
    "navigation_expanded": True,
    "hide_apps": ["portal_api"],
    "topmenu_links": [
        {"name": "Dashboard", "url": "admin:index"},
        {"name": "Access & Identity", "url": "admin:auth_user_changelist"},
        {"name": "Patients", "url": "admin:core_patientprofile_changelist"},
        {"name": "Providers", "url": "admin:core_providerprofile_changelist"},
        {"name": "Riders & Deliveries", "url": "admin:core_riderprofile_changelist"},
        {"name": "Orders & Fulfillment", "url": "admin:core_patientmedicationorder_changelist"},
        {"name": "Billing & Finance", "url": "admin:core_revenueentry_changelist"},
    ],
    "order_with_respect_to": [
        "auth", "auth.user", "auth.group", "core.facility",
        "core.patientuserlink", "core.providermembership", "core.rideruserlink",
        "core.patientprofile", "core.patientpreference", "core.patientbooking",
        "core.patientconsultation", "core.patientprescription",
        "core.patientdiagnosticorder", "core.patientmedicationorder",
        "core.patientmedicationorderitem", "core.patientrecordevent",
        "core.patientportalnotification", "core.patientsupportticket",
        "core.providerprofile", "core.providerverificationsubmission",
        "core.providerverificationdocument",
        "core.providerappointment", "core.providerconsultation",
        "core.providerprescriptiontask", "core.providerlabresult",
        "core.provideravailability", "core.providerclinicalsetting",
        "core.providerinventoryitem", "core.providerbillingrecord",
        "core.providerportalnotification", "core.providersupportticket",
        "core.provideractivitylog", "core.providerpostransaction",
        "core.providerearningssnapshot", "core.providerprotocol",
        "core.riderprofile", "core.riderjob", "core.riderrequestdecision",
        "core.riderportalnotification", "core.riderchatmessage",
        "core.riderpreference", "core.riderhistoryentry", "core.riderearningssnapshot",
        "core.commandbooking", "core.commandprovider", "core.commandrider",
        "core.commandincident", "core.performanceflag",
        "core.stockitem", "core.inventorybatch", "core.supplier", "core.salerecord",
        "core.revenueentry", "core.payoutrequest", "core.invoice",
        "core.transactionlog", "core.executivekpi",
        "core.complianceaudit", "core.complaint", "core.riskflag",
        "core.auditevent", "core.timelineevent", "core.attachment",
        "core.note", "core.actionqueueitem", "core.tag",
    ],
    "icons": {
        "auth": "fas fa-users-cog", "auth.user": "fas fa-user", "auth.group": "fas fa-user-tag",
        "core": "fas fa-sitemap", "core.facility": "fas fa-hospital",
        "core.patientuserlink": "fas fa-link", "core.providermembership": "fas fa-id-badge",
        "core.rideruserlink": "fas fa-link", "core.patientprofile": "fas fa-user-injured",
        "core.patientpreference": "fas fa-sliders-h", "core.patientbooking": "fas fa-calendar-check",
        "core.patientconsultation": "fas fa-stethoscope",
        "core.patientprescription": "fas fa-prescription-bottle-alt",
        "core.patientdiagnosticorder": "fas fa-vials", "core.patientmedicationorder": "fas fa-box-open",
        "core.patientmedicationorderitem": "fas fa-capsules",
        "core.patientrecordevent": "fas fa-file-medical-alt",
        "core.patientportalnotification": "fas fa-bell", "core.patientsupportticket": "fas fa-life-ring",
        "core.providerprofile": "fas fa-user-md",
        "core.providerverificationsubmission": "fas fa-shield-alt",
        "core.providerverificationdocument": "fas fa-file-contract",
        "core.providerappointment": "fas fa-calendar-plus",
        "core.providerconsultation": "fas fa-notes-medical",
        "core.providerprescriptiontask": "fas fa-prescription-bottle-alt",
        "core.providerlabresult": "fas fa-flask", "core.provideravailability": "fas fa-clock",
        "core.providerclinicalsetting": "fas fa-cogs", "core.providerinventoryitem": "fas fa-pills",
        "core.providerbillingrecord": "fas fa-file-invoice-dollar",
        "core.providerportalnotification": "fas fa-bell", "core.providersupportticket": "fas fa-headset",
        "core.provideractivitylog": "fas fa-history", "core.providerpostransaction": "fas fa-cash-register",
        "core.providerearningssnapshot": "fas fa-chart-line", "core.providerprotocol": "fas fa-clipboard-list",
        "core.riderprofile": "fas fa-motorcycle", "core.riderjob": "fas fa-route",
        "core.riderrequestdecision": "fas fa-check-circle", "core.riderportalnotification": "fas fa-bell",
        "core.riderchatmessage": "fas fa-comments", "core.riderpreference": "fas fa-sliders-h",
        "core.riderhistoryentry": "fas fa-history", "core.riderearningssnapshot": "fas fa-wallet",
        "core.commandprovider": "fas fa-briefcase-medical", "core.commandrider": "fas fa-motorcycle",
        "core.commandbooking": "fas fa-calendar-alt", "core.commandincident": "fas fa-exclamation-triangle",
        "core.performanceflag": "fas fa-tachometer-alt", "core.complianceaudit": "fas fa-clipboard-check",
        "core.complaint": "fas fa-comment-dots", "core.riskflag": "fas fa-flag",
        "core.supplier": "fas fa-truck-loading", "core.stockitem": "fas fa-boxes",
        "core.inventorybatch": "fas fa-barcode", "core.salerecord": "fas fa-shopping-cart",
        "core.revenueentry": "fas fa-wallet", "core.payoutrequest": "fas fa-money-check-alt",
        "core.invoice": "fas fa-file-invoice", "core.transactionlog": "fas fa-receipt",
        "core.executivekpi": "fas fa-chart-bar", "core.auditevent": "fas fa-shield-alt",
        "core.timelineevent": "fas fa-stream", "core.attachment": "fas fa-paperclip",
        "core.note": "fas fa-sticky-note", "core.actionqueueitem": "fas fa-tasks", "core.tag": "fas fa-tag",
    },
    "default_icon_parents": "fas fa-folder",
    "default_icon_children": "fas fa-circle",
}

JAZZMIN_UI_TWEAKS = {
    "navbar": "navbar-white navbar-light",
    "sidebar": "sidebar-light-primary",
    "theme": "flatly",
    "dark_mode_theme": None,
    "navbar_fixed": True,
    "sidebar_fixed": True,
}

# ── Gonep env vars ────────────────────────────────────────────────────────────
GONEP_PORTAL_LOGIN_URL = os.getenv("GONEP_PORTAL_LOGIN_URL", "")
GONEP_PATIENT_LOGIN_URL = os.getenv("GONEP_PATIENT_LOGIN_URL", "")
DAILY_API_KEY = os.getenv("DAILY_API_KEY", "")

# ── Production security ───────────────────────────────────────────────────────
if not DEBUG:
    CSRF_COOKIE_SECURE = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SAMESITE = "Lax"
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
