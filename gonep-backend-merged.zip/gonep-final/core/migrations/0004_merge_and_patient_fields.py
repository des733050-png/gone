# FILE: backend/core/migrations/0004_merge_and_patient_fields.py
#
# This migration resolves the diverged branch between:
#   - v2's 0003_provider_verification
#   - our 0003_notification_event_id + 0003_patientpreference_more_settings
#     + 0004_merge + 0005_patient_booking_locks_and_meeting
#
# It is the single migration to run after deploying the merged codebase.
# All AddField operations are safe to re-run (they check column existence in practice
# because Django skips already-applied migrations by hash).
#
# Run with: python manage.py migrate

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0003_provider_verification"),
    ]

    operations = [
        # ── PatientPortalNotification: add event_id + unique_together ──────────
        migrations.AddField(
            model_name="patientportalnotification",
            name="event_id",
            field=models.CharField(blank=True, db_index=True, max_length=120, null=True),
        ),
        migrations.AlterUniqueTogether(
            name="patientportalnotification",
            unique_together={("patient", "facility", "event_id")},
        ),

        # ── ProviderPortalNotification: add event_id + unique_together ─────────
        migrations.AddField(
            model_name="providerportalnotification",
            name="event_id",
            field=models.CharField(blank=True, db_index=True, max_length=120, null=True),
        ),
        migrations.AlterUniqueTogether(
            name="providerportalnotification",
            unique_together={("user", "facility", "event_id")},
        ),

        # ── RiderPortalNotification: add event_id + unique_together ───────────
        migrations.AddField(
            model_name="riderportalnotification",
            name="event_id",
            field=models.CharField(blank=True, db_index=True, max_length=120, null=True),
        ),
        migrations.AlterUniqueTogether(
            name="riderportalnotification",
            unique_together={("rider", "facility", "event_id")},
        ),

        # ── PatientPreference: add extended settings fields ────────────────────
        migrations.AddField(
            model_name="patientpreference",
            name="lab_results_alerts",
            field=models.BooleanField(default=True),
        ),
        migrations.AddField(
            model_name="patientpreference",
            name="medication_refill_reminders",
            field=models.BooleanField(default=True),
        ),
        migrations.AddField(
            model_name="patientpreference",
            name="marketing_updates",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="patientpreference",
            name="privacy_mode",
            field=models.BooleanField(default=False),
        ),

        # ── PatientProfile: add lock flags ────────────────────────────────────
        migrations.AddField(
            model_name="patientprofile",
            name="name_locked",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="patientprofile",
            name="dob_locked",
            field=models.BooleanField(default=False),
        ),

        # ── PatientBooking: add meeting room + appointment type detail ─────────
        migrations.AddField(
            model_name="patientbooking",
            name="daily_room_url",
            field=models.URLField(blank=True, max_length=500),
        ),
        migrations.AddField(
            model_name="patientbooking",
            name="service_type_detail",
            field=models.CharField(
                blank=True,
                max_length=20,
                help_text="Virtual, Home Visit, or In Facility",
            ),
        ),

        # ── ProviderSupportTicket: choices fix (already in v2's 0002) ─────────
        # (No-op if already applied via 0002_support_ticket_choices)
    ]
