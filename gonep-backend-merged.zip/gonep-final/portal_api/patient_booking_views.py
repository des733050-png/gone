"""
portal_api/patient_booking_views.py
Patient-facing booking discovery and appointment creation endpoints.

Endpoints (all prefixed /api/v1/):
  GET  patient/specialties/                     — list specialties available in facility
  GET  patient/doctors/?specialty=X             — list doctors for a specialty
  GET  patient/doctors/<provider_code>/slots/   — get available time slots
  POST patient/appointments/create/             — create a new booking
  GET  patient/appointments/<ref>/meeting-room/ — get Daily.co meeting room URL
"""
from datetime import datetime, timedelta

from django.conf import settings
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import NotFound, ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from core.models import (
    Facility,
    PatientBooking,
    PatientPortalNotification,
    ProviderAvailability,
    ProviderMembership,
    ProviderPortalNotification,
    ProviderProfile,
    ProviderSubRole,
    WorkflowStatus,
)
from portal_api.patient_views import get_active_patient_context_or_raise
from portal_api.utils import (
    build_patient_appointment_payload,
    format_currency,
    format_uuid,
)

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
SLOT_HORIZON_WEEKS = 8


def _next_booking_ref():
    counter = PatientBooking.objects.count() + 1
    while True:
        candidate = f"BKG-{counter:04d}"
        if not PatientBooking.objects.filter(booking_ref=candidate).exists():
            return candidate
        counter += 1


def _next_notification_code():
    counter = PatientPortalNotification.objects.count() + 1
    while True:
        candidate = f"pn-{counter:04d}"
        if not PatientPortalNotification.objects.filter(notification_code=candidate).exists():
            return candidate
        counter += 1


def _next_provider_notification_code():
    counter = ProviderPortalNotification.objects.count() + 1
    while True:
        candidate = f"pvn-{counter:04d}"
        if not ProviderPortalNotification.objects.filter(notification_code=candidate).exists():
            return candidate
        counter += 1


def _expand_slots(availability, weeks=SLOT_HORIZON_WEEKS):
    """Convert ProviderAvailability.slots day-names into concrete future datetimes."""
    today = timezone.localdate()
    results = []
    for slot in (availability.slots or []):
        day_name = slot.get("day", "")
        start_time = slot.get("start", "")
        slot_type = slot.get("type", "In Facility")
        slot_id = slot.get("id", "")
        if not day_name or not start_time:
            continue
        try:
            day_index = DAYS.index(day_name)
        except ValueError:
            continue
        try:
            hour, minute = [int(x) for x in start_time.split(":")[:2]]
        except (ValueError, AttributeError):
            continue
        # Walk forward SLOT_HORIZON_WEEKS weeks finding matching day-of-week
        current = today
        weeks_found = 0
        while weeks_found < weeks:
            if current.weekday() == day_index and current > today:
                dt = timezone.make_aware(
                    datetime(current.year, current.month, current.day, hour, minute)
                )
                results.append({
                    "slot_id": slot_id,
                    "day": day_name,
                    "datetime": dt.isoformat(),
                    "time": dt.strftime("%I:%M %p").lstrip("0"),
                    "date_label": dt.strftime("%a, %b %-d"),
                    "type": slot_type,
                })
                weeks_found += 1
            current += timedelta(days=1)
    results.sort(key=lambda s: s["datetime"])
    return results


def _fan_out_provider_notification(facility, patient, booking):
    """Notify all doctors + facility admins + superusers about a new booking."""
    from django.contrib.auth import get_user_model
    User = get_user_model()

    memberships = ProviderMembership.objects.select_related("user", "facility").filter(
        facility=facility,
        is_active=True,
        role__in=[ProviderSubRole.DOCTOR, ProviderSubRole.FACILITY_ADMIN],
    )
    notified_user_ids = set()
    for membership in memberships:
        if membership.user_id in notified_user_ids:
            continue
        notified_user_ids.add(membership.user_id)
        ProviderPortalNotification.objects.create(
            notification_code=_next_provider_notification_code(),
            user=membership.user,
            facility=facility,
            title="New appointment booked",
            message=f"{patient.full_name} booked {booking.booking_ref} — {booking.service_type or 'Consultation'}.",
            icon_lib="feather",
            icon_name="calendar",
            color="primary",
        )

    for superuser in User.objects.filter(is_superuser=True, is_active=True):
        if superuser.pk in notified_user_ids:
            continue
        ProviderPortalNotification.objects.create(
            notification_code=_next_provider_notification_code(),
            user=superuser,
            facility=facility,
            title="New appointment booked",
            message=f"{patient.full_name} booked {booking.booking_ref}.",
            icon_lib="feather",
            icon_name="calendar",
            color="primary",
        )


def _notify_patient(patient, facility, booking, event_id=None):
    event_id = event_id or f"booking-created-{booking.booking_ref}"
    PatientPortalNotification.objects.update_or_create(
        patient=patient,
        facility=facility,
        event_id=event_id,
        defaults={
            "notification_code": _next_notification_code(),
            "kind": "appointment",
            "title": "Appointment confirmed",
            "body": f"Your appointment {booking.booking_ref} has been scheduled.",
            "icon_lib": "feather",
            "icon_name": "calendar-check",
            "read": False,
        },
    )


def _create_daily_room(booking_ref):
    """Create a Daily.co meeting room. Returns URL stub if API key not configured."""
    daily_api_key = getattr(settings, "DAILY_API_KEY", "")
    if not daily_api_key:
        return f"https://gonep.daily.co/{booking_ref}"
    try:
        import urllib.request, json as _json
        payload = _json.dumps({"name": booking_ref, "privacy": "private"}).encode()
        req = urllib.request.Request(
            "https://api.daily.co/v1/rooms",
            data=payload,
            headers={"Authorization": f"Bearer {daily_api_key}", "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = _json.loads(resp.read())
            return data.get("url", f"https://gonep.daily.co/{booking_ref}")
    except Exception:
        return f"https://gonep.daily.co/{booking_ref}"


class PatientSpecialtiesView(APIView):
    """GET /api/v1/patient/specialties/ — list specialties served by the active facility."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        specialties = list(
            ProviderProfile.objects.filter(
                facility=facility,
                memberships__is_active=True,
                memberships__role=ProviderSubRole.DOCTOR,
            )
            .values_list("specialty", flat=True)
            .distinct()
            .order_by("specialty")
        )
        specialties = [s for s in specialties if s]
        return Response(specialties)


class PatientDoctorsView(APIView):
    """GET /api/v1/patient/doctors/?specialty=X — list doctors for a specialty."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        specialty = str(request.query_params.get("specialty") or "").strip()

        qs = ProviderProfile.objects.filter(
            facility=facility,
            memberships__is_active=True,
            memberships__role=ProviderSubRole.DOCTOR,
            status=WorkflowStatus.CONFIRMED,
        ).distinct()

        if specialty:
            qs = qs.filter(specialty__iexact=specialty)

        return Response([
            {
                "provider_code": p.provider_code,
                "full_name": p.full_name,
                "specialty": p.specialty or "General Care",
                "license": p.license_number,
                "experience_years": p.years_experience,
                "bio": p.bio,
            }
            for p in qs.order_by("full_name")
        ])


class PatientDoctorSlotsView(APIView):
    """GET /api/v1/patient/doctors/<provider_code>/slots/?type=X — available slots."""
    permission_classes = [IsAuthenticated]

    def get(self, request, provider_code):
        link, facility, _ = get_active_patient_context_or_raise(request)
        slot_type = str(request.query_params.get("type") or "").strip()

        provider = ProviderProfile.objects.filter(
            provider_code=provider_code, facility=facility
        ).first()
        if provider is None:
            raise NotFound("Doctor not found.")

        availability = ProviderAvailability.objects.filter(
            provider=provider, facility=facility
        ).first()

        slots = _expand_slots(availability) if availability else []
        if slot_type:
            slots = [s for s in slots if s.get("type", "").lower() == slot_type.lower()]

        return Response({
            "provider_code": provider.provider_code,
            "full_name": provider.full_name,
            "slots": slots,
        })


class PatientBookingCreateView(APIView):
    """POST /api/v1/patient/appointments/create/ — create a new booking."""
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        data = request.data or {}
        patient = link.patient

        provider_code = str(data.get("provider_code") or "").strip()
        slot_datetime_str = str(data.get("slot_datetime") or "").strip()
        service_type = str(data.get("service_type") or "Consultation").strip()
        service_type_detail = str(data.get("service_type_detail") or "In Facility").strip()
        notes = str(data.get("notes") or "").strip()

        if not slot_datetime_str:
            raise ValidationError({"slot_datetime": "slot_datetime is required (ISO format)."})

        from django.utils.dateparse import parse_datetime
        scheduled_for = parse_datetime(slot_datetime_str)
        if scheduled_for is None:
            raise ValidationError({"slot_datetime": "Use ISO datetime format e.g. 2026-05-10T09:00:00."})
        if timezone.is_naive(scheduled_for):
            scheduled_for = timezone.make_aware(scheduled_for)

        if scheduled_for < timezone.now() + timedelta(hours=1):
            raise ValidationError({"slot_datetime": "Appointment must be at least 1 hour in the future."})

        # Double-booking check — patient
        patient_clash = PatientBooking.objects.filter(
            patient=patient,
            facility=facility,
            status__in=[WorkflowStatus.CONFIRMED, WorkflowStatus.DRAFT],
            scheduled_for__range=(scheduled_for - timedelta(hours=1), scheduled_for + timedelta(hours=1)),
        ).exists()
        if patient_clash:
            raise ValidationError({"slot_datetime": "You already have an appointment within 1 hour of this slot."})

        provider = None
        provider_name = ""
        provider_specialty = ""
        doctor_membership = None

        if provider_code:
            provider = ProviderProfile.objects.filter(provider_code=provider_code, facility=facility).first()
            if provider is None:
                raise NotFound("Doctor not found.")
            provider_name = provider.full_name
            provider_specialty = provider.specialty or "General Care"
            doctor_membership = ProviderMembership.objects.filter(
                provider=provider, facility=facility, role=ProviderSubRole.DOCTOR, is_active=True
            ).first()

            # Double-booking check — doctor
            if doctor_membership:
                doctor_clash = PatientBooking.objects.filter(
                    provider_name=provider.full_name,
                    facility=facility,
                    status__in=[WorkflowStatus.CONFIRMED, WorkflowStatus.DRAFT],
                    scheduled_for__range=(scheduled_for - timedelta(hours=1), scheduled_for + timedelta(hours=1)),
                ).exists()
                if doctor_clash:
                    raise ValidationError({"slot_datetime": "This doctor is not available at the selected time."})

        booking_ref = _next_booking_ref()
        booking = PatientBooking.objects.create(
            booking_ref=booking_ref,
            patient=patient,
            facility=facility,
            status=WorkflowStatus.CONFIRMED,
            service_type=service_type,
            service_type_detail=service_type_detail,
            provider_name=provider_name,
            provider_specialty=provider_specialty,
            scheduled_for=scheduled_for,
            notes=notes,
            fee_amount=0,
        )

        # Patient notification
        _notify_patient(patient, facility, booking)

        # Provider + admin notifications
        _fan_out_provider_notification(facility, patient, booking)

        consultation = booking.consultations.order_by("-consulted_at").first()
        return Response(build_patient_appointment_payload(booking, consultation), status=201)


class PatientMeetingRoomView(APIView):
    """GET /api/v1/patient/appointments/<ref>/meeting-room/ — get video room URL."""
    permission_classes = [IsAuthenticated]

    def get(self, request, booking_ref):
        link, facility, _ = get_active_patient_context_or_raise(request)
        try:
            booking = link.patient.bookings.filter(facility=facility).get(booking_ref=booking_ref)
        except PatientBooking.DoesNotExist:
            raise NotFound("Appointment not found.")

        if booking.status not in {WorkflowStatus.CONFIRMED, WorkflowStatus.IN_PROGRESS}:
            raise ValidationError({"detail": "Meeting room is only available for confirmed or in-progress appointments."})

        room_url = getattr(booking, "daily_room_url", "") or ""
        if not room_url:
            room_url = _create_daily_room(booking.booking_ref)
            if hasattr(booking, "daily_room_url"):
                booking.daily_room_url = room_url
                booking.save(update_fields=["daily_room_url", "updated_at"])

        return Response({
            "booking_ref": booking.booking_ref,
            "room_url": room_url,
            "token": None,  # populated when Daily.co token generation is wired
        })
