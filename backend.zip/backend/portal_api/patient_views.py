from django.db import transaction
from django.db.models import Prefetch
from django.utils import timezone
from rest_framework.exceptions import NotFound, PermissionDenied, ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from core.models import (
    PatientBooking,
    PatientConsultation,
    PatientDiagnosticOrder,
    PatientMedicationOrder,
    PatientMedicationOrderItem,
    PatientPortalNotification,
    PatientPortalOrderStatus,
    PatientPreference,
    PatientPrescription,
    PatientProfile,
)
from portal_api.utils import (
    PATIENT_FACILITY_SESSION_KEY,
    build_patient_appointment_payload,
    build_patient_notification_payload,
    build_patient_order_payload,
    build_patient_payload,
    build_patient_record_payload,
    get_patient_active_facility,
    get_patient_link,
    parse_patient_booking_status,
)


def get_active_patient_context_or_raise(request):
    link = get_patient_link(request.user)
    if link is None:
        raise NotFound("Patient profile link not found.")
    facility, access_rows = get_patient_active_facility(
        link,
        request.session.get(PATIENT_FACILITY_SESSION_KEY),
    )
    if facility is None:
        raise PermissionDenied("No facility context is available for this patient.")
    return link, facility, access_rows


def _lookup_by_id_or_code(queryset, identifier, code_field, not_found_message):
    try:
        return queryset.get(pk=identifier)
    except Exception:
        try:
            return queryset.get(**{code_field: identifier})
        except queryset.model.DoesNotExist as exc:
            raise NotFound(not_found_message) from exc


def get_patient_booking_or_raise(patient, facility, booking_ref):
    return _lookup_by_id_or_code(
        patient.bookings.filter(facility=facility),
        booking_ref,
        "booking_ref",
        "Appointment not found.",
    )


def get_patient_order_or_raise(patient, facility, order_number):
    return _lookup_by_id_or_code(
        patient.medication_orders.select_related("rider").prefetch_related("items").filter(
            facility=facility
        ),
        order_number,
        "order_number",
        "Order not found.",
    )


def resolve_record_provider_labels(events):
    consultation_refs = [
        event.source_identifier
        for event in events
        if event.source_model == "PatientConsultation"
    ]
    prescription_refs = [
        event.source_identifier
        for event in events
        if event.source_model == "PatientPrescription"
    ]
    diagnostic_refs = [
        event.source_identifier
        for event in events
        if event.source_model == "PatientDiagnosticOrder"
    ]

    consultations = {
        item.consultation_ref: item
        for item in PatientConsultation.objects.filter(
            consultation_ref__in=consultation_refs
        )
    }
    prescriptions = {
        item.rx_number: item
        for item in PatientPrescription.objects.select_related("consultation").filter(
            rx_number__in=prescription_refs
        )
    }
    diagnostics = {
        item.order_number: item
        for item in PatientDiagnosticOrder.objects.select_related("consultation").filter(
            order_number__in=diagnostic_refs
        )
    }

    labels = {}
    for event in events:
        provider_label = "Care Team"
        if event.source_model == "PatientConsultation":
            provider_label = (
                consultations.get(event.source_identifier).provider_name
                if consultations.get(event.source_identifier)
                and consultations.get(event.source_identifier).provider_name
                else "Care Team"
            )
        elif event.source_model == "PatientPrescription":
            prescription = prescriptions.get(event.source_identifier)
            provider_label = (
                prescription.consultation.provider_name
                if prescription
                and prescription.consultation
                and prescription.consultation.provider_name
                else "Pharmacy Team"
            )
        elif event.source_model == "PatientDiagnosticOrder":
            diagnostic = diagnostics.get(event.source_identifier)
            provider_label = (
                diagnostic.consultation.provider_name
                if diagnostic
                and diagnostic.consultation
                and diagnostic.consultation.provider_name
                else "Diagnostic Lab"
            )
        labels[event.pk] = provider_label
    return labels


def build_profile_update_payload(link, payload):
    user = link.user
    patient = link.patient

    email = str(payload.get("email", user.email)).strip().lower()
    if not email:
        raise ValidationError({"email": "Email is required."})
    duplicate = (
        user.__class__.objects.filter(email__iexact=email).exclude(pk=user.pk).exists()
    )
    if duplicate:
        raise ValidationError({"email": "Another account already uses that email."})

    first_name = str(payload.get("first_name", user.first_name)).strip()
    last_name = str(payload.get("last_name", user.last_name)).strip()
    if not first_name:
        raise ValidationError({"first_name": "First name is required."})
    if not last_name:
        raise ValidationError({"last_name": "Last name is required."})

    phone = str(payload.get("phone", patient.phone)).strip()
    if not phone:
        raise ValidationError({"phone": "Phone number is required."})

    date_of_birth = payload.get("date_of_birth", None)
    if date_of_birth is None:
        parsed_dob = patient.date_of_birth
    elif date_of_birth == "":
        parsed_dob = None
    else:
        try:
            parsed_dob = PatientProfile._meta.get_field("date_of_birth").to_python(
                date_of_birth
            )
        except Exception as exc:
            raise ValidationError(
                {"date_of_birth": "Date of birth must use YYYY-MM-DD format."}
            ) from exc

    return {
        "user": {
            "first_name": first_name,
            "last_name": last_name,
            "email": email,
        },
        "patient": {
            "full_name": f"{first_name} {last_name}".strip(),
            "phone": phone,
            "email": email,
            "address": str(payload.get("address", patient.address)).strip(),
            "date_of_birth": parsed_dob,
        },
    }


def build_patient_settings_payload(link, facility):
    preferences, _ = PatientPreference.objects.get_or_create(
        patient=link.patient,
        facility=facility,
        defaults={"appointment_reminders": True, "order_updates": True},
    )
    return {
        "appointment_reminders": preferences.appointment_reminders,
        "order_updates": preferences.order_updates,
    }


class PatientMeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, access_rows = get_active_patient_context_or_raise(request)
        return Response(build_patient_payload(link, facility, access_rows))

    @transaction.atomic
    def patch(self, request):
        link, facility, access_rows = get_active_patient_context_or_raise(request)
        update_payload = build_profile_update_payload(link, request.data or {})

        for field_name, value in update_payload["user"].items():
            setattr(link.user, field_name, value)
        link.user.save(update_fields=["first_name", "last_name", "email"])

        for field_name, value in update_payload["patient"].items():
            setattr(link.patient, field_name, value)
        link.patient.save(
            update_fields=["full_name", "phone", "email", "address", "date_of_birth"]
        )

        return Response(build_patient_payload(link, facility, access_rows))


class PatientSettingsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        return Response(build_patient_settings_payload(link, facility))

    @transaction.atomic
    def patch(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        preferences, _ = PatientPreference.objects.get_or_create(
            patient=link.patient,
            facility=facility,
            defaults={"appointment_reminders": True, "order_updates": True},
        )
        data = request.data or {}
        if "appointment_reminders" in data:
            preferences.appointment_reminders = bool(data.get("appointment_reminders"))
        if "order_updates" in data:
            preferences.order_updates = bool(data.get("order_updates"))
        preferences.save(
            update_fields=["appointment_reminders", "order_updates", "updated_at"]
        )
        return Response(build_patient_settings_payload(link, facility))


class PatientAppointmentsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        bookings = (
            link.patient.bookings.filter(facility=facility)
            .prefetch_related(
                Prefetch(
                    "consultations",
                    queryset=PatientConsultation.objects.order_by("-consulted_at"),
                    to_attr="prefetched_consultations",
                )
            )
            .order_by("scheduled_for", "-created_at")
        )
        payload = []
        for booking in bookings:
            consultation = (
                booking.prefetched_consultations[0]
                if getattr(booking, "prefetched_consultations", None)
                else None
            )
            booking.latest_consultation = consultation
            payload.append(build_patient_appointment_payload(booking, consultation))
        return Response(payload)


class PatientAppointmentDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, booking_ref):
        link, facility, _ = get_active_patient_context_or_raise(request)
        booking = get_patient_booking_or_raise(link.patient, facility, booking_ref)
        consultation = booking.consultations.order_by("-consulted_at").first()
        return Response(build_patient_appointment_payload(booking, consultation))

    def patch(self, request, booking_ref):
        link, facility, _ = get_active_patient_context_or_raise(request)
        booking = get_patient_booking_or_raise(link.patient, facility, booking_ref)
        next_status = request.data.get("status")
        if next_status:
            booking.status = parse_patient_booking_status(str(next_status).strip())
        booking.save(update_fields=["status", "updated_at"])
        consultation = booking.consultations.order_by("-consulted_at").first()
        return Response(build_patient_appointment_payload(booking, consultation))


class PatientOrdersView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        orders = (
            link.patient.medication_orders.select_related("rider")
            .prefetch_related("items")
            .filter(facility=facility)
            .order_by("-placed_at", "-created_at")
        )
        return Response([build_patient_order_payload(order) for order in orders])


class PatientOrderDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, order_number):
        link, facility, _ = get_active_patient_context_or_raise(request)
        order = get_patient_order_or_raise(link.patient, facility, order_number)
        return Response(build_patient_order_payload(order, include_tracking=True))


def _next_reorder_number(base_order_number):
    suffix = 1
    while True:
        candidate = f"{base_order_number}-R{suffix:02d}"
        if not PatientMedicationOrder.objects.filter(order_number=candidate).exists():
            return candidate
        suffix += 1


class PatientOrderReorderView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request, order_number):
        link, facility, _ = get_active_patient_context_or_raise(request)
        original = get_patient_order_or_raise(link.patient, facility, order_number)
        recreated = PatientMedicationOrder.objects.create(
            order_number=_next_reorder_number(original.order_number),
            patient=link.patient,
            facility=facility,
            prescription=original.prescription,
            rider=original.rider,
            status=PatientPortalOrderStatus.IN_TRANSIT,
            placed_at=timezone.now(),
            eta_label="~15 mins",
            delivery_address=original.delivery_address or link.patient.address,
            pickup_address=original.pickup_address,
            patient_phone=link.patient.phone,
            rider_payout_amount=original.rider_payout_amount,
            distance_km=original.distance_km,
            estimated_minutes=original.estimated_minutes,
            notes=f"Reorder created from {original.order_number}.",
        )
        PatientMedicationOrderItem.objects.bulk_create(
            [
                PatientMedicationOrderItem(
                    order=recreated,
                    medication_name=item.medication_name,
                    quantity=item.quantity,
                )
                for item in original.items.all()
            ]
        )
        recreated.refresh_from_db()
        return Response(build_patient_order_payload(recreated), status=201)


class PatientRecordsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        events = list(
            link.patient.record_events.filter(facility=facility).order_by("-occurred_at")
        )
        provider_labels = resolve_record_provider_labels(events)
        payload = [
            build_patient_record_payload(event, provider_labels.get(event.pk))
            for event in events
        ]
        return Response(payload)


class PatientNotificationsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link, facility, _ = get_active_patient_context_or_raise(request)
        notifications = (
            link.patient.portal_notifications.filter(facility=facility).order_by("-created_at")
        )
        return Response(
            [build_patient_notification_payload(notification) for notification in notifications]
        )


class PatientNotificationReadView(APIView):
    permission_classes = [IsAuthenticated]

    def patch(self, request, notification_code):
        link, facility, _ = get_active_patient_context_or_raise(request)
        notification = _lookup_by_id_or_code(
            link.patient.portal_notifications.filter(facility=facility),
            notification_code,
            "notification_code",
            "Notification not found.",
        )
        if not notification.read:
            notification.read = True
            notification.save(update_fields=["read", "updated_at"])
        return Response(build_patient_notification_payload(notification))
