import json

from django.contrib.auth import authenticate, get_user_model, login, logout
from django.db import transaction
from django.http import JsonResponse
from django.middleware.csrf import get_token
from django.utils.text import slugify
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from django.views.decorators.http import require_GET, require_POST
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from core.models import (
    Facility,
    FacilityStatus,
    PatientFacilityAccess,
    PatientProfile,
    PatientUserLink,
    WorkflowStatus,
)
from portal_api.utils import (
    PATIENT_FACILITY_SESSION_KEY,
    RIDER_FACILITY_SESSION_KEY,
    build_patient_payload,
    build_provider_payload,
    build_rider_payload,
    build_session_payload,
    get_patient_active_facility,
    get_patient_link,
    get_rider_active_facility,
    get_rider_link,
    get_staff_membership,
    prime_user_facility_context,
    set_patient_active_facility,
    set_rider_active_facility,
)


def _parse_request_json(request):
    if not request.body:
        return {}
    try:
        return json.loads(request.body.decode("utf-8"))
    except (TypeError, ValueError):
        return {}


def _json_error(detail, status_code=400, **extra):
    payload = {"detail": detail}
    payload.update(extra)
    return JsonResponse(payload, status=status_code)


def _build_unique_username(email):
    user_model = get_user_model()
    base = slugify(email.split("@", 1)[0]) or "user"
    candidate = base
    counter = 1
    while user_model.objects.filter(username=candidate).exists():
        candidate = f"{base}{counter}"
        counter += 1
    return candidate


def _next_identifier(model_class, field_name, prefix, padding):
    counter = model_class.objects.count() + 1
    while True:
        candidate = f"{prefix}{counter:0{padding}d}"
        if not model_class.objects.filter(**{field_name: candidate}).exists():
            return candidate
        counter += 1


def _default_registration_facility():
    facility = (
        Facility.objects.filter(status=FacilityStatus.APPROVED)
        .order_by("name")
        .first()
    )
    if facility is None:
        facility = Facility.objects.order_by("name").first()
    return facility


@ensure_csrf_cookie
@require_GET
def csrf_cookie_view(request):
    return JsonResponse(
        {
            "detail": "CSRF cookie set.",
            "csrfToken": get_token(request),
        }
    )


@require_GET
def session_view(request):
    if not request.user.is_authenticated:
        return JsonResponse({"authenticated": False, "user": None})
    return JsonResponse(
        {
            "authenticated": True,
            "user": build_session_payload(request.user, request),
        }
    )


@csrf_protect
@require_POST
def login_view(request):
    payload = _parse_request_json(request)
    email = str(payload.get("email", "")).strip().lower()
    password = payload.get("password", "")
    if not email or not password:
        return _json_error("Email and password are required.")

    user_model = get_user_model()
    matched_user = user_model.objects.filter(email__iexact=email).first()
    if matched_user is None:
        return _json_error("Invalid email or password.", status_code=401)

    user = authenticate(
        request, username=matched_user.get_username(), password=password
    )
    if user is None or not user.is_active:
        return _json_error("Invalid email or password.", status_code=401)

    login(request, user)
    prime_user_facility_context(request, user)
    return JsonResponse(
        {
            "authenticated": True,
            "user": build_session_payload(user, request),
            "csrfToken": get_token(request),
        }
    )


@csrf_protect
@require_POST
def logout_view(request):
    if request.user.is_authenticated:
        logout(request)
    return JsonResponse(
        {
            "authenticated": False,
            "detail": "Signed out.",
            "csrfToken": get_token(request),
        }
    )


@csrf_protect
@require_POST
@transaction.atomic
def register_patient_view(request):
    payload = _parse_request_json(request)
    email = str(payload.get("email", "")).strip().lower()
    password = payload.get("password", "")
    first_name = str(payload.get("first_name", "")).strip()
    last_name = str(payload.get("last_name", "")).strip()
    phone = str(payload.get("phone", "")).strip()
    address = str(payload.get("address", "")).strip()
    blood_group = str(payload.get("blood_group", "")).strip()
    date_of_birth = str(payload.get("date_of_birth", "")).strip()

    if not email:
        return _json_error("Email is required.")
    if len(password) < 6:
        return _json_error("Password must be at least 6 characters.")
    if not first_name:
        return _json_error("First name is required.")
    if not last_name:
        return _json_error("Last name is required.")
    if not phone:
        return _json_error("Phone number is required.")

    user_model = get_user_model()
    if user_model.objects.filter(email__iexact=email).exists():
        return _json_error("An account with that email already exists.")

    facility = _default_registration_facility()
    if facility is None:
        return _json_error("No facility is available for registration.", status_code=503)

    parsed_dob = None
    if date_of_birth:
        try:
            parsed_dob = PatientProfile._meta.get_field("date_of_birth").to_python(
                date_of_birth
            )
        except Exception:
            return _json_error("Date of birth must use YYYY-MM-DD format.")

    user = user_model.objects.create_user(
        username=_build_unique_username(email),
        email=email,
        password=password,
        first_name=first_name,
        last_name=last_name,
        is_staff=False,
    )

    patient = PatientProfile.objects.create(
        patient_code=_next_identifier(PatientProfile, "patient_code", "PAT-", 4),
        full_name=f"{first_name} {last_name}".strip(),
        status=WorkflowStatus.CONFIRMED,
        phone=phone,
        email=email,
        date_of_birth=parsed_dob,
        blood_group=blood_group,
        address=address,
        preferred_language="en",
    )
    link = PatientUserLink.objects.create(
        user=user,
        patient=patient,
        default_facility=facility,
        is_active=True,
    )
    access = PatientFacilityAccess.objects.create(
        patient=patient,
        facility=facility,
        is_default=True,
        is_active=True,
    )

    login(request, user)
    set_patient_active_facility(request, facility)
    return JsonResponse(
        {
            "authenticated": True,
            "user": build_patient_payload(link, facility, [access]),
            "csrfToken": get_token(request),
        },
        status=201,
    )


@csrf_protect
@require_POST
def switch_facility_context_view(request):
    if not request.user.is_authenticated:
        return _json_error("Authentication required.", status_code=401)

    payload = _parse_request_json(request)
    facility_id = str(payload.get("facility_id", "")).strip()
    principal = str(payload.get("principal", "")).strip().lower()
    if not facility_id:
        return _json_error("facility_id is required.")

    if principal == "patient" or not principal:
        link = get_patient_link(request.user)
        if link:
            facility, access_rows = get_patient_active_facility(link, facility_id)
            if facility and str(facility.id) == facility_id:
                set_patient_active_facility(request, facility)
                return JsonResponse(
                    {
                        "detail": "Patient facility context updated.",
                        "user": build_patient_payload(link, facility, access_rows),
                    }
                )

    if principal == "rider" or not principal:
        link = get_rider_link(request.user)
        if link:
            facility, access_rows = get_rider_active_facility(link, facility_id)
            if facility and str(facility.id) == facility_id:
                set_rider_active_facility(request, facility)
                return JsonResponse(
                    {
                        "detail": "Rider facility context updated.",
                        "user": build_rider_payload(link, facility, access_rows),
                    }
                )

    membership = get_staff_membership(request.user)
    if membership and str(membership.facility_id) == facility_id:
        return JsonResponse(
            {
                "detail": "Staff accounts are fixed to their assigned facility.",
                "user": build_provider_payload(membership),
            }
        )

    return _json_error("Facility context not available for this account.", status_code=403)


class ProviderMeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        membership = get_staff_membership(request.user)
        if membership is None:
            return Response(
                {"detail": "This account does not have provider portal access."},
                status=403,
            )
        return Response(build_provider_payload(membership))


class RiderMeView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        link = get_rider_link(request.user)
        if link is None:
            return Response(
                {"detail": "Rider profile link not found."},
                status=404,
            )
        active_facility, access_rows = get_rider_active_facility(
            link,
            request.session.get(RIDER_FACILITY_SESSION_KEY),
        )
        return Response(build_rider_payload(link, active_facility, access_rows))
