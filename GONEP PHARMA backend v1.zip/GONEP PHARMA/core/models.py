from django.conf import settings
from django.db import models
from django.utils import timezone
from django.utils.text import slugify


class WorkflowStatus(models.TextChoices):
    IDLE = "idle", "Idle"
    DRAFT = "draft", "Draft"
    CONFIRMED = "confirmed", "Confirmed"
    IN_PROGRESS = "in_progress", "In Progress"
    COMPLETED = "completed", "Completed"
    CANCELLED = "cancelled", "Cancelled"


class SeverityLevel(models.TextChoices):
    LOW = "low", "Low"
    MEDIUM = "medium", "Medium"
    HIGH = "high", "High"
    CRITICAL = "critical", "Critical"


class PayoutState(models.TextChoices):
    DRAFT = "draft", "Draft"
    PENDING_APPROVAL = "pending_approval", "Pending Approval"
    APPROVED = "approved", "Approved"
    PAID = "paid", "Paid"
    REJECTED = "rejected", "Rejected"


class ComplaintSLAState(models.TextChoices):
    ON_TRACK = "on_track", "On Track"
    AT_RISK = "at_risk", "At Risk"
    BREACHED = "breached", "Breached"
    RESOLVED = "resolved", "Resolved"


class InventoryState(models.TextChoices):
    IN_STOCK = "in_stock", "In Stock"
    LOW_STOCK = "low_stock", "Low Stock"
    OUT_OF_STOCK = "out_of_stock", "Out of Stock"
    EXPIRED = "expired", "Expired"


class ReconciliationState(models.TextChoices):
    PENDING = "pending", "Pending"
    RECONCILED = "reconciled", "Reconciled"
    EXCEPTION = "exception", "Exception"


class CollectionStage(models.TextChoices):
    CURRENT = "current", "Current"
    DUE = "due", "Due"
    OVERDUE = "overdue", "Overdue"
    DISPUTED = "disputed", "Disputed"
    PAID = "paid", "Paid"


class AuditReviewState(models.TextChoices):
    PENDING = "pending", "Pending"
    UNDER_REVIEW = "under_review", "Under Review"
    EVIDENCE_REQUESTED = "evidence_requested", "Evidence Requested"
    APPROVED = "approved", "Approved"
    REJECTED = "rejected", "Rejected"


class AttachmentKind(models.TextChoices):
    EVIDENCE = "evidence", "Evidence"
    REPORT = "report", "Report"
    NOTE = "note", "Note"
    PLACEHOLDER = "placeholder", "Placeholder"


class BaseTrackedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Tag(BaseTrackedModel):
    module = models.CharField(max_length=64, default="control_admin")
    name = models.CharField(max_length=64, unique=True)
    slug = models.SlugField(max_length=80, unique=True, blank=True)
    color = models.CharField(max_length=7, default="#0EA5A4")

    class Meta:
        ordering = ["module", "name"]

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class AuditEvent(BaseTrackedModel):
    module = models.CharField(max_length=64, default="control_admin")
    action = models.CharField(max_length=120)
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.LOW
    )
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="audit_events",
    )
    model_label = models.CharField(max_length=120)
    object_identifier = models.CharField(max_length=120)
    metadata = models.JSONField(default=dict, blank=True)
    message = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.model_label}:{self.action}"


class TimelineEvent(BaseTrackedModel):
    module = models.CharField(max_length=64, default="control_admin")
    event_type = models.CharField(max_length=80)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.IDLE
    )
    title = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    related_model = models.CharField(max_length=120)
    related_identifier = models.CharField(max_length=120)
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="timeline_events",
    )
    extra = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


class Attachment(BaseTrackedModel):
    module = models.CharField(max_length=64, default="control_admin")
    title = models.CharField(max_length=120)
    file_name = models.CharField(max_length=255)
    file_url = models.URLField(max_length=500)
    kind = models.CharField(
        max_length=24, choices=AttachmentKind.choices, default=AttachmentKind.PLACEHOLDER
    )
    content_type = models.CharField(max_length=120, blank=True)
    related_model = models.CharField(max_length=120)
    related_identifier = models.CharField(max_length=120)
    complaint = models.ForeignKey(
        "Complaint",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="attachments",
    )
    compliance_audit = models.ForeignKey(
        "ComplianceAudit",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="attachments",
    )
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="uploaded_attachments",
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


class Note(BaseTrackedModel):
    module = models.CharField(max_length=64, default="control_admin")
    title = models.CharField(max_length=120)
    body = models.TextField()
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    related_model = models.CharField(max_length=120, blank=True)
    related_identifier = models.CharField(max_length=120, blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="notes_created",
    )
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="notes_assigned",
    )
    tags = models.ManyToManyField(Tag, blank=True, related_name="notes")

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


class ActionQueueItem(BaseTrackedModel):
    module = models.CharField(max_length=64, default="control_admin")
    action_type = models.CharField(max_length=120)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.IDLE
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    priority = models.PositiveSmallIntegerField(default=3)
    payload = models.JSONField(default=dict, blank=True)
    due_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="queue_items",
    )

    class Meta:
        ordering = ["priority", "-created_at"]

    def __str__(self):
        return self.action_type


class CommandProvider(BaseTrackedModel):
    full_name = models.CharField(max_length=120)
    specialty = models.CharField(max_length=120, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.IDLE
    )
    phone = models.CharField(max_length=32, blank=True)
    email = models.EmailField(blank=True)
    availability_score = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    tags = models.ManyToManyField(Tag, blank=True, related_name="providers")

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return self.full_name


class CommandRider(BaseTrackedModel):
    full_name = models.CharField(max_length=120)
    vehicle_type = models.CharField(max_length=64, blank=True)
    zone = models.CharField(max_length=64, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.IDLE
    )
    phone = models.CharField(max_length=32, blank=True)
    tags = models.ManyToManyField(Tag, blank=True, related_name="riders")

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return self.full_name


class CommandBooking(BaseTrackedModel):
    reference = models.CharField(max_length=50, unique=True)
    patient_name = models.CharField(max_length=120)
    service_type = models.CharField(max_length=120, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.LOW
    )
    scheduled_for = models.DateTimeField(null=True, blank=True)
    provider = models.ForeignKey(
        CommandProvider,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="bookings",
    )
    rider = models.ForeignKey(
        CommandRider,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="bookings",
    )
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=8, default="KES")
    notes = models.TextField(blank=True)
    tags = models.ManyToManyField(Tag, blank=True, related_name="bookings")

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.reference


class CommandIncident(BaseTrackedModel):
    title = models.CharField(max_length=160)
    category = models.CharField(max_length=80, blank=True)
    status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.IN_PROGRESS,
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    booking = models.ForeignKey(
        CommandBooking,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="incidents",
    )
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="command_incidents",
    )
    resolved_at = models.DateTimeField(null=True, blank=True)
    details = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


class PerformanceFlag(BaseTrackedModel):
    subject_type = models.CharField(max_length=40)
    subject_identifier = models.CharField(max_length=120)
    title = models.CharField(max_length=160)
    status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.IN_PROGRESS,
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    score = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="performance_flags",
    )
    summary = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


class ComplianceAudit(BaseTrackedModel):
    title = models.CharField(max_length=160)
    audit_type = models.CharField(max_length=80, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="compliance_audits",
    )
    review_state = models.CharField(
        max_length=32,
        choices=AuditReviewState.choices,
        default=AuditReviewState.PENDING,
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="compliance_reviews",
    )
    due_date = models.DateField(null=True, blank=True)
    evidence_due_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    summary = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


class Complaint(BaseTrackedModel):
    ticket_number = models.CharField(max_length=50, unique=True)
    customer_name = models.CharField(max_length=120)
    channel = models.CharField(max_length=64, blank=True)
    status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.IN_PROGRESS,
    )
    sla_state = models.CharField(
        max_length=16,
        choices=ComplaintSLAState.choices,
        default=ComplaintSLAState.ON_TRACK,
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="complaints",
    )
    opened_at = models.DateTimeField(default=timezone.now)
    sla_due_at = models.DateTimeField(null=True, blank=True)
    first_response_at = models.DateTimeField(null=True, blank=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    breach_reason = models.TextField(blank=True)
    resolution_notes = models.TextField(blank=True)
    summary = models.TextField(blank=True)

    class Meta:
        ordering = ["-opened_at"]

    def __str__(self):
        return self.ticket_number


class RiskFlag(BaseTrackedModel):
    name = models.CharField(max_length=160)
    flag_type = models.CharField(max_length=80, blank=True)
    status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.IN_PROGRESS,
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    subject_model = models.CharField(max_length=120, blank=True)
    subject_identifier = models.CharField(max_length=120, blank=True)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="risk_flags",
    )
    reason = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.name


class PatientProfile(BaseTrackedModel):
    patient_code = models.CharField(max_length=40, unique=True)
    full_name = models.CharField(max_length=120)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    phone = models.CharField(max_length=32, blank=True)
    email = models.EmailField(blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=20, blank=True)
    preferred_language = models.CharField(max_length=24, default="en")
    theme_preference = models.CharField(max_length=16, default="system")
    emergency_contact_name = models.CharField(max_length=120, blank=True)
    emergency_contact_phone = models.CharField(max_length=32, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return f"{self.patient_code} - {self.full_name}"


class PatientBooking(BaseTrackedModel):
    booking_ref = models.CharField(max_length=50, unique=True)
    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name="bookings"
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    service_type = models.CharField(max_length=120, blank=True)
    channel = models.CharField(max_length=50, blank=True)
    scheduled_for = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.booking_ref


class PatientConsultation(BaseTrackedModel):
    consultation_ref = models.CharField(max_length=50, unique=True)
    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name="consultations"
    )
    booking = models.ForeignKey(
        PatientBooking,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="consultations",
    )
    status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.IN_PROGRESS,
    )
    provider_name = models.CharField(max_length=120, blank=True)
    subjective = models.TextField(blank=True)
    objective = models.TextField(blank=True)
    assessment = models.TextField(blank=True)
    plan = models.TextField(blank=True)
    consulted_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-consulted_at"]

    def __str__(self):
        return self.consultation_ref


class PatientPrescription(BaseTrackedModel):
    rx_number = models.CharField(max_length=50, unique=True)
    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name="prescriptions"
    )
    consultation = models.ForeignKey(
        PatientConsultation,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="prescriptions",
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    medication_name = models.CharField(max_length=160)
    dosage = models.CharField(max_length=120, blank=True)
    instructions = models.TextField(blank=True)
    delivery_status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.CONFIRMED,
    )
    issued_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-issued_at"]

    def __str__(self):
        return self.rx_number


class PatientDiagnosticOrder(BaseTrackedModel):
    order_number = models.CharField(max_length=50, unique=True)
    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name="diagnostic_orders"
    )
    consultation = models.ForeignKey(
        PatientConsultation,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="diagnostic_orders",
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    test_type = models.CharField(max_length=140)
    upload_url = models.URLField(max_length=500, blank=True)
    result_summary = models.TextField(blank=True)
    collected_at = models.DateTimeField(null=True, blank=True)
    result_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.order_number


class PatientRecordEvent(BaseTrackedModel):
    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name="record_events"
    )
    event_type = models.CharField(max_length=64)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    title = models.CharField(max_length=160)
    source_model = models.CharField(max_length=120)
    source_identifier = models.CharField(max_length=120)
    details = models.TextField(blank=True)
    occurred_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-occurred_at"]

    def __str__(self):
        return f"{self.patient.patient_code} - {self.title}"


class PatientSupportTicket(BaseTrackedModel):
    ticket_number = models.CharField(max_length=50, unique=True)
    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name="support_tickets"
    )
    status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.IN_PROGRESS,
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    channel = models.CharField(max_length=64, blank=True)
    subject = models.CharField(max_length=180)
    message = models.TextField(blank=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.ticket_number


class ProviderProfile(BaseTrackedModel):
    provider_code = models.CharField(max_length=40, unique=True)
    full_name = models.CharField(max_length=120)
    specialty = models.CharField(max_length=120, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    phone = models.CharField(max_length=32, blank=True)
    email = models.EmailField(blank=True)
    license_number = models.CharField(max_length=80, blank=True)
    years_experience = models.PositiveSmallIntegerField(default=0)
    payout_account = models.CharField(max_length=120, blank=True)
    bio = models.TextField(blank=True)

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return f"{self.provider_code} - {self.full_name}"


class ProviderAppointment(BaseTrackedModel):
    appointment_ref = models.CharField(max_length=50, unique=True)
    provider = models.ForeignKey(
        ProviderProfile, on_delete=models.CASCADE, related_name="appointments"
    )
    patient = models.ForeignKey(
        PatientProfile, on_delete=models.SET_NULL, null=True, blank=True
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    scheduled_for = models.DateTimeField(null=True, blank=True)
    visit_reason = models.CharField(max_length=160, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.appointment_ref


class ProviderConsultation(BaseTrackedModel):
    consultation_ref = models.CharField(max_length=50, unique=True)
    provider = models.ForeignKey(
        ProviderProfile, on_delete=models.CASCADE, related_name="consultations"
    )
    patient = models.ForeignKey(
        PatientProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="provider_consultations",
    )
    appointment = models.ForeignKey(
        ProviderAppointment,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="consultations",
    )
    status = models.CharField(
        max_length=16,
        choices=WorkflowStatus.choices,
        default=WorkflowStatus.IN_PROGRESS,
    )
    vitals = models.TextField(blank=True)
    soap_notes = models.TextField(blank=True)
    next_action = models.CharField(max_length=160, blank=True)
    consulted_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-consulted_at"]

    def __str__(self):
        return self.consultation_ref


class ProviderPrescriptionTask(BaseTrackedModel):
    task_ref = models.CharField(max_length=50, unique=True)
    provider = models.ForeignKey(
        ProviderProfile, on_delete=models.CASCADE, related_name="prescription_tasks"
    )
    patient = models.ForeignKey(
        PatientProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="provider_prescription_tasks",
    )
    consultation = models.ForeignKey(
        ProviderConsultation,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="prescription_tasks",
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    medication_summary = models.TextField(blank=True)
    signed_off_at = models.DateTimeField(null=True, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.task_ref


class ProviderEarningsSnapshot(BaseTrackedModel):
    provider = models.ForeignKey(
        ProviderProfile, on_delete=models.CASCADE, related_name="earnings_snapshots"
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    period_start = models.DateField()
    period_end = models.DateField()
    gross_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    fee_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    net_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    payout_state = models.CharField(
        max_length=24, choices=PayoutState.choices, default=PayoutState.DRAFT
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-period_end"]

    def __str__(self):
        return f"{self.provider.provider_code} {self.period_start} - {self.period_end}"


class ProviderProtocol(BaseTrackedModel):
    protocol_code = models.CharField(max_length=50, unique=True)
    title = models.CharField(max_length=180)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    version = models.CharField(max_length=20, default="v1")
    category = models.CharField(max_length=100, blank=True)
    content = models.TextField(blank=True)
    published_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["title"]

    def __str__(self):
        return self.protocol_code


class RiderProfile(BaseTrackedModel):
    rider_code = models.CharField(max_length=40, unique=True)
    full_name = models.CharField(max_length=120)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    vehicle_type = models.CharField(max_length=64, blank=True)
    zone = models.CharField(max_length=64, blank=True)
    phone = models.CharField(max_length=32, blank=True)
    is_online = models.BooleanField(default=False)

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return f"{self.rider_code} - {self.full_name}"


class RiderJob(BaseTrackedModel):
    job_ref = models.CharField(max_length=50, unique=True)
    rider = models.ForeignKey(
        RiderProfile, on_delete=models.CASCADE, related_name="jobs"
    )
    booking = models.ForeignKey(
        CommandBooking,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="rider_jobs",
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    severity = models.CharField(
        max_length=16, choices=SeverityLevel.choices, default=SeverityLevel.MEDIUM
    )
    pickup_location = models.CharField(max_length=200, blank=True)
    dropoff_location = models.CharField(max_length=200, blank=True)
    delivery_proof_url = models.URLField(max_length=500, blank=True)
    sample_collected = models.BooleanField(default=False)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.job_ref


class RiderHistoryEntry(BaseTrackedModel):
    rider = models.ForeignKey(
        RiderProfile, on_delete=models.CASCADE, related_name="history_entries"
    )
    job = models.ForeignKey(
        RiderJob, on_delete=models.SET_NULL, null=True, blank=True, related_name="history_entries"
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    title = models.CharField(max_length=160)
    details = models.TextField(blank=True)
    occurred_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-occurred_at"]

    def __str__(self):
        return f"{self.rider.rider_code} - {self.title}"


class RiderEarningsSnapshot(BaseTrackedModel):
    rider = models.ForeignKey(
        RiderProfile, on_delete=models.CASCADE, related_name="earnings_snapshots"
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    period_start = models.DateField()
    period_end = models.DateField()
    gross_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    bonus_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    net_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    payout_state = models.CharField(
        max_length=24, choices=PayoutState.choices, default=PayoutState.DRAFT
    )
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["-period_end"]

    def __str__(self):
        return f"{self.rider.rider_code} {self.period_start} - {self.period_end}"


class Supplier(BaseTrackedModel):
    name = models.CharField(max_length=120)
    contact_person = models.CharField(max_length=120, blank=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=32, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.IDLE
    )
    rating = models.DecimalField(max_digits=4, decimal_places=2, default=0)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class StockItem(BaseTrackedModel):
    sku = models.CharField(max_length=64, unique=True)
    name = models.CharField(max_length=120)
    status = models.CharField(
        max_length=16, choices=InventoryState.choices, default=InventoryState.IN_STOCK
    )
    quantity = models.PositiveIntegerField(default=0)
    reorder_level = models.PositiveIntegerField(default=0)
    unit_price = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    supplier = models.ForeignKey(
        Supplier,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="stock_items",
    )

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class InventoryBatch(BaseTrackedModel):
    stock_item = models.ForeignKey(
        StockItem, on_delete=models.CASCADE, related_name="batches"
    )
    batch_code = models.CharField(max_length=64, unique=True)
    status = models.CharField(
        max_length=16, choices=InventoryState.choices, default=InventoryState.IN_STOCK
    )
    quantity = models.PositiveIntegerField(default=0)
    received_on = models.DateField(null=True, blank=True)
    expires_on = models.DateField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.batch_code


class SaleRecord(BaseTrackedModel):
    sale_number = models.CharField(max_length=64, unique=True)
    item = models.ForeignKey(
        StockItem, on_delete=models.SET_NULL, null=True, blank=True, related_name="sales"
    )
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    quantity = models.PositiveIntegerField(default=1)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    sold_at = models.DateTimeField(default=timezone.now)
    channel = models.CharField(max_length=64, blank=True)

    class Meta:
        ordering = ["-sold_at"]

    def __str__(self):
        return self.sale_number


class RevenueEntry(BaseTrackedModel):
    reference = models.CharField(max_length=64, unique=True)
    source = models.CharField(max_length=120, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    reconciliation_state = models.CharField(
        max_length=24,
        choices=ReconciliationState.choices,
        default=ReconciliationState.PENDING,
    )
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=8, default="KES")
    booked_at = models.DateTimeField(default=timezone.now)
    reconciled_at = models.DateTimeField(null=True, blank=True)
    reconciled_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="reconciled_revenue_entries",
    )

    class Meta:
        ordering = ["-booked_at"]

    def __str__(self):
        return self.reference


class PayoutRequest(BaseTrackedModel):
    reference = models.CharField(max_length=64, unique=True)
    beneficiary_name = models.CharField(max_length=120)
    status = models.CharField(
        max_length=24, choices=PayoutState.choices, default=PayoutState.DRAFT
    )
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=8, default="KES")
    requested_at = models.DateTimeField(default=timezone.now)
    review_note = models.TextField(blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="approved_payouts",
    )

    class Meta:
        ordering = ["-requested_at"]

    def __str__(self):
        return self.reference


class Invoice(BaseTrackedModel):
    invoice_number = models.CharField(max_length=64, unique=True)
    customer_name = models.CharField(max_length=120)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.DRAFT
    )
    collection_stage = models.CharField(
        max_length=16, choices=CollectionStage.choices, default=CollectionStage.CURRENT
    )
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=8, default="KES")
    issued_on = models.DateField(default=timezone.now)
    due_on = models.DateField(null=True, blank=True)
    paid_on = models.DateField(null=True, blank=True)

    class Meta:
        ordering = ["-issued_on"]

    def __str__(self):
        return self.invoice_number


class TransactionLog(BaseTrackedModel):
    transaction_id = models.CharField(max_length=80, unique=True)
    transaction_type = models.CharField(max_length=64, blank=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.CONFIRMED
    )
    reconciliation_state = models.CharField(
        max_length=24,
        choices=ReconciliationState.choices,
        default=ReconciliationState.PENDING,
    )
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    currency = models.CharField(max_length=8, default="KES")
    processed_at = models.DateTimeField(default=timezone.now)
    reconciled_at = models.DateTimeField(null=True, blank=True)
    reconciled_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="reconciled_transactions",
    )
    payload = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-processed_at"]

    def __str__(self):
        return self.transaction_id


class ExecutiveKPI(BaseTrackedModel):
    metric_name = models.CharField(max_length=120)
    metric_code = models.CharField(max_length=40, unique=True)
    status = models.CharField(
        max_length=16, choices=WorkflowStatus.choices, default=WorkflowStatus.IDLE
    )
    value = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    trend_delta = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    period_start = models.DateField()
    period_end = models.DateField()
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="executive_kpis",
    )

    class Meta:
        ordering = ["-period_end", "metric_name"]

    def __str__(self):
        return self.metric_name
