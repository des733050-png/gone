from django import template

register = template.Library()


MODEL_ICON_MAP = {
    "actionqueueitem": "pending_actions",
    "attachment": "attach_file",
    "auditevent": "policy",
    "commandbooking": "event_available",
    "commandincident": "report_problem",
    "commandprovider": "local_hospital",
    "commandrider": "two_wheeler",
    "complaint": "support_agent",
    "complianceaudit": "fact_check",
    "executivekpi": "insights",
    "inventorybatch": "inventory_2",
    "invoice": "receipt_long",
    "note": "note",
    "patientbooking": "event_note",
    "patientconsultation": "health_and_safety",
    "patientdiagnosticorder": "biotech",
    "patientprescription": "medication",
    "patientprofile": "badge",
    "patientrecordevent": "description",
    "patientsupportticket": "help_center",
    "performanceflag": "monitoring",
    "payoutrequest": "account_balance_wallet",
    "providerappointment": "event",
    "providerconsultation": "stethoscope",
    "providerearningssnapshot": "payments",
    "providerprescriptiontask": "medication",
    "providerprofile": "badge",
    "providerprotocol": "menu_book",
    "revenueentry": "payments",
    "riderearningssnapshot": "payments",
    "riderhistoryentry": "history",
    "riderjob": "local_shipping",
    "riderprofile": "badge",
    "riskflag": "flag",
    "salerecord": "point_of_sale",
    "stockitem": "inventory",
    "supplier": "local_shipping",
    "tag": "sell",
    "timelineevent": "timeline",
    "transactionlog": "swap_horiz",
    "user": "person",
    "group": "groups",
}

APP_ICON_MAP = {
    "core": "dashboard_customize",
    "auth": "admin_panel_settings",
}


@register.filter
def model_icon(object_name):
    if not object_name:
        return "apps"
    return MODEL_ICON_MAP.get(str(object_name).lower(), "apps")


@register.filter
def app_icon(app_label):
    if not app_label:
        return "widgets"
    return APP_ICON_MAP.get(str(app_label).lower(), "widgets")
