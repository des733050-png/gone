from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand


GROUPS = (
    "admin_user",
    "patient_user",
    "provider_user",
    "rider_user",
)

LEGACY_GROUPS = (
    "control_ops_admin",
    "control_finance_admin",
    "control_compliance_admin",
    "support_admin",
    "patient_ops_admin",
    "provider_ops_admin",
    "rider_ops_admin",
)

GROUP_MODELS = {
    "admin_user": [
        "commandbooking",
        "commandprovider",
        "commandrider",
        "commandincident",
        "performanceflag",
        "complianceaudit",
        "complaint",
        "riskflag",
        "stockitem",
        "inventorybatch",
        "salerecord",
        "supplier",
        "revenueentry",
        "payoutrequest",
        "invoice",
        "transactionlog",
        "executivekpi",
        "actionqueueitem",
        "timelineevent",
        "attachment",
        "note",
        "auditevent",
        "tag",
    ],
    "patient_user": [
        "patientprofile",
        "patientbooking",
        "patientconsultation",
        "patientprescription",
        "patientdiagnosticorder",
        "patientrecordevent",
        "patientsupportticket",
        "timelineevent",
        "attachment",
        "note",
    ],
    "provider_user": [
        "providerprofile",
        "providerappointment",
        "providerconsultation",
        "providerprescriptiontask",
        "providerearningssnapshot",
        "providerprotocol",
        "patientprofile",
        "timelineevent",
        "attachment",
        "note",
    ],
    "rider_user": [
        "riderprofile",
        "riderjob",
        "riderhistoryentry",
        "riderearningssnapshot",
        "commandbooking",
        "timelineevent",
        "attachment",
        "note",
    ],
}

CRUD_ACTIONS = ("add", "change", "delete", "view")


class Command(BaseCommand):
    help = "Create and sync only the four production role groups."

    def handle(self, *args, **options):
        removed_count = 0
        for name in LEGACY_GROUPS:
            deleted, _ = Group.objects.filter(name=name).delete()
            if deleted:
                removed_count += 1
                self.stdout.write(f"Removed legacy group: {name}")

        created_count = 0
        for name in GROUPS:
            group, created = Group.objects.get_or_create(name=name)
            if created:
                created_count += 1
                self.stdout.write(self.style.SUCCESS(f"Created group: {name}"))
            else:
                self.stdout.write(f"Group exists: {name}")
            self._assign_model_permissions(group)
        self.stdout.write(
            self.style.SUCCESS(
                f"Bootstrap complete. New groups created: {created_count}. "
                f"Legacy groups removed: {removed_count}."
            )
        )

    def _assign_model_permissions(self, group):
        model_names = GROUP_MODELS.get(group.name, [])
        content_types = ContentType.objects.filter(
            app_label="core", model__in=model_names
        )
        perm_codenames = []
        for content_type in content_types:
            for action in CRUD_ACTIONS:
                perm_codenames.append(f"{action}_{content_type.model}")
        permissions = group.permissions.model.objects.filter(
            codename__in=perm_codenames, content_type__app_label="core"
        )
        group.permissions.set(permissions)
        self.stdout.write(
            f"Permissions synced for {group.name}: {permissions.count()} permission(s)."
        )
