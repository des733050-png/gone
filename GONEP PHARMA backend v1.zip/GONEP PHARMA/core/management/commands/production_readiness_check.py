from django.core.management.base import BaseCommand, CommandError
from django.db.models import Count

from core.models import (
    ActionQueueItem,
    AuditEvent,
    CommandIncident,
    Complaint,
    ComplianceAudit,
)


REQUIRED_GROUPS = (
    "admin_user",
    "patient_user",
    "provider_user",
    "rider_user",
)


class Command(BaseCommand):
    help = "Run production-closure readiness checks for roles, queues, and observability."

    def add_arguments(self, parser):
        parser.add_argument(
            "--strict",
            action="store_true",
            help="Fail with non-zero exit code if required checks are missing.",
        )

    def handle(self, *args, **options):
        strict = options["strict"]
        failures = []

        # Group existence check
        from django.contrib.auth.models import Group

        existing_groups = set(Group.objects.filter(name__in=REQUIRED_GROUPS).values_list("name", flat=True))
        missing_groups = [name for name in REQUIRED_GROUPS if name not in existing_groups]
        if missing_groups:
            failures.append(f"Missing role groups: {', '.join(missing_groups)}")

        # Operational closure snapshots
        open_critical_incidents = CommandIncident.objects.filter(
            severity="critical"
        ).exclude(status="completed").count()
        unresolved_complaints = Complaint.objects.exclude(sla_state="resolved").count()
        pending_audits = ComplianceAudit.objects.exclude(review_state="approved").count()
        queue_backlog = ActionQueueItem.objects.exclude(status="completed").count()

        finance_audit_actions = (
            AuditEvent.objects.filter(module="finance")
            .values("action")
            .annotate(total=Count("id"))
            .order_by("-total")
        )

        self.stdout.write("=== GonePharm Production Readiness Snapshot ===")
        self.stdout.write(f"Open critical incidents: {open_critical_incidents}")
        self.stdout.write(f"Unresolved complaints: {unresolved_complaints}")
        self.stdout.write(f"Pending compliance audits: {pending_audits}")
        self.stdout.write(f"Action queue backlog: {queue_backlog}")
        self.stdout.write("Top finance audit actions:")
        if finance_audit_actions:
            for item in finance_audit_actions[:10]:
                self.stdout.write(f" - {item['action']}: {item['total']}")
        else:
            self.stdout.write(" - none")

        if failures:
            for failure in failures:
                self.stdout.write(self.style.ERROR(failure))
            if strict:
                raise CommandError("Production readiness check failed in strict mode.")
            self.stdout.write(self.style.WARNING("Readiness check completed with warnings."))
        else:
            self.stdout.write(self.style.SUCCESS("Readiness check passed."))
