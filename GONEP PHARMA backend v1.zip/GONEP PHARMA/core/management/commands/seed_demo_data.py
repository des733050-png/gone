from datetime import timedelta

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.management import call_command
from django.core.management.base import BaseCommand
from django.utils import timezone

from core import models


DEMO_PASSWORD = "Demo@12345"
DEMO_USERS = (
    ("demo_superadmin", "demo.superadmin@gonepharm.local", ("admin_user", "patient_user", "provider_user", "rider_user"), True),
    ("demo_admin_user", "demo.admin@gonepharm.local", ("admin_user",), True),
    ("demo_patient_user", "demo.patient@gonepharm.local", ("patient_user",), True),
    ("demo_provider_user", "demo.provider@gonepharm.local", ("provider_user",), True),
    ("demo_rider_user", "demo.rider@gonepharm.local", ("rider_user",), True),
)

LEGACY_DEMO_USERNAMES = (
    "demo_ops_admin",
    "demo_finance_admin",
    "demo_compliance_admin",
    "demo_support_admin",
    "demo_patient_admin",
    "demo_provider_admin",
    "demo_rider_admin",
)


class Command(BaseCommand):
    help = "Seed idempotent demo data for GonePharm admin modules."

    def add_arguments(self, parser):
        parser.add_argument(
            "--password",
            default=DEMO_PASSWORD,
            help="Password used for demo users (default: Demo@12345).",
        )

    def handle(self, *args, **options):
        password = options["password"]
        now = timezone.now()
        today = now.date()
        counts = {"created": 0, "existing": 0}

        call_command("bootstrap_control_groups")
        self.stdout.write(self.style.SUCCESS("Groups bootstrapped."))
        removed_legacy = get_user_model().objects.filter(
            username__in=LEGACY_DEMO_USERNAMES
        ).delete()[0]
        if removed_legacy:
            self.stdout.write(f"Removed legacy demo users: {removed_legacy}")

        users = self._seed_users(password, counts)
        owner = users["demo_superadmin"]

        tags = {
            "ops": self._upsert(
                models.Tag,
                {"name": "ops-critical"},
                {"module": "control_admin", "color": "#DC2626"},
                counts,
            ),
            "finance": self._upsert(
                models.Tag,
                {"name": "finance-review"},
                {"module": "control_admin", "color": "#0891B2"},
                counts,
            ),
            "patient": self._upsert(
                models.Tag,
                {"name": "patient-priority"},
                {"module": "patient", "color": "#7C3AED"},
                counts,
            ),
        }

        provider = self._upsert(
            models.CommandProvider,
            {"full_name": "Dr. Amina Wanjiru"},
            {
                "specialty": "General Practice",
                "status": models.WorkflowStatus.CONFIRMED,
                "phone": "+254700000101",
                "email": "provider.demo@gonepharm.local",
                "availability_score": 91.50,
            },
            counts,
        )
        provider.tags.add(tags["ops"])

        rider = self._upsert(
            models.CommandRider,
            {"full_name": "John Kamau"},
            {
                "vehicle_type": "Motorbike",
                "zone": "Nairobi CBD",
                "status": models.WorkflowStatus.CONFIRMED,
                "phone": "+254700000202",
            },
            counts,
        )
        rider.tags.add(tags["ops"])

        booking = self._upsert(
            models.CommandBooking,
            {"reference": "CB-1001"},
            {
                "patient_name": "Mary Atieno",
                "service_type": "Lab Collection",
                "status": models.WorkflowStatus.CONFIRMED,
                "severity": models.SeverityLevel.MEDIUM,
                "scheduled_for": now + timedelta(hours=4),
                "provider": provider,
                "rider": rider,
                "total_amount": 3500,
                "currency": "KES",
                "notes": "Demo booking for command center.",
            },
            counts,
        )
        booking.tags.add(tags["ops"])

        incident = self._upsert(
            models.CommandIncident,
            {"title": "Delayed rider pickup - Zone A"},
            {
                "category": "Logistics",
                "status": models.WorkflowStatus.IN_PROGRESS,
                "severity": models.SeverityLevel.HIGH,
                "booking": booking,
                "owner": owner,
                "details": "Traffic congestion impacted pickup SLA.",
            },
            counts,
        )

        performance = self._upsert(
            models.PerformanceFlag,
            {"title": "Provider response time below target"},
            {
                "subject_type": "provider",
                "subject_identifier": provider.full_name,
                "status": models.WorkflowStatus.IN_PROGRESS,
                "severity": models.SeverityLevel.MEDIUM,
                "score": 72.5,
                "owner": owner,
                "summary": "Needs follow-up with provider ops lead.",
            },
            counts,
        )

        compliance_audit = self._upsert(
            models.ComplianceAudit,
            {"title": "Q1 Pharmacy Compliance Audit"},
            {
                "audit_type": "Quarterly",
                "status": models.WorkflowStatus.IN_PROGRESS,
                "severity": models.SeverityLevel.MEDIUM,
                "owner": owner,
                "review_state": models.AuditReviewState.UNDER_REVIEW,
                "due_date": today + timedelta(days=7),
                "evidence_due_at": now + timedelta(days=3),
                "summary": "Standard Q1 operational compliance check.",
            },
            counts,
        )

        complaint = self._upsert(
            models.Complaint,
            {"ticket_number": "CMP-1001"},
            {
                "customer_name": "Grace Njeri",
                "channel": "phone",
                "status": models.WorkflowStatus.IN_PROGRESS,
                "sla_state": models.ComplaintSLAState.AT_RISK,
                "severity": models.SeverityLevel.HIGH,
                "owner": owner,
                "opened_at": now - timedelta(days=1),
                "sla_due_at": now + timedelta(hours=8),
                "summary": "Medicine delivery delay complaint.",
            },
            counts,
        )

        self._upsert(
            models.RiskFlag,
            {"name": "Repeated delay complaints in Nairobi CBD"},
            {
                "flag_type": "operational",
                "status": models.WorkflowStatus.IN_PROGRESS,
                "severity": models.SeverityLevel.HIGH,
                "subject_model": "CommandBooking",
                "subject_identifier": booking.reference,
                "owner": owner,
                "reason": "Threshold breached for delay complaints this week.",
            },
            counts,
        )

        supplier = self._upsert(
            models.Supplier,
            {"name": "MediSupply East Africa"},
            {
                "contact_person": "Rachel Mutua",
                "email": "supply.demo@gonepharm.local",
                "phone": "+254700000303",
                "status": models.WorkflowStatus.CONFIRMED,
                "rating": 4.6,
            },
            counts,
        )
        stock_item = self._upsert(
            models.StockItem,
            {"sku": "SKU-PARA-500"},
            {
                "name": "Paracetamol 500mg",
                "status": models.InventoryState.LOW_STOCK,
                "quantity": 45,
                "reorder_level": 100,
                "unit_price": 12.5,
                "supplier": supplier,
            },
            counts,
        )
        self._upsert(
            models.InventoryBatch,
            {"batch_code": "BAT-PARA-001"},
            {
                "stock_item": stock_item,
                "status": models.InventoryState.IN_STOCK,
                "quantity": 45,
                "received_on": today - timedelta(days=20),
                "expires_on": today + timedelta(days=120),
            },
            counts,
        )
        self._upsert(
            models.SaleRecord,
            {"sale_number": "SAL-1001"},
            {
                "item": stock_item,
                "status": models.WorkflowStatus.CONFIRMED,
                "quantity": 8,
                "total_amount": 100.0,
                "sold_at": now - timedelta(hours=6),
                "channel": "walk-in",
            },
            counts,
        )

        self._upsert(
            models.RevenueEntry,
            {"reference": "REV-1001"},
            {
                "source": "pharmacy_sale",
                "status": models.WorkflowStatus.CONFIRMED,
                "reconciliation_state": models.ReconciliationState.PENDING,
                "amount": 12500,
                "currency": "KES",
                "booked_at": now - timedelta(days=1),
            },
            counts,
        )
        self._upsert(
            models.PayoutRequest,
            {"reference": "PAY-1001"},
            {
                "beneficiary_name": "Dr. Amina Wanjiru",
                "status": models.PayoutState.PENDING_APPROVAL,
                "amount": 8200,
                "currency": "KES",
                "requested_at": now - timedelta(hours=10),
                "review_note": "Demo payout awaiting approval.",
            },
            counts,
        )
        self._upsert(
            models.Invoice,
            {"invoice_number": "INV-1001"},
            {
                "customer_name": "Acme Health Ltd",
                "status": models.WorkflowStatus.CONFIRMED,
                "collection_stage": models.CollectionStage.DUE,
                "amount": 42000,
                "currency": "KES",
                "issued_on": today - timedelta(days=10),
                "due_on": today + timedelta(days=4),
            },
            counts,
        )
        self._upsert(
            models.TransactionLog,
            {"transaction_id": "TXN-1001"},
            {
                "transaction_type": "card",
                "status": models.WorkflowStatus.CONFIRMED,
                "reconciliation_state": models.ReconciliationState.PENDING,
                "amount": 42000,
                "currency": "KES",
                "processed_at": now - timedelta(hours=3),
                "payload": {"gateway": "demo_gateway"},
            },
            counts,
        )
        self._upsert(
            models.ExecutiveKPI,
            {"metric_code": "KPI-NET-REV"},
            {
                "metric_name": "Net Revenue",
                "status": models.WorkflowStatus.CONFIRMED,
                "value": 1450000,
                "trend_delta": 5.20,
                "period_start": today.replace(day=1),
                "period_end": today,
                "owner": owner,
            },
            counts,
        )

        patient = self._upsert(
            models.PatientProfile,
            {"patient_code": "PAT-1001"},
            {
                "full_name": "Mary Atieno",
                "status": models.WorkflowStatus.CONFIRMED,
                "phone": "+254700000404",
                "email": "patient.demo@gonepharm.local",
                "preferred_language": "en",
            },
            counts,
        )
        patient_booking = self._upsert(
            models.PatientBooking,
            {"booking_ref": "PB-1001"},
            {
                "patient": patient,
                "status": models.WorkflowStatus.CONFIRMED,
                "service_type": "Teleconsultation",
                "channel": "web",
                "scheduled_for": now + timedelta(hours=2),
            },
            counts,
        )
        patient_consult = self._upsert(
            models.PatientConsultation,
            {"consultation_ref": "PC-1001"},
            {
                "patient": patient,
                "booking": patient_booking,
                "status": models.WorkflowStatus.IN_PROGRESS,
                "provider_name": provider.full_name,
                "subjective": "Fever and headache for 2 days.",
                "assessment": "Likely viral infection.",
                "plan": "Symptomatic management and hydration.",
            },
            counts,
        )
        patient_rx = self._upsert(
            models.PatientPrescription,
            {"rx_number": "RX-1001"},
            {
                "patient": patient,
                "consultation": patient_consult,
                "status": models.WorkflowStatus.CONFIRMED,
                "medication_name": "Paracetamol 500mg",
                "dosage": "1 tablet every 8 hours",
                "instructions": "Take after meals.",
                "delivery_status": models.WorkflowStatus.CONFIRMED,
            },
            counts,
        )
        patient_diag = self._upsert(
            models.PatientDiagnosticOrder,
            {"order_number": "PD-1001"},
            {
                "patient": patient,
                "consultation": patient_consult,
                "status": models.WorkflowStatus.IN_PROGRESS,
                "test_type": "Full Blood Count",
                "upload_url": "https://example.com/reports/pd-1001",
            },
            counts,
        )
        self._upsert(
            models.PatientRecordEvent,
            {"patient": patient, "source_model": "PatientConsultation", "source_identifier": patient_consult.consultation_ref},
            {
                "event_type": "consultation",
                "status": models.WorkflowStatus.CONFIRMED,
                "title": "Consultation logged",
                "details": "Consultation added during demo seed.",
                "occurred_at": now - timedelta(hours=1),
            },
            counts,
        )
        self._upsert(
            models.PatientSupportTicket,
            {"ticket_number": "PST-1001"},
            {
                "patient": patient,
                "status": models.WorkflowStatus.IN_PROGRESS,
                "severity": models.SeverityLevel.MEDIUM,
                "channel": "chat",
                "subject": "Need clarification on dosage timing",
                "message": "Please confirm if dosage should continue after 3 days.",
            },
            counts,
        )

        provider_profile = self._upsert(
            models.ProviderProfile,
            {"provider_code": "PRV-1001"},
            {
                "full_name": provider.full_name,
                "specialty": "General Practice",
                "status": models.WorkflowStatus.CONFIRMED,
                "phone": provider.phone,
                "email": provider.email,
                "license_number": "LIC-PRV-1001",
                "years_experience": 7,
                "payout_account": "BANK-ACC-1001",
            },
            counts,
        )
        provider_appt = self._upsert(
            models.ProviderAppointment,
            {"appointment_ref": "PA-1001"},
            {
                "provider": provider_profile,
                "patient": patient,
                "status": models.WorkflowStatus.CONFIRMED,
                "scheduled_for": now + timedelta(hours=2),
                "visit_reason": "Headache and fever",
            },
            counts,
        )
        provider_consult = self._upsert(
            models.ProviderConsultation,
            {"consultation_ref": "PVC-1001"},
            {
                "provider": provider_profile,
                "patient": patient,
                "appointment": provider_appt,
                "status": models.WorkflowStatus.IN_PROGRESS,
                "vitals": "Temp 37.8C, BP 120/80",
                "soap_notes": "Stable; monitor symptoms",
                "next_action": "Review in 48h",
            },
            counts,
        )
        self._upsert(
            models.ProviderPrescriptionTask,
            {"task_ref": "PPT-1001"},
            {
                "provider": provider_profile,
                "patient": patient,
                "consultation": provider_consult,
                "status": models.WorkflowStatus.DRAFT,
                "medication_summary": patient_rx.medication_name,
            },
            counts,
        )
        self._upsert(
            models.ProviderEarningsSnapshot,
            {"provider": provider_profile, "period_start": today - timedelta(days=30), "period_end": today},
            {
                "status": models.WorkflowStatus.CONFIRMED,
                "gross_amount": 98000,
                "fee_amount": 12000,
                "net_amount": 86000,
                "payout_state": models.PayoutState.PENDING_APPROVAL,
            },
            counts,
        )
        self._upsert(
            models.ProviderProtocol,
            {"protocol_code": "PROTO-TRIAGE-001"},
            {
                "title": "Primary Care Triage",
                "status": models.WorkflowStatus.CONFIRMED,
                "version": "v1",
                "category": "Clinical",
                "content": "Initial triage protocol for common outpatient symptoms.",
                "published_at": now - timedelta(days=7),
            },
            counts,
        )

        rider_profile = self._upsert(
            models.RiderProfile,
            {"rider_code": "RID-1001"},
            {
                "full_name": rider.full_name,
                "status": models.WorkflowStatus.CONFIRMED,
                "vehicle_type": rider.vehicle_type,
                "zone": rider.zone,
                "phone": rider.phone,
                "is_online": True,
            },
            counts,
        )
        rider_job = self._upsert(
            models.RiderJob,
            {"job_ref": "RJ-1001"},
            {
                "rider": rider_profile,
                "booking": booking,
                "status": models.WorkflowStatus.IN_PROGRESS,
                "severity": models.SeverityLevel.MEDIUM,
                "pickup_location": "GonePharm Central Store",
                "dropoff_location": "Kilimani, Nairobi",
                "sample_collected": True,
                "started_at": now - timedelta(minutes=45),
            },
            counts,
        )
        self._upsert(
            models.RiderHistoryEntry,
            {"rider": rider_profile, "job": rider_job, "title": "Job accepted and pickup started"},
            {
                "status": models.WorkflowStatus.CONFIRMED,
                "details": "Demo rider accepted job and moved to pickup point.",
                "occurred_at": now - timedelta(minutes=30),
            },
            counts,
        )
        self._upsert(
            models.RiderEarningsSnapshot,
            {"rider": rider_profile, "period_start": today - timedelta(days=30), "period_end": today},
            {
                "status": models.WorkflowStatus.CONFIRMED,
                "gross_amount": 43000,
                "bonus_amount": 3500,
                "net_amount": 46500,
                "payout_state": models.PayoutState.PENDING_APPROVAL,
            },
            counts,
        )

        self._upsert(
            models.TimelineEvent,
            {"title": "Booking confirmed", "related_identifier": booking.reference},
            {
                "module": "control_admin",
                "event_type": "booking",
                "status": booking.status,
                "description": "Demo booking confirmed and assigned.",
                "related_model": "CommandBooking",
                "actor": owner,
            },
            counts,
        )
        self._upsert(
            models.AuditEvent,
            {"action": "demo_seed", "model_label": "core.CommandBooking", "object_identifier": booking.reference},
            {
                "module": "control_admin",
                "severity": models.SeverityLevel.LOW,
                "actor": owner,
                "metadata": {"source": "seed_demo_data"},
                "message": "Demo seed data initialized.",
            },
            counts,
        )
        self._upsert(
            models.Attachment,
            {"title": "Complaint Evidence Placeholder", "related_identifier": complaint.ticket_number},
            {
                "module": "control_admin",
                "file_name": "evidence-placeholder.pdf",
                "file_url": "https://example.com/files/evidence-placeholder.pdf",
                "kind": models.AttachmentKind.EVIDENCE,
                "content_type": "application/pdf",
                "related_model": "Complaint",
                "complaint": complaint,
                "compliance_audit": compliance_audit,
                "uploaded_by": owner,
            },
            counts,
        )
        note = self._upsert(
            models.Note,
            {"title": "Demo operations note"},
            {
                "module": "control_admin",
                "body": "Initial note seeded for demo walkthrough.",
                "status": models.WorkflowStatus.DRAFT,
                "related_model": "CommandBooking",
                "related_identifier": booking.reference,
                "created_by": owner,
                "assigned_to": owner,
            },
            counts,
        )
        note.tags.add(tags["ops"], tags["finance"], tags["patient"])
        self._upsert(
            models.ActionQueueItem,
            {"action_type": "review_low_stock_item", "module": "control_admin"},
            {
                "status": models.WorkflowStatus.IDLE,
                "severity": models.SeverityLevel.MEDIUM,
                "priority": 2,
                "payload": {"sku": stock_item.sku, "quantity": stock_item.quantity},
                "due_at": now + timedelta(days=1),
                "assigned_to": owner,
            },
            counts,
        )

        self.stdout.write(
            self.style.SUCCESS(
                f"Demo data seed completed. Created: {counts['created']}, Existing: {counts['existing']}."
            )
        )
        self.stdout.write("Demo user password in use: " + password)

    def _seed_users(self, password, counts):
        user_model = get_user_model()
        users = {}
        for username, email, groups, is_staff in DEMO_USERS:
            user, created = user_model.objects.get_or_create(
                username=username,
                defaults={"email": email, "is_staff": is_staff, "is_superuser": username == "demo_superadmin"},
            )
            if created:
                counts["created"] += 1
            else:
                counts["existing"] += 1
            user.email = email
            user.is_staff = is_staff
            user.is_superuser = username == "demo_superadmin"
            user.set_password(password)
            user.save()
            for group_name in groups:
                group, _ = Group.objects.get_or_create(name=group_name)
                user.groups.add(group)
            users[username] = user
        return users

    def _upsert(self, model_class, lookup, defaults, counts):
        instance, created = model_class.objects.get_or_create(**lookup, defaults=defaults)
        if created:
            counts["created"] += 1
        else:
            counts["existing"] += 1
            dirty = False
            for key, value in defaults.items():
                if getattr(instance, key) != value:
                    setattr(instance, key, value)
                    dirty = True
            if dirty:
                instance.save()
        return instance
