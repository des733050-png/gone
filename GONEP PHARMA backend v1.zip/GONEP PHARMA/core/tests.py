from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.admin.sites import AdminSite
from django.core.management import call_command
from django.test import RequestFactory, TestCase

from core.admin import ComplaintAdmin, PayoutRequestAdmin, ProviderProfileAdmin, UserAdmin
from core.models import (
    CollectionStage,
    AuditEvent,
    CommandBooking,
    CommandProvider,
    ComplianceAudit,
    Complaint,
    InventoryBatch,
    InventoryState,
    PatientBooking,
    PatientProfile,
    ProviderAppointment,
    ProviderProfile,
    ReconciliationState,
    RiderJob,
    RiderProfile,
    PayoutRequest,
    RevenueEntry,
    SeverityLevel,
    StockItem,
    Supplier,
    TransactionLog,
    WorkflowStatus,
)


class WorkflowStatusTests(TestCase):
    def test_booking_defaults_to_draft(self):
        booking = CommandBooking.objects.create(
            reference="BK-0001",
            patient_name="Jane Doe",
        )
        self.assertEqual(booking.status, WorkflowStatus.DRAFT)

    def test_severity_default_is_low(self):
        booking = CommandBooking.objects.create(
            reference="BK-0002",
            patient_name="John Doe",
        )
        self.assertEqual(booking.severity, SeverityLevel.LOW)


class GroupBootstrapCommandTests(TestCase):
    def test_bootstrap_control_groups(self):
        call_command("bootstrap_control_groups")
        ops_group = Group.objects.get(name="control_ops_admin")
        compliance_group = Group.objects.get(name="control_compliance_admin")
        patient_group = Group.objects.get(name="patient_ops_admin")
        provider_group = Group.objects.get(name="provider_ops_admin")
        rider_group = Group.objects.get(name="rider_ops_admin")
        self.assertTrue(ops_group.permissions.filter(codename="view_commandbooking").exists())
        self.assertTrue(
            compliance_group.permissions.filter(codename="view_complaint").exists()
        )
        self.assertTrue(
            patient_group.permissions.filter(codename="view_patientprofile").exists()
        )
        self.assertTrue(
            provider_group.permissions.filter(codename="view_providerprofile").exists()
        )
        self.assertTrue(
            rider_group.permissions.filter(codename="view_riderprofile").exists()
        )
        self.assertTrue(Group.objects.filter(name="control_finance_admin").exists())
        self.assertTrue(Group.objects.filter(name="control_compliance_admin").exists())
        self.assertTrue(Group.objects.filter(name="support_admin").exists())


class CoreModelCreationTests(TestCase):
    def test_provider_and_booking_relations(self):
        provider = CommandProvider.objects.create(full_name="Dr. Alice")
        booking = CommandBooking.objects.create(
            reference="BK-0003",
            patient_name="Patient A",
            provider=provider,
        )
        self.assertEqual(booking.provider, provider)

    def test_payout_request_defaults(self):
        payout = PayoutRequest.objects.create(
            reference="PO-0001",
            beneficiary_name="Provider A",
        )
        self.assertEqual(payout.status, "draft")

    def test_audit_event_creation(self):
        event = AuditEvent.objects.create(
            action="transition_status",
            model_label="core.CommandBooking",
            object_identifier="BK-0001",
        )
        self.assertEqual(event.module, "control_admin")

    def test_compliance_defaults(self):
        audit = ComplianceAudit.objects.create(title="Audit A")
        complaint = Complaint.objects.create(
            ticket_number="CMP-0001",
            customer_name="Jane Customer",
        )
        self.assertEqual(audit.review_state, "pending")
        self.assertEqual(complaint.sla_state, "on_track")

    def test_commerce_defaults(self):
        supplier = Supplier.objects.create(name="Supplier A")
        stock = StockItem.objects.create(sku="SKU-01", name="Item A", supplier=supplier)
        batch = InventoryBatch.objects.create(stock_item=stock, batch_code="B-01")
        self.assertEqual(stock.status, InventoryState.IN_STOCK)
        self.assertEqual(batch.status, InventoryState.IN_STOCK)

    def test_finance_defaults(self):
        revenue = RevenueEntry.objects.create(reference="REV-01")
        payout = PayoutRequest.objects.create(
            reference="PO-0001",
            beneficiary_name="Provider A",
        )
        tx = TransactionLog.objects.create(transaction_id="TX-01")
        self.assertEqual(revenue.reconciliation_state, ReconciliationState.PENDING)
        self.assertEqual(payout.status, "draft")
        self.assertEqual(tx.reconciliation_state, ReconciliationState.PENDING)

    def test_invoice_collection_stage_default(self):
        from core.models import Invoice

        invoice = Invoice.objects.create(
            invoice_number="INV-01",
            customer_name="Client A",
        )
        self.assertEqual(invoice.collection_stage, CollectionStage.CURRENT)

    def test_patient_module_defaults(self):
        profile = PatientProfile.objects.create(
            patient_code="PT-0001",
            full_name="Patient One",
        )
        booking = PatientBooking.objects.create(
            booking_ref="PB-0001",
            patient=profile,
        )
        self.assertEqual(profile.status, WorkflowStatus.CONFIRMED)
        self.assertEqual(booking.status, WorkflowStatus.DRAFT)

    def test_provider_module_defaults(self):
        provider = ProviderProfile.objects.create(
            provider_code="PR-0001",
            full_name="Dr. Provider",
        )
        appointment = ProviderAppointment.objects.create(
            appointment_ref="AP-0001",
            provider=provider,
        )
        self.assertEqual(provider.status, WorkflowStatus.CONFIRMED)
        self.assertEqual(appointment.status, WorkflowStatus.DRAFT)

    def test_rider_module_defaults(self):
        rider = RiderProfile.objects.create(
            rider_code="RD-0001",
            full_name="Rider One",
        )
        job = RiderJob.objects.create(
            job_ref="RJ-0001",
            rider=rider,
        )
        self.assertEqual(rider.status, WorkflowStatus.CONFIRMED)
        self.assertEqual(job.status, WorkflowStatus.DRAFT)


class RoleAccessRegressionTests(TestCase):
    def setUp(self):
        call_command("bootstrap_control_groups")
        self.factory = RequestFactory()
        user_model = get_user_model()
        self.superuser = user_model.objects.create_superuser(
            username="super",
            email="super@example.com",
            password="pass12345",
        )
        self.provider_user = user_model.objects.create_user(
            username="provider_user",
            email="provider@example.com",
            password="pass12345",
            is_staff=True,
        )
        self.support_user = user_model.objects.create_user(
            username="support_user",
            email="support@example.com",
            password="pass12345",
            is_staff=True,
        )
        provider_group = Group.objects.get(name="provider_ops_admin")
        support_group = Group.objects.get(name="support_admin")
        self.provider_user.groups.add(provider_group)
        self.support_user.groups.add(support_group)
        self.site = AdminSite()

    def _request(self, user):
        request = self.factory.get("/admin/")
        request.user = user
        return request

    def test_provider_admin_access_is_group_scoped(self):
        admin_obj = ProviderProfileAdmin(ProviderProfile, self.site)
        self.assertTrue(admin_obj.has_module_permission(self._request(self.provider_user)))
        self.assertFalse(admin_obj.has_module_permission(self._request(self.support_user)))

    def test_user_admin_is_superuser_only(self):
        admin_obj = UserAdmin(get_user_model(), self.site)
        self.assertTrue(admin_obj.has_module_permission(self._request(self.superuser)))
        self.assertFalse(admin_obj.has_module_permission(self._request(self.provider_user)))

    def test_complaint_queryset_scoped_by_owner(self):
        complaint_admin = ComplaintAdmin(Complaint, self.site)
        owned = Complaint.objects.create(
            ticket_number="CMP-OWN",
            customer_name="Owned",
            owner=self.support_user,
        )
        Complaint.objects.create(
            ticket_number="CMP-OTHER",
            customer_name="Other",
            owner=self.superuser,
        )
        qs = complaint_admin.get_queryset(self._request(self.support_user))
        self.assertIn(owned, list(qs))
        self.assertEqual(qs.filter(ticket_number="CMP-OTHER").count(), 0)

    def test_payout_action_creates_audit_event(self):
        finance_user = get_user_model().objects.create_user(
            username="finance_user",
            email="finance@example.com",
            password="pass12345",
            is_staff=True,
        )
        finance_group = Group.objects.get(name="control_finance_admin")
        finance_user.groups.add(finance_group)
        payout = PayoutRequest.objects.create(
            reference="PO-AUDIT-1",
            beneficiary_name="Beneficiary",
        )
        admin_obj = PayoutRequestAdmin(PayoutRequest, self.site)
        admin_obj.message_user = lambda *args, **kwargs: None
        request = self._request(finance_user)
        admin_obj.approve_selected(request, PayoutRequest.objects.filter(pk=payout.pk))
        self.assertTrue(
            AuditEvent.objects.filter(action="approve_payout", module="finance").exists()
        )
