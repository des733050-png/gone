from __future__ import annotations

from django.conf import settings
from django.db import DatabaseError
from django.db.models import Count, Sum
from django.templatetags.static import static
from django.urls import reverse
from django.utils import timezone

from core import models


def _user_group_names(request):
    cached = getattr(request, "_unfold_group_names", None)
    if cached is not None:
        return cached

    user = getattr(request, "user", None)
    if not user or not user.is_authenticated:
        names = set()
    else:
        names = set(user.groups.values_list("name", flat=True))

    request._unfold_group_names = names
    return names


def _has_group(request, group_name):
    return group_name in _user_group_names(request)


def can_access_control_ops(request):
    return request.user.is_superuser or _has_group(request, "admin_user")


def can_access_control_compliance(request):
    return request.user.is_superuser or _has_group(request, "admin_user")


def can_access_control_finance(request):
    return request.user.is_superuser or _has_group(request, "admin_user")


def can_access_support(request):
    return request.user.is_superuser or _has_group(request, "admin_user")


def can_access_patient_ops(request):
    return request.user.is_superuser or _has_group(request, "patient_user")


def can_access_provider_ops(request):
    return request.user.is_superuser or _has_group(request, "provider_user")


def can_access_rider_ops(request):
    return request.user.is_superuser or _has_group(request, "rider_user")


def can_access_superuser_only(request):
    return request.user.is_superuser


def _role_key(request):
    cached = getattr(request, "_unfold_role_key", None)
    if cached is not None:
        return cached

    if request.user.is_superuser:
        role = "superuser"
    elif _has_group(request, "admin_user"):
        role = "admin_user"
    elif _has_group(request, "patient_user"):
        role = "patient_user"
    elif _has_group(request, "provider_user"):
        role = "provider_user"
    elif _has_group(request, "rider_user"):
        role = "rider_user"
    else:
        role = "unknown"

    request._unfold_role_key = role
    return role


def _can_access_nav_item(request, permission):
    if not permission:
        return True
    if callable(permission):
        return bool(permission(request))
    if isinstance(permission, str) and permission.startswith("core.unfold."):
        fn_name = permission.rsplit(".", 1)[-1]
        fn = globals().get(fn_name)
        if callable(fn):
            return bool(fn(request))
    return False


def _friendly_shortcut_title(title):
    titles = {
        "Executive KPIs": "Business Insights",
        "Prescription Queue": "Prescription Tasks",
        "Record Events": "Records",
    }
    return titles.get(title, title)


def _friendly_shortcut_hint(title):
    hints = {
        "Users": "Manage team accounts",
        "Groups": "Set role permissions",
        "Bookings": "Track and update requests",
        "Providers": "Manage provider roster",
        "Riders": "Manage rider operations",
        "Incidents": "Resolve active issues",
        "Performance": "Review service performance",
        "Audits": "Run compliance checks",
        "Complaints": "Handle support complaints",
        "Flags": "Review risk alerts",
        "Stock": "Monitor stock levels",
        "Inventory": "Manage inventory batches",
        "Sales": "Review sales records",
        "Suppliers": "Manage supplier directory",
        "Profiles": "View and edit profiles",
        "Consultations": "Track care sessions",
        "Prescriptions": "Manage medications",
        "Diagnostics": "Manage test requests",
        "Records": "Access care history",
        "Support": "Respond to support tickets",
        "Revenue": "Track incoming payments",
        "Payouts": "Manage payout approvals",
        "Invoices": "Create and review invoices",
        "Transactions": "Audit money movement",
        "Business Insights": "Review KPI snapshots",
        "Appointments": "Manage scheduled visits",
        "Prescription Tasks": "Process prescription queue",
        "Earnings": "Track earnings summary",
        "Protocols": "Review care protocols",
        "Jobs": "Manage delivery jobs",
        "History": "View activity history",
    }
    return hints.get(title, "Open this workspace")


def _dashboard_shortcuts(request):
    shortcuts = []
    seen_links = set()

    for group in sidebar_navigation(request):
        for item in group.get("items", []):
            if not _can_access_nav_item(request, item.get("permission")):
                continue
            if item.get("title") == "Dashboard":
                continue

            link = item.get("link")
            if not link or link in seen_links:
                continue

            title = _friendly_shortcut_title(item.get("title", ""))
            shortcuts.append(
                {
                    "title": title,
                    "icon": item.get("icon", "apps"),
                    "link": link,
                    "hint": _friendly_shortcut_hint(title),
                }
            )
            seen_links.add(link)

    return shortcuts


def _dashboard_config(request):
    role = _role_key(request)
    today = timezone.now().date()

    if role in {"superuser", "admin_user"}:
        revenue = models.RevenueEntry.objects.aggregate(total=Sum("amount")).get("total") or 0
        open_incidents = models.CommandIncident.objects.exclude(status="completed").count()
        open_queue = models.ActionQueueItem.objects.exclude(status="completed").count()
        total_bookings = models.CommandBooking.objects.count()
        status_matrix = (
            models.CommandBooking.objects.values("status")
            .annotate(total=Count("id"))
            .order_by("status")
        )
        return {
            "title": "GonePharm Command Center",
            "subtitle": "Role-based admin workflows with internal operational placeholders.",
            "tabs": [
                {"key": "dashboard", "label": "Dashboard"},
                {"key": "ops", "label": "Ops Queue"},
                {"key": "roles", "label": "Role View"},
            ],
            "kpis": [
                {"title": "Revenue Pipeline", "value": f"KES {revenue:,.2f}", "delta": f"{models.RevenueEntry.objects.count()} entries", "period": "All time"},
                {"title": "Open Incidents", "value": str(open_incidents), "delta": "Active ops risk queue", "period": "Current"},
                {"title": "Pending Action Queue", "value": str(open_queue), "delta": f"{total_bookings} total bookings", "period": "Current"},
            ],
            "show_matrix": True,
            "matrix_rows": [
                {
                    "day": item["status"].replace("_", " ").title(),
                    "total": item["total"],
                    "values": [min(1.0, item["total"] / 25)] * 6,
                }
                for item in status_matrix
            ]
            or [{"day": "No Data", "total": 0, "values": [0.0] * 6}],
        }
    if role == "patient_user":
        active_bookings = models.PatientBooking.objects.filter(status__in=["draft", "confirmed", "in_progress"]).count()
        active_consults = models.PatientConsultation.objects.filter(status="in_progress").count()
        open_support = models.PatientSupportTicket.objects.exclude(status__in=["completed", "cancelled"]).count()
        total_rx = models.PatientPrescription.objects.count()
        return {
            "title": "Patient Service Dashboard",
            "subtitle": "Track service requests, consultations, prescriptions, and support.",
            "tabs": [{"key": "dashboard", "label": "Dashboard"}],
            "kpis": [
                {"title": "Active Bookings", "value": str(active_bookings), "delta": "Current service requests", "period": "Current"},
                {"title": "Consultations In Progress", "value": str(active_consults), "delta": "Ongoing clinical review", "period": "Current"},
                {"title": "Open Support Tickets", "value": str(open_support), "delta": "Pending responses", "period": "Current"},
                {"title": "Total Prescriptions", "value": str(total_rx), "delta": "Issued records", "period": "All time"},
            ],
            "show_matrix": False,
            "matrix_rows": [],
        }
    if role == "provider_user":
        appt_today = models.ProviderAppointment.objects.filter(scheduled_for__date=today).count()
        consults = models.ProviderConsultation.objects.filter(status="in_progress").count()
        pending_tasks = models.ProviderPrescriptionTask.objects.filter(status__in=["draft", "in_progress"]).count()
        earnings = models.ProviderEarningsSnapshot.objects.count()
        return {
            "title": "Provider Operations Dashboard",
            "subtitle": "Manage appointments, consultations, prescription tasks, and earnings.",
            "tabs": [{"key": "dashboard", "label": "Dashboard"}],
            "kpis": [
                {"title": "Appointments Today", "value": str(appt_today), "delta": "Scheduled visits", "period": "Today"},
                {"title": "Consultations In Progress", "value": str(consults), "delta": "Active sessions", "period": "Current"},
                {"title": "Pending Prescription Tasks", "value": str(pending_tasks), "delta": "Awaiting sign-off", "period": "Current"},
                {"title": "Earnings Snapshots", "value": str(earnings), "delta": "Recorded periods", "period": "All time"},
            ],
            "show_matrix": False,
            "matrix_rows": [],
        }
    if role == "rider_user":
        active_jobs = models.RiderJob.objects.filter(status__in=["confirmed", "in_progress"]).count()
        completed_today = models.RiderJob.objects.filter(status="completed", completed_at__date=today).count()
        online_riders = models.RiderProfile.objects.filter(is_online=True).count()
        pending_payouts = models.RiderEarningsSnapshot.objects.filter(
            payout_state=models.PayoutState.PENDING_APPROVAL
        ).count()
        return {
            "title": "Rider Dispatch Dashboard",
            "subtitle": "Track dispatch workload, completions, and payout readiness.",
            "tabs": [{"key": "dashboard", "label": "Dashboard"}],
            "kpis": [
                {"title": "Active Jobs", "value": str(active_jobs), "delta": "Current dispatch load", "period": "Current"},
                {"title": "Completed Today", "value": str(completed_today), "delta": "Successful deliveries", "period": "Today"},
                {"title": "Online Riders", "value": str(online_riders), "delta": "Available for assignments", "period": "Live"},
                {"title": "Pending Payout Snapshots", "value": str(pending_payouts), "delta": "Awaiting payout review", "period": "Current"},
            ],
            "show_matrix": False,
            "matrix_rows": [],
        }
    return {
        "title": "GonePharm Dashboard",
        "subtitle": "Your workspace is being prepared.",
        "tabs": [{"key": "dashboard", "label": "Dashboard"}],
        "kpis": [],
        "show_matrix": False,
        "matrix_rows": [],
    }


def environment_label(request):
    return "STAGING" if settings.DEBUG else "PRODUCTION"


def environment_title_prefix(request):
    return "[STAGING]" if settings.DEBUG else "[PROD]"


def site_dropdown(request):
    return [
        {
            "title": "Control Dashboard",
            "icon": "dashboard",
            "link": reverse("admin:index"),
        },
        {
            "title": "Public Launcher",
            "icon": "language",
            "link": "/",
        },
    ]


def sidebar_navigation(request):
    role = _role_key(request)
    navigation = [
        {
            "title": "Control Admin",
            "separator": False,
            "items": [
                {
                    "title": "Dashboard",
                    "icon": "dashboard",
                    "link": reverse("admin:index"),
                    "permission": "core.unfold.can_access_superuser_only",
                },
                {
                    "title": "Users",
                    "icon": "person",
                    "link": reverse("admin:auth_user_changelist"),
                    "permission": "core.unfold.can_access_superuser_only",
                },
                {
                    "title": "Groups",
                    "icon": "groups",
                    "link": reverse("admin:auth_group_changelist"),
                    "permission": "core.unfold.can_access_superuser_only",
                },
            ],
        },
        {
            "title": "Ops",
            "collapsible": True,
            "items": [
                {
                    "title": "Bookings",
                    "icon": "event_available",
                    "link": reverse("admin:core_commandbooking_changelist"),
                    "permission": "core.unfold.can_access_control_ops",
                },
                {
                    "title": "Providers",
                    "icon": "local_hospital",
                    "link": reverse("admin:core_commandprovider_changelist"),
                    "permission": "core.unfold.can_access_control_ops",
                },
                {
                    "title": "Riders",
                    "icon": "two_wheeler",
                    "link": reverse("admin:core_commandrider_changelist"),
                    "permission": "core.unfold.can_access_control_ops",
                },
                {
                    "title": "Incidents",
                    "icon": "report_problem",
                    "link": reverse("admin:core_commandincident_changelist"),
                    "permission": "core.unfold.can_access_control_ops",
                },
                {
                    "title": "Performance",
                    "icon": "monitoring",
                    "link": reverse("admin:core_performanceflag_changelist"),
                    "permission": "core.unfold.can_access_control_ops",
                },
            ],
        },
        {
            "title": "Compliance",
            "collapsible": True,
            "items": [
                {
                    "title": "Audits",
                    "icon": "fact_check",
                    "link": reverse("admin:core_complianceaudit_changelist"),
                    "permission": "core.unfold.can_access_control_compliance",
                },
                {
                    "title": "Complaints",
                    "icon": "support_agent",
                    "link": reverse("admin:core_complaint_changelist"),
                    "permission": "core.unfold.can_access_control_compliance",
                },
                {
                    "title": "Flags",
                    "icon": "flag",
                    "link": reverse("admin:core_riskflag_changelist"),
                    "permission": "core.unfold.can_access_control_compliance",
                },
            ],
        },
        {
            "title": "Commerce",
            "collapsible": True,
            "items": [
                {
                    "title": "Stock",
                    "icon": "inventory_2",
                    "link": reverse("admin:core_stockitem_changelist"),
                    "permission": "core.unfold.can_access_support",
                },
                {
                    "title": "Inventory",
                    "icon": "warehouse",
                    "link": reverse("admin:core_inventorybatch_changelist"),
                    "permission": "core.unfold.can_access_support",
                },
                {
                    "title": "Sales",
                    "icon": "point_of_sale",
                    "link": reverse("admin:core_salerecord_changelist"),
                    "permission": "core.unfold.can_access_support",
                },
                {
                    "title": "Suppliers",
                    "icon": "local_shipping",
                    "link": reverse("admin:core_supplier_changelist"),
                    "permission": "core.unfold.can_access_support",
                },
            ],
        },
        {
            "title": "Patient",
            "collapsible": True,
            "items": [
                {
                    "title": "Profiles",
                    "icon": "badge",
                    "link": reverse("admin:core_patientprofile_changelist"),
                    "permission": "core.unfold.can_access_patient_ops",
                },
                {
                    "title": "Bookings",
                    "icon": "event_note",
                    "link": reverse("admin:core_patientbooking_changelist"),
                    "permission": "core.unfold.can_access_patient_ops",
                },
                {
                    "title": "Consultations",
                    "icon": "health_and_safety",
                    "link": reverse("admin:core_patientconsultation_changelist"),
                    "permission": "core.unfold.can_access_patient_ops",
                },
                {
                    "title": "Prescriptions",
                    "icon": "medication",
                    "link": reverse("admin:core_patientprescription_changelist"),
                    "permission": "core.unfold.can_access_patient_ops",
                },
                {
                    "title": "Diagnostics",
                    "icon": "biotech",
                    "link": reverse("admin:core_patientdiagnosticorder_changelist"),
                    "permission": "core.unfold.can_access_patient_ops",
                },
                {
                    "title": "Records",
                    "icon": "description",
                    "link": reverse("admin:core_patientrecordevent_changelist"),
                    "permission": "core.unfold.can_access_patient_ops",
                },
                {
                    "title": "Support",
                    "icon": "support_agent",
                    "link": reverse("admin:core_patientsupportticket_changelist"),
                    "permission": "core.unfold.can_access_patient_ops",
                },
            ],
        },
        {
            "title": "Finance",
            "collapsible": True,
            "items": [
                {
                    "title": "Revenue",
                    "icon": "payments",
                    "link": reverse("admin:core_revenueentry_changelist"),
                    "permission": "core.unfold.can_access_control_finance",
                },
                {
                    "title": "Payouts",
                    "icon": "account_balance_wallet",
                    "link": reverse("admin:core_payoutrequest_changelist"),
                    "permission": "core.unfold.can_access_control_finance",
                },
                {
                    "title": "Invoices",
                    "icon": "receipt_long",
                    "link": reverse("admin:core_invoice_changelist"),
                    "permission": "core.unfold.can_access_control_finance",
                },
                {
                    "title": "Transactions",
                    "icon": "swap_horiz",
                    "link": reverse("admin:core_transactionlog_changelist"),
                    "permission": "core.unfold.can_access_control_finance",
                },
                {
                    "title": "Executive KPIs",
                    "icon": "insights",
                    "link": reverse("admin:core_executivekpi_changelist"),
                    "permission": "core.unfold.can_access_control_finance",
                },
            ],
        },
        {
            "title": "Provider",
            "collapsible": True,
            "items": [
                {
                    "title": "Profiles",
                    "icon": "badge",
                    "link": reverse("admin:core_providerprofile_changelist"),
                    "permission": "core.unfold.can_access_provider_ops",
                },
                {
                    "title": "Appointments",
                    "icon": "event",
                    "link": reverse("admin:core_providerappointment_changelist"),
                    "permission": "core.unfold.can_access_provider_ops",
                },
                {
                    "title": "Consultations",
                    "icon": "health_and_safety",
                    "link": reverse("admin:core_providerconsultation_changelist"),
                    "permission": "core.unfold.can_access_provider_ops",
                },
                {
                    "title": "Prescription Queue",
                    "icon": "medication",
                    "link": reverse("admin:core_providerprescriptiontask_changelist"),
                    "permission": "core.unfold.can_access_provider_ops",
                },
                {
                    "title": "Earnings",
                    "icon": "payments",
                    "link": reverse("admin:core_providerearningssnapshot_changelist"),
                    "permission": "core.unfold.can_access_provider_ops",
                },
                {
                    "title": "Protocols",
                    "icon": "menu_book",
                    "link": reverse("admin:core_providerprotocol_changelist"),
                    "permission": "core.unfold.can_access_provider_ops",
                },
            ],
        },
        {
            "title": "Rider",
            "collapsible": True,
            "items": [
                {
                    "title": "Profiles",
                    "icon": "badge",
                    "link": reverse("admin:core_riderprofile_changelist"),
                    "permission": "core.unfold.can_access_rider_ops",
                },
                {
                    "title": "Jobs",
                    "icon": "local_shipping",
                    "link": reverse("admin:core_riderjob_changelist"),
                    "permission": "core.unfold.can_access_rider_ops",
                },
                {
                    "title": "History",
                    "icon": "history",
                    "link": reverse("admin:core_riderhistoryentry_changelist"),
                    "permission": "core.unfold.can_access_rider_ops",
                },
                {
                    "title": "Earnings",
                    "icon": "payments",
                    "link": reverse("admin:core_riderearningssnapshot_changelist"),
                    "permission": "core.unfold.can_access_rider_ops",
                },
            ],
        },
    ]

    # Keep module sections always expanded for non-admin roles.
    if role in {"patient_user", "provider_user", "rider_user"}:
        for group in navigation:
            if group.get("collapsible"):
                group["collapsible"] = False

    return navigation


def dashboard_callback(request, context):
    active_tab = request.GET.get("tab", "dashboard")
    try:
        dashboard = _dashboard_config(request)
    except DatabaseError:
        dashboard = {
            "title": "GonePharm Dashboard",
            "subtitle": "Data currently unavailable.",
            "tabs": [{"key": "dashboard", "label": "Dashboard"}],
            "kpis": [],
            "show_matrix": False,
            "matrix_rows": [],
        }

    context.update(
        {
            "dashboard_title": dashboard["title"],
            "dashboard_subtitle": dashboard["subtitle"],
            "dashboard_tabs": dashboard["tabs"],
            "active_tab": active_tab,
            "dashboard_kpis": dashboard["kpis"],
            "dashboard_show_performance_matrix": dashboard["show_matrix"],
            "dashboard_heatmap_rows": dashboard["matrix_rows"],
            "dashboard_columns": [
                "SLA",
                "Ops Load",
                "Risk",
                "Velocity",
                "Escalation",
                "Backlog",
            ],
            "dashboard_shortcuts": _dashboard_shortcuts(request),
            "dashboard_logo_placeholder": static("core/branding/logo-light.svg"),
        }
    )

    return context
