import csv

from django.contrib import admin, messages
from django.http import HttpResponse
from django.db.models import Q
from django.utils import timezone
from django.utils.html import format_html

from core.models import AuditEvent, PayoutState, SeverityLevel, WorkflowStatus


class TimeStampedAdminMixin:
    readonly_fields = ("created_at", "updated_at")


class SuperuserOnlyAdminMixin:
    def has_module_permission(self, request):
        return request.user.is_superuser

    def has_view_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_add_permission(self, request):
        return request.user.is_superuser

    def has_change_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser


class GroupScopedAdminMixin:
    required_groups = ()
    ownership_field = None
    group_aliases = {
        "control_ops_admin": "admin_user",
        "control_finance_admin": "admin_user",
        "control_compliance_admin": "admin_user",
        "support_admin": "admin_user",
        "patient_ops_admin": "patient_user",
        "provider_ops_admin": "provider_user",
        "rider_ops_admin": "rider_user",
    }

    def _has_group_access(self, request):
        if request.user.is_superuser:
            return True
        if not self.required_groups:
            return True
        normalized_groups = set(self.required_groups)
        normalized_groups.update(
            self.group_aliases.get(name) for name in self.required_groups
        )
        normalized_groups.discard(None)
        return request.user.groups.filter(name__in=normalized_groups).exists()

    def has_module_permission(self, request):
        return self._has_group_access(request)

    def has_view_permission(self, request, obj=None):
        return self._has_group_access(request)

    def has_add_permission(self, request):
        return self._has_group_access(request)

    def has_change_permission(self, request, obj=None):
        return self._has_group_access(request)

    def has_delete_permission(self, request, obj=None):
        return self._has_group_access(request)

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        if request.user.is_superuser or not self.ownership_field:
            return queryset
        if not self._has_group_access(request):
            return queryset.none()
        return queryset.filter(
            Q(**{self.ownership_field: request.user})
            | Q(**{f"{self.ownership_field}__isnull": True})
        )


class StatusBadgeMixin:
    @admin.display(description="Status")
    def status_badge(self, obj):
        value = getattr(obj, "status", "-")
        color_map = {
            "idle": "#64748B",
            "draft": "#0EA5E9",
            "confirmed": "#0284C7",
            "in_progress": "#D97706",
            "completed": "#059669",
            "cancelled": "#DC2626",
            "approved": "#059669",
            "paid": "#0EA5E9",
            "rejected": "#DC2626",
            "pending_approval": "#D97706",
        }
        color = color_map.get(value, "#64748B")
        label = value.replace("_", " ").title()
        return format_html(
            '<span style="background:{};color:white;padding:2px 8px;border-radius:9999px;font-size:12px;">{}</span>',
            color,
            label,
        )


class SafeAdminActionsMixin:
    actions = (
        "transition_to_in_progress",
        "transition_to_completed",
        "transition_to_cancelled",
        "assign_to_me",
        "export_selected",
    )

    @admin.action(description="Transition status to In Progress")
    def transition_to_in_progress(self, request, queryset):
        self._transition_status(request, queryset, WorkflowStatus.IN_PROGRESS)

    @admin.action(description="Transition status to Completed")
    def transition_to_completed(self, request, queryset):
        self._transition_status(request, queryset, WorkflowStatus.COMPLETED)

    @admin.action(description="Transition status to Cancelled")
    def transition_to_cancelled(self, request, queryset):
        self._transition_status(request, queryset, WorkflowStatus.CANCELLED)

    def _transition_status(self, request, queryset, status):
        if not hasattr(queryset.model, "status"):
            self.message_user(
                request, "Selected model has no status field.", level=messages.WARNING
            )
            return
        updated = queryset.update(status=status, updated_at=timezone.now())
        self.message_user(request, f"{updated} record(s) updated.")
        self._log_audit(
            request,
            queryset,
            action=f"transition_status:{status}",
            severity=SeverityLevel.MEDIUM,
            metadata={"updated_count": updated},
        )

    @admin.action(description="Assign selected to me")
    def assign_to_me(self, request, queryset):
        fields = {f.name for f in queryset.model._meta.fields}
        if "owner" in fields:
            updated = queryset.update(owner=request.user, updated_at=timezone.now())
        elif "assigned_to" in fields:
            updated = queryset.update(
                assigned_to=request.user, updated_at=timezone.now()
            )
        else:
            self.message_user(
                request,
                "Selected model has no owner/assigned_to field.",
                level=messages.WARNING,
            )
            return
        self.message_user(request, f"{updated} record(s) assigned.")
        self._log_audit(
            request,
            queryset,
            action="assign_to_me",
            severity=SeverityLevel.MEDIUM,
            metadata={"updated_count": updated},
        )

    @admin.action(description="Export selected as CSV")
    def export_selected(self, request, queryset):
        fields = [f.name for f in queryset.model._meta.fields]
        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = (
            f'attachment; filename="{queryset.model._meta.model_name}_export.csv"'
        )
        writer = csv.writer(response)
        writer.writerow(fields)
        for item in queryset:
            writer.writerow([getattr(item, field) for field in fields])
        self._log_audit(
            request,
            queryset,
            action="export_selected",
            severity=SeverityLevel.LOW,
            metadata={"export_count": queryset.count()},
        )
        return response

    def _log_audit(self, request, queryset, action, severity, metadata=None):
        metadata = metadata or {}
        AuditEvent.objects.create(
            module="admin_actions",
            action=action,
            severity=severity,
            actor=request.user if request.user.is_authenticated else None,
            model_label=queryset.model._meta.label,
            object_identifier=f"bulk:{queryset.count()}",
            metadata=metadata,
            message=f"Action {action} on {queryset.model._meta.label}",
        )


class PayoutActionMixin:
    actions = ("approve_selected", "reject_selected", "mark_paid")

    @admin.action(description="Approve selected payouts")
    def approve_selected(self, request, queryset):
        updated = queryset.update(
            status=PayoutState.APPROVED,
            approved_at=timezone.now(),
            approved_by=request.user,
            updated_at=timezone.now(),
        )
        self.message_user(request, f"{updated} payout(s) approved.")
        self._log_payout_audit(
            request,
            queryset,
            action="approve_payout",
            severity=SeverityLevel.HIGH,
            metadata={"updated_count": updated},
        )

    @admin.action(description="Reject selected payouts")
    def reject_selected(self, request, queryset):
        updated = queryset.update(status=PayoutState.REJECTED, updated_at=timezone.now())
        self.message_user(request, f"{updated} payout(s) rejected.")
        self._log_payout_audit(
            request,
            queryset,
            action="reject_payout",
            severity=SeverityLevel.HIGH,
            metadata={"updated_count": updated},
        )

    @admin.action(description="Mark selected payouts as paid")
    def mark_paid(self, request, queryset):
        updated = queryset.update(status=PayoutState.PAID, updated_at=timezone.now())
        self.message_user(request, f"{updated} payout(s) marked as paid.")
        self._log_payout_audit(
            request,
            queryset,
            action="mark_payout_paid",
            severity=SeverityLevel.CRITICAL,
            metadata={"updated_count": updated},
        )

    def _log_payout_audit(self, request, queryset, action, severity, metadata=None):
        metadata = metadata or {}
        AuditEvent.objects.create(
            module="finance",
            action=action,
            severity=severity,
            actor=request.user if request.user.is_authenticated else None,
            model_label=queryset.model._meta.label,
            object_identifier=f"bulk:{queryset.count()}",
            metadata=metadata,
            message=f"Finance payout action {action}",
        )
