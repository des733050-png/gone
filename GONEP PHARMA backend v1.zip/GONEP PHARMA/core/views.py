from django.shortcuts import render


def module_launcher(request):
    modules = [
        {
            "title": "Control Admin",
            "subtitle": "Operations, compliance, commerce, and finance workflows.",
            "icon": "admin_panel_settings",
            "href": "/admin/",
        },
        {
            "title": "Patient Module",
            "subtitle": "Patient profiles, bookings, consultations, records, and support.",
            "icon": "person",
            "href": "/admin/core/patientprofile/",
        },
        {
            "title": "Provider Module",
            "subtitle": "Provider profiles, appointments, consultations, prescriptions, earnings, protocols.",
            "icon": "local_hospital",
            "href": "/admin/core/providerprofile/",
        },
        {
            "title": "Rider Module",
            "subtitle": "Rider profiles, jobs, history, and earnings workflows.",
            "icon": "two_wheeler",
            "href": "/admin/core/riderprofile/",
        },
    ]
    return render(
        request,
        "public/index.html",
        {
            "modules": modules,
        },
    )
