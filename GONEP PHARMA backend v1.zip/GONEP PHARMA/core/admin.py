from datetime import datetime, time, timedelta

from django.contrib import admin
from django.contrib.auth.admin import GroupAdmin as BaseGroupAdmin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import Group, User
from django.db.models import F, Q
from django.utils import timezone

from unfold.admin import ModelAdmin
from unfold.forms import UserChangeForm, UserCreationForm

from core.admin_mixins import (
    GroupScopedAdminMixin,
    PayoutActionMixin,
    SafeAdminActionsMixin,
    StatusBadgeMixin,
    SuperuserOnlyAdminMixin,
    TimeStampedAdminMixin,
)
from core.models import (
    ActionQueueItem,
    Attachment,
    AuditReviewState,
    AuditEvent,
    CommandBooking,
    CommandIncident,
    CommandProvider,
    CommandRider,
    CollectionStage,
    Complaint,
    ComplaintSLAState,
    ComplianceAudit,
    ExecutiveKPI,
    InventoryBatch,
    InventoryState,
    Invoice,
    Note,
    PatientBooking,
    PatientConsultation,
    PatientDiagnosticOrder,
    PatientPrescription,
    PatientProfile,
    PatientRecordEvent,
    PatientSupportTicket,
    PerformanceFlag,
    PayoutRequest,
    ProviderAppointment,
    ProviderConsultation,
    ProviderEarningsSnapshot,
    ProviderPrescriptionTask,
    ProviderProfile,
    ProviderProtocol,
    RiderEarningsSnapshot,
    RiderHistoryEntry,
    RiderJob,
    RiderProfile,
    RevenueEntry,
    ReconciliationState,
    RiskFlag,
    SaleRecord,
    StockItem,
    Supplier,
    Tag,
    TimelineEvent,
    TransactionLog,
    WorkflowStatus,
)

for model in (User, Group):
    try:
        admin.site.unregister(model)
    except admin.sites.NotRegistered:
        pass


@admin.register(User)
class UserAdmin(SuperuserOnlyAdminMixin, BaseUserAdmin, ModelAdmin):
    form = UserChangeForm
    add_form = UserCreationForm


@admin.register(Group)
class GroupAdmin(SuperuserOnlyAdminMixin, BaseGroupAdmin, ModelAdmin):
    pass


@admin.register(Tag)
class TagAdmin(SuperuserOnlyAdminMixin, TimeStampedAdminMixin, ModelAdmin):
    list_display = ("name", "module", "slug", "color", "created_at")
    search_fields = ("name", "slug", "module")
    list_filter = ("module",)


@admin.register(AuditEvent)
class AuditEventAdmin(
    SuperuserOnlyAdminMixin, TimeStampedAdminMixin, StatusBadgeMixin, ModelAdmin
):
    list_display = (
        "action",
        "module",
        "model_label",
        "object_identifier",
        "severity",
        "actor",
        "created_at",
    )
    search_fields = ("action", "model_label", "object_identifier", "message")
    list_filter = ("module", "severity", "action")


@admin.register(TimelineEvent)
class TimelineEventAdmin(
    SuperuserOnlyAdminMixin, TimeStampedAdminMixin, StatusBadgeMixin, ModelAdmin
):
    list_display = (
        "title",
        "event_type",
        "module",
        "status_badge",
        "related_model",
        "related_identifier",
        "created_at",
    )
    search_fields = ("title", "event_type", "related_model", "related_identifier")
    list_filter = ("module", "status", "event_type")


@admin.register(Attachment)
class AttachmentAdmin(TimeStampedAdminMixin, GroupScopedAdminMixin, ModelAdmin):
    required_groups = (
        "control_compliance_admin",
        "support_admin",
        "patient_ops_admin",
        "provider_ops_admin",
        "rider_ops_admin",
    )
    list_display = (
        "title",
        "kind",
        "module",
        "file_name",
        "complaint",
        "compliance_audit",
        "related_model",
        "related_identifier",
        "uploaded_by",
        "created_at",
    )
    search_fields = ("title", "file_name", "related_model", "related_identifier")
    list_filter = ("module", "kind", "content_type")
    autocomplete_fields = ("uploaded_by", "complaint", "compliance_audit")


@admin.register(Note)
class NoteAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = (
        "control_ops_admin",
        "control_compliance_admin",
        "control_finance_admin",
        "support_admin",
        "patient_ops_admin",
        "provider_ops_admin",
        "rider_ops_admin",
    )
    ownership_field = "assigned_to"
    list_display = ("title", "module", "status_badge", "assigned_to", "created_at")
    search_fields = ("title", "body", "related_model", "related_identifier")
    list_filter = ("module", "status")
    filter_horizontal = ("tags",)


@admin.register(ActionQueueItem)
class ActionQueueItemAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = (
        "control_ops_admin",
        "control_compliance_admin",
        "control_finance_admin",
        "support_admin",
    )
    ownership_field = "assigned_to"
    list_display = (
        "action_type",
        "module",
        "status_badge",
        "severity",
        "priority",
        "assigned_to",
        "due_at",
    )
    search_fields = ("action_type", "module")
    list_filter = ("module", "status", "severity", "priority")


@admin.register(CommandProvider)
class CommandProviderAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_ops_admin",)
    list_display = (
        "full_name",
        "specialty",
        "status_badge",
        "availability_score",
        "phone",
        "email",
    )
    search_fields = ("full_name", "specialty", "phone", "email")
    list_filter = ("status", "specialty")
    filter_horizontal = ("tags",)


@admin.register(CommandRider)
class CommandRiderAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_ops_admin",)
    list_display = ("full_name", "vehicle_type", "zone", "status_badge", "phone")
    search_fields = ("full_name", "vehicle_type", "zone", "phone")
    list_filter = ("status", "vehicle_type", "zone")
    filter_horizontal = ("tags",)


@admin.register(CommandBooking)
class CommandBookingAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_ops_admin",)
    list_display = (
        "reference",
        "patient_name",
        "service_type",
        "status_badge",
        "severity",
        "provider",
        "rider",
        "scheduled_for",
    )
    search_fields = ("reference", "patient_name", "service_type")
    list_filter = ("status", "severity", "service_type")
    autocomplete_fields = ("provider", "rider")
    filter_horizontal = ("tags",)
    actions = SafeAdminActionsMixin.actions + (
        "confirm_selected_bookings",
        "start_selected_bookings",
        "complete_selected_bookings",
        "queue_selected_bookings",
    )

    def _run_booking_transition(self, request, queryset, target_status, allowed_from):
        updated = 0
        skipped = 0
        for booking in queryset:
            if booking.status in allowed_from:
                booking.status = target_status
                booking.save(update_fields=["status", "updated_at"])
                updated += 1
            else:
                skipped += 1
        self.message_user(
            request,
            f"{updated} booking(s) transitioned to {target_status}. Skipped: {skipped}.",
        )

    @admin.action(description="Confirm selected bookings")
    def confirm_selected_bookings(self, request, queryset):
        self._run_booking_transition(
            request,
            queryset,
            WorkflowStatus.CONFIRMED,
            {WorkflowStatus.DRAFT, WorkflowStatus.IDLE},
        )

    @admin.action(description="Start selected bookings")
    def start_selected_bookings(self, request, queryset):
        self._run_booking_transition(
            request,
            queryset,
            WorkflowStatus.IN_PROGRESS,
            {WorkflowStatus.CONFIRMED},
        )

    @admin.action(description="Complete selected bookings")
    def complete_selected_bookings(self, request, queryset):
        self._run_booking_transition(
            request,
            queryset,
            WorkflowStatus.COMPLETED,
            {WorkflowStatus.IN_PROGRESS},
        )

    @admin.action(description="Push selected bookings to action queue")
    def queue_selected_bookings(self, request, queryset):
        created = 0
        for booking in queryset:
            ActionQueueItem.objects.create(
                module="ops",
                action_type=f"booking_followup:{booking.reference}",
                status=WorkflowStatus.DRAFT,
                severity=booking.severity,
                assigned_to=request.user,
                payload={"booking_reference": booking.reference},
            )
            created += 1
        self.message_user(request, f"{created} queue item(s) created.")


@admin.register(CommandIncident)
class CommandIncidentAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_ops_admin",)
    ownership_field = "owner"
    list_display = (
        "title",
        "category",
        "status_badge",
        "severity",
        "booking",
        "owner",
        "resolved_at",
    )
    search_fields = ("title", "category", "details")
    list_filter = ("status", "severity", "category")
    autocomplete_fields = ("booking", "owner")
    actions = SafeAdminActionsMixin.actions + (
        "mark_resolved",
        "queue_selected_incidents",
    )

    @admin.action(description="Mark selected incidents resolved")
    def mark_resolved(self, request, queryset):
        updated = queryset.filter(status=WorkflowStatus.IN_PROGRESS).update(
            status=WorkflowStatus.COMPLETED, resolved_at=timezone.now()
        )
        self.message_user(request, f"{updated} incident(s) resolved.")

    @admin.action(description="Push selected incidents to action queue")
    def queue_selected_incidents(self, request, queryset):
        created = 0
        for incident in queryset:
            ActionQueueItem.objects.create(
                module="ops",
                action_type=f"incident_triage:{incident.id}",
                status=WorkflowStatus.DRAFT,
                severity=incident.severity,
                assigned_to=request.user,
                payload={"incident_title": incident.title},
            )
            created += 1
        self.message_user(request, f"{created} queue item(s) created.")


@admin.register(PerformanceFlag)
class PerformanceFlagAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_ops_admin",)
    ownership_field = "owner"
    list_display = (
        "title",
        "subject_type",
        "subject_identifier",
        "status_badge",
        "severity",
        "score",
        "owner",
    )
    search_fields = ("title", "subject_type", "subject_identifier", "summary")
    list_filter = ("status", "severity", "subject_type")
    autocomplete_fields = ("owner",)
    actions = SafeAdminActionsMixin.actions + ("queue_selected_flags",)

    @admin.action(description="Push selected performance flags to action queue")
    def queue_selected_flags(self, request, queryset):
        created = 0
        for flag in queryset:
            ActionQueueItem.objects.create(
                module="ops",
                action_type=f"performance_flag:{flag.id}",
                status=WorkflowStatus.DRAFT,
                severity=flag.severity,
                assigned_to=request.user,
                payload={"flag_title": flag.title},
            )
            created += 1
        self.message_user(request, f"{created} queue item(s) created.")


class ComplaintSLAFilter(admin.SimpleListFilter):
    title = "SLA bucket"
    parameter_name = "sla_bucket"

    def lookups(self, request, model_admin):
        return (
            ("overdue", "Overdue"),
            ("due_24h", "Due in 24h"),
            ("resolved", "Resolved"),
            ("on_track", "On Track"),
        )

    def queryset(self, request, queryset):
        now = timezone.now()
        value = self.value()
        if value == "overdue":
            return queryset.filter(sla_due_at__lt=now).exclude(
                sla_state=ComplaintSLAState.RESOLVED
            )
        if value == "due_24h":
            return queryset.filter(sla_due_at__gte=now, sla_due_at__lte=now + timedelta(hours=24)).exclude(
                sla_state=ComplaintSLAState.RESOLVED
            )
        if value == "resolved":
            return queryset.filter(sla_state=ComplaintSLAState.RESOLVED)
        if value == "on_track":
            return queryset.filter(sla_state=ComplaintSLAState.ON_TRACK)
        return queryset


class AuditDueFilter(admin.SimpleListFilter):
    title = "Audit due"
    parameter_name = "audit_due"

    def lookups(self, request, model_admin):
        return (("overdue", "Overdue"), ("due_7d", "Due in 7 days"), ("completed", "Completed"))

    def queryset(self, request, queryset):
        today = timezone.localdate()
        value = self.value()
        if value == "overdue":
            return queryset.filter(due_date__lt=today).exclude(
                review_state=AuditReviewState.APPROVED
            )
        if value == "due_7d":
            return queryset.filter(due_date__gte=today, due_date__lte=today + timedelta(days=7))
        if value == "completed":
            return queryset.filter(review_state=AuditReviewState.APPROVED)
        return queryset


class StockHealthFilter(admin.SimpleListFilter):
    title = "Stock health"
    parameter_name = "stock_health"

    def lookups(self, request, model_admin):
        return (
            ("out", "Out of stock"),
            ("low", "Low stock"),
            ("ok", "Healthy"),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == "out":
            return queryset.filter(quantity=0)
        if value == "low":
            return queryset.filter(quantity__gt=0, quantity__lte=F("reorder_level"))
        if value == "ok":
            return queryset.filter(quantity__gt=F("reorder_level"))
        return queryset


class BatchExpiryFilter(admin.SimpleListFilter):
    title = "Batch expiry"
    parameter_name = "batch_expiry"

    def lookups(self, request, model_admin):
        return (
            ("expired", "Expired"),
            ("expiring_30d", "Expiring in 30 days"),
            ("safe", "Safe"),
        )

    def queryset(self, request, queryset):
        today = timezone.localdate()
        value = self.value()
        if value == "expired":
            return queryset.filter(expires_on__lt=today)
        if value == "expiring_30d":
            return queryset.filter(
                expires_on__gte=today, expires_on__lte=today + timedelta(days=30)
            )
        if value == "safe":
            return queryset.filter(expires_on__gt=today + timedelta(days=30))
        return queryset


class InvoiceAgingFilter(admin.SimpleListFilter):
    title = "Invoice aging"
    parameter_name = "invoice_aging"

    def lookups(self, request, model_admin):
        return (
            ("current", "Current"),
            ("due_7d", "Due in 7 days"),
            ("overdue", "Overdue"),
        )

    def queryset(self, request, queryset):
        today = timezone.localdate()
        value = self.value()
        if value == "current":
            return queryset.filter(due_on__gt=today)
        if value == "due_7d":
            return queryset.filter(due_on__gte=today, due_on__lte=today + timedelta(days=7))
        if value == "overdue":
            return queryset.filter(due_on__lt=today).exclude(collection_stage=CollectionStage.PAID)
        return queryset


class ReconciliationFilter(admin.SimpleListFilter):
    title = "Reconciliation"
    parameter_name = "reconciliation"

    def lookups(self, request, model_admin):
        return (
            ("pending", "Pending"),
            ("reconciled", "Reconciled"),
            ("exception", "Exception"),
        )

    def queryset(self, request, queryset):
        value = self.value()
        if value == "pending":
            return queryset.filter(reconciliation_state=ReconciliationState.PENDING)
        if value == "reconciled":
            return queryset.filter(reconciliation_state=ReconciliationState.RECONCILED)
        if value == "exception":
            return queryset.filter(reconciliation_state=ReconciliationState.EXCEPTION)
        return queryset


@admin.register(ComplianceAudit)
class ComplianceAuditAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_compliance_admin",)
    ownership_field = "owner"
    list_display = (
        "title",
        "audit_type",
        "status_badge",
        "review_state",
        "severity",
        "owner",
        "due_date",
        "evidence_due_at",
    )
    search_fields = ("title", "audit_type", "summary")
    list_filter = ("status", "review_state", "severity", "audit_type", AuditDueFilter)
    autocomplete_fields = ("owner", "reviewed_by")
    actions = SafeAdminActionsMixin.actions + (
        "move_under_review",
        "request_evidence",
        "approve_review",
        "reject_review",
    )

    @admin.action(description="Move selected audits to under review")
    def move_under_review(self, request, queryset):
        updated = queryset.filter(
            Q(review_state=AuditReviewState.PENDING)
            | Q(review_state=AuditReviewState.EVIDENCE_REQUESTED)
        ).update(
            review_state=AuditReviewState.UNDER_REVIEW,
            status=WorkflowStatus.IN_PROGRESS,
            reviewed_by=request.user,
            reviewed_at=timezone.now(),
        )
        self.message_user(request, f"{updated} audit(s) moved to under review.")

    @admin.action(description="Request evidence for selected audits")
    def request_evidence(self, request, queryset):
        due = timezone.now() + timezone.timedelta(days=2)
        updated = queryset.exclude(review_state=AuditReviewState.APPROVED).update(
            review_state=AuditReviewState.EVIDENCE_REQUESTED,
            status=WorkflowStatus.IN_PROGRESS,
            evidence_due_at=due,
            reviewed_by=request.user,
            reviewed_at=timezone.now(),
        )
        self.message_user(request, f"{updated} audit(s) set to evidence requested.")

    @admin.action(description="Approve selected audits")
    def approve_review(self, request, queryset):
        now = timezone.now()
        updated = queryset.filter(review_state=AuditReviewState.UNDER_REVIEW).update(
            review_state=AuditReviewState.APPROVED,
            status=WorkflowStatus.COMPLETED,
            completed_at=now,
            reviewed_by=request.user,
            reviewed_at=now,
        )
        self.message_user(request, f"{updated} audit(s) approved.")

    @admin.action(description="Reject selected audits")
    def reject_review(self, request, queryset):
        updated = queryset.exclude(review_state=AuditReviewState.APPROVED).update(
            review_state=AuditReviewState.REJECTED,
            status=WorkflowStatus.CANCELLED,
            reviewed_by=request.user,
            reviewed_at=timezone.now(),
        )
        self.message_user(request, f"{updated} audit(s) rejected.")


@admin.register(Complaint)
class ComplaintAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_compliance_admin", "support_admin")
    ownership_field = "owner"
    list_display = (
        "ticket_number",
        "customer_name",
        "channel",
        "status_badge",
        "sla_state",
        "sla_due_at",
        "severity",
        "owner",
    )
    search_fields = ("ticket_number", "customer_name", "summary", "breach_reason")
    list_filter = ("status", "sla_state", "severity", "channel", ComplaintSLAFilter)
    autocomplete_fields = ("owner",)
    actions = SafeAdminActionsMixin.actions + (
        "mark_first_response",
        "mark_at_risk",
        "mark_breached",
        "resolve_complaints",
        "queue_sla_followup",
    )

    @admin.action(description="Mark first response on selected complaints")
    def mark_first_response(self, request, queryset):
        now = timezone.now()
        updated = queryset.filter(first_response_at__isnull=True).update(
            first_response_at=now
        )
        self.message_user(request, f"{updated} complaint(s) first response captured.")

    @admin.action(description="Mark selected complaints as at risk")
    def mark_at_risk(self, request, queryset):
        updated = queryset.exclude(sla_state=ComplaintSLAState.RESOLVED).update(
            sla_state=ComplaintSLAState.AT_RISK
        )
        self.message_user(request, f"{updated} complaint(s) marked at risk.")

    @admin.action(description="Mark selected complaints as breached")
    def mark_breached(self, request, queryset):
        updated = queryset.exclude(sla_state=ComplaintSLAState.RESOLVED).update(
            sla_state=ComplaintSLAState.BREACHED
        )
        self.message_user(request, f"{updated} complaint(s) marked breached.")

    @admin.action(description="Resolve selected complaints")
    def resolve_complaints(self, request, queryset):
        now = timezone.now()
        updated = queryset.exclude(status=WorkflowStatus.COMPLETED).update(
            status=WorkflowStatus.COMPLETED,
            sla_state=ComplaintSLAState.RESOLVED,
            resolved_at=now,
        )
        self.message_user(request, f"{updated} complaint(s) resolved.")

    @admin.action(description="Queue SLA follow-up for selected complaints")
    def queue_sla_followup(self, request, queryset):
        created = 0
        for complaint in queryset:
            ActionQueueItem.objects.create(
                module="compliance",
                action_type=f"complaint_sla:{complaint.ticket_number}",
                status=WorkflowStatus.DRAFT,
                severity=complaint.severity,
                assigned_to=request.user,
                due_at=complaint.sla_due_at,
                payload={"ticket_number": complaint.ticket_number},
            )
            created += 1
        self.message_user(request, f"{created} SLA follow-up queue item(s) created.")


@admin.register(RiskFlag)
class RiskFlagAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_compliance_admin",)
    ownership_field = "owner"
    list_display = (
        "name",
        "flag_type",
        "status_badge",
        "severity",
        "subject_model",
        "subject_identifier",
        "owner",
    )
    search_fields = ("name", "flag_type", "subject_model", "subject_identifier")
    list_filter = ("status", "severity", "flag_type")
    autocomplete_fields = ("owner",)


@admin.register(PatientProfile)
class PatientProfileAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("patient_ops_admin",)
    list_display = (
        "patient_code",
        "full_name",
        "status_badge",
        "phone",
        "email",
        "preferred_language",
    )
    search_fields = ("patient_code", "full_name", "phone", "email")
    list_filter = ("status", "preferred_language", "gender")


@admin.register(PatientBooking)
class PatientBookingAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("patient_ops_admin",)
    list_display = (
        "booking_ref",
        "patient",
        "service_type",
        "status_badge",
        "channel",
        "scheduled_for",
    )
    search_fields = ("booking_ref", "patient__patient_code", "patient__full_name")
    list_filter = ("status", "service_type", "channel")
    autocomplete_fields = ("patient",)
    actions = SafeAdminActionsMixin.actions + (
        "confirm_bookings",
        "start_bookings",
        "complete_bookings",
    )

    @admin.action(description="Confirm selected patient bookings")
    def confirm_bookings(self, request, queryset):
        updated = queryset.filter(
            status__in=[WorkflowStatus.DRAFT, WorkflowStatus.IDLE]
        ).update(status=WorkflowStatus.CONFIRMED)
        self.message_user(request, f"{updated} patient booking(s) confirmed.")

    @admin.action(description="Start selected patient bookings")
    def start_bookings(self, request, queryset):
        updated = queryset.filter(status=WorkflowStatus.CONFIRMED).update(
            status=WorkflowStatus.IN_PROGRESS
        )
        self.message_user(request, f"{updated} patient booking(s) moved to in progress.")

    @admin.action(description="Complete selected patient bookings")
    def complete_bookings(self, request, queryset):
        updated = queryset.filter(status=WorkflowStatus.IN_PROGRESS).update(
            status=WorkflowStatus.COMPLETED
        )
        self.message_user(request, f"{updated} patient booking(s) completed.")


@admin.register(PatientConsultation)
class PatientConsultationAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("patient_ops_admin",)
    list_display = (
        "consultation_ref",
        "patient",
        "booking",
        "provider_name",
        "status_badge",
        "consulted_at",
    )
    search_fields = ("consultation_ref", "patient__patient_code", "provider_name")
    list_filter = ("status", "provider_name")
    autocomplete_fields = ("patient", "booking")
    actions = SafeAdminActionsMixin.actions + ("add_to_record_timeline",)

    @admin.action(description="Add selected consultations to patient record timeline")
    def add_to_record_timeline(self, request, queryset):
        created = 0
        for consultation in queryset:
            PatientRecordEvent.objects.create(
                patient=consultation.patient,
                event_type="consultation",
                status=consultation.status,
                title=f"Consultation {consultation.consultation_ref}",
                source_model="PatientConsultation",
                source_identifier=consultation.consultation_ref,
                details=consultation.assessment,
                occurred_at=consultation.consulted_at,
            )
            created += 1
        self.message_user(request, f"{created} timeline event(s) created.")


@admin.register(PatientPrescription)
class PatientPrescriptionAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("patient_ops_admin",)
    list_display = (
        "rx_number",
        "patient",
        "consultation",
        "medication_name",
        "status_badge",
        "delivery_status",
        "issued_at",
    )
    search_fields = ("rx_number", "patient__patient_code", "medication_name")
    list_filter = ("status", "delivery_status")
    autocomplete_fields = ("patient", "consultation")
    actions = SafeAdminActionsMixin.actions + (
        "mark_delivery_in_progress",
        "mark_delivery_completed",
        "add_to_record_timeline",
    )

    @admin.action(description="Mark selected prescriptions delivery in progress")
    def mark_delivery_in_progress(self, request, queryset):
        updated = queryset.update(delivery_status=WorkflowStatus.IN_PROGRESS)
        self.message_user(request, f"{updated} prescription(s) set to delivery in progress.")

    @admin.action(description="Mark selected prescriptions delivered")
    def mark_delivery_completed(self, request, queryset):
        updated = queryset.update(delivery_status=WorkflowStatus.COMPLETED)
        self.message_user(request, f"{updated} prescription(s) marked delivered.")

    @admin.action(description="Add selected prescriptions to patient record timeline")
    def add_to_record_timeline(self, request, queryset):
        created = 0
        for rx in queryset:
            PatientRecordEvent.objects.create(
                patient=rx.patient,
                event_type="prescription",
                status=rx.status,
                title=f"Prescription {rx.rx_number}",
                source_model="PatientPrescription",
                source_identifier=rx.rx_number,
                details=rx.instructions,
                occurred_at=rx.issued_at,
            )
            created += 1
        self.message_user(request, f"{created} timeline event(s) created.")


@admin.register(PatientDiagnosticOrder)
class PatientDiagnosticOrderAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("patient_ops_admin",)
    list_display = (
        "order_number",
        "patient",
        "consultation",
        "test_type",
        "status_badge",
        "collected_at",
        "result_at",
    )
    search_fields = ("order_number", "patient__patient_code", "test_type")
    list_filter = ("status", "test_type")
    autocomplete_fields = ("patient", "consultation")
    actions = SafeAdminActionsMixin.actions + (
        "mark_sample_collected",
        "mark_results_ready",
        "add_to_record_timeline",
    )

    @admin.action(description="Mark selected diagnostics as sample collected")
    def mark_sample_collected(self, request, queryset):
        now = timezone.now()
        updated = queryset.update(
            status=WorkflowStatus.IN_PROGRESS,
            collected_at=now,
        )
        self.message_user(request, f"{updated} diagnostic order(s) marked sample collected.")

    @admin.action(description="Mark selected diagnostics results ready")
    def mark_results_ready(self, request, queryset):
        now = timezone.now()
        updated = queryset.update(
            status=WorkflowStatus.COMPLETED,
            result_at=now,
        )
        self.message_user(request, f"{updated} diagnostic order(s) marked result ready.")

    @admin.action(description="Add selected diagnostics to patient record timeline")
    def add_to_record_timeline(self, request, queryset):
        created = 0
        for order in queryset:
            PatientRecordEvent.objects.create(
                patient=order.patient,
                event_type="diagnostic",
                status=order.status,
                title=f"Diagnostic {order.order_number}",
                source_model="PatientDiagnosticOrder",
                source_identifier=order.order_number,
                details=order.result_summary,
                occurred_at=order.result_at or order.created_at,
            )
            created += 1
        self.message_user(request, f"{created} timeline event(s) created.")


@admin.register(PatientRecordEvent)
class PatientRecordEventAdmin(
    TimeStampedAdminMixin, StatusBadgeMixin, GroupScopedAdminMixin, ModelAdmin
):
    required_groups = ("patient_ops_admin",)
    list_display = (
        "patient",
        "event_type",
        "title",
        "status_badge",
        "source_model",
        "source_identifier",
        "occurred_at",
    )
    search_fields = ("patient__patient_code", "title", "source_identifier", "source_model")
    list_filter = ("status", "event_type", "source_model")
    autocomplete_fields = ("patient",)


@admin.register(PatientSupportTicket)
class PatientSupportTicketAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("patient_ops_admin", "support_admin")
    list_display = (
        "ticket_number",
        "patient",
        "subject",
        "status_badge",
        "severity",
        "channel",
        "resolved_at",
    )
    search_fields = ("ticket_number", "patient__patient_code", "subject")
    list_filter = ("status", "severity", "channel")
    autocomplete_fields = ("patient",)
    actions = SafeAdminActionsMixin.actions + (
        "resolve_tickets",
        "queue_support_followup",
    )

    @admin.action(description="Resolve selected support tickets")
    def resolve_tickets(self, request, queryset):
        now = timezone.now()
        updated = queryset.exclude(status=WorkflowStatus.COMPLETED).update(
            status=WorkflowStatus.COMPLETED, resolved_at=now
        )
        self.message_user(request, f"{updated} support ticket(s) resolved.")

    @admin.action(description="Queue support follow-up")
    def queue_support_followup(self, request, queryset):
        created = 0
        for ticket in queryset:
            ActionQueueItem.objects.create(
                module="patient",
                action_type=f"patient_support:{ticket.ticket_number}",
                status=WorkflowStatus.DRAFT,
                severity=ticket.severity,
                assigned_to=request.user,
                payload={"ticket_number": ticket.ticket_number},
            )
            created += 1
        self.message_user(request, f"{created} support follow-up queue item(s) created.")


@admin.register(ProviderProfile)
class ProviderProfileAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("provider_ops_admin",)
    list_display = (
        "provider_code",
        "full_name",
        "specialty",
        "status_badge",
        "phone",
        "email",
        "license_number",
    )
    search_fields = ("provider_code", "full_name", "specialty", "license_number")
    list_filter = ("status", "specialty")


@admin.register(ProviderAppointment)
class ProviderAppointmentAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("provider_ops_admin",)
    list_display = (
        "appointment_ref",
        "provider",
        "patient",
        "status_badge",
        "scheduled_for",
        "visit_reason",
    )
    search_fields = ("appointment_ref", "provider__provider_code", "patient__patient_code")
    list_filter = ("status", "scheduled_for")
    autocomplete_fields = ("provider", "patient")
    actions = SafeAdminActionsMixin.actions + (
        "confirm_appointments",
        "start_appointments",
        "complete_appointments",
    )

    @admin.action(description="Confirm selected provider appointments")
    def confirm_appointments(self, request, queryset):
        updated = queryset.filter(
            status__in=[WorkflowStatus.DRAFT, WorkflowStatus.IDLE]
        ).update(status=WorkflowStatus.CONFIRMED)
        self.message_user(request, f"{updated} appointment(s) confirmed.")

    @admin.action(description="Start selected provider appointments")
    def start_appointments(self, request, queryset):
        updated = queryset.filter(status=WorkflowStatus.CONFIRMED).update(
            status=WorkflowStatus.IN_PROGRESS
        )
        self.message_user(request, f"{updated} appointment(s) started.")

    @admin.action(description="Complete selected provider appointments")
    def complete_appointments(self, request, queryset):
        updated = queryset.filter(status=WorkflowStatus.IN_PROGRESS).update(
            status=WorkflowStatus.COMPLETED
        )
        self.message_user(request, f"{updated} appointment(s) completed.")


@admin.register(ProviderConsultation)
class ProviderConsultationAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("provider_ops_admin",)
    list_display = (
        "consultation_ref",
        "provider",
        "patient",
        "appointment",
        "status_badge",
        "consulted_at",
    )
    search_fields = (
        "consultation_ref",
        "provider__provider_code",
        "patient__patient_code",
        "next_action",
    )
    list_filter = ("status", "consulted_at")
    autocomplete_fields = ("provider", "patient", "appointment")
    actions = SafeAdminActionsMixin.actions + (
        "queue_consultation_followup",
    )

    @admin.action(description="Queue consultation follow-up")
    def queue_consultation_followup(self, request, queryset):
        created = 0
        for consultation in queryset:
            ActionQueueItem.objects.create(
                module="provider",
                action_type=f"provider_consult_followup:{consultation.consultation_ref}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={"consultation_ref": consultation.consultation_ref},
            )
            created += 1
        self.message_user(request, f"{created} follow-up queue item(s) created.")


@admin.register(ProviderPrescriptionTask)
class ProviderPrescriptionTaskAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("provider_ops_admin",)
    list_display = (
        "task_ref",
        "provider",
        "patient",
        "consultation",
        "status_badge",
        "signed_off_at",
        "sent_at",
    )
    search_fields = ("task_ref", "provider__provider_code", "patient__patient_code")
    list_filter = ("status", "signed_off_at", "sent_at")
    autocomplete_fields = ("provider", "patient", "consultation")
    actions = SafeAdminActionsMixin.actions + (
        "sign_off_tasks",
        "send_tasks",
    )

    @admin.action(description="Sign off selected prescription tasks")
    def sign_off_tasks(self, request, queryset):
        now = timezone.now()
        updated = queryset.filter(
            status__in=[WorkflowStatus.DRAFT, WorkflowStatus.CONFIRMED]
        ).update(
            status=WorkflowStatus.IN_PROGRESS,
            signed_off_at=now,
        )
        self.message_user(request, f"{updated} prescription task(s) signed off.")

    @admin.action(description="Mark selected prescription tasks as sent")
    def send_tasks(self, request, queryset):
        now = timezone.now()
        updated = queryset.filter(status=WorkflowStatus.IN_PROGRESS).update(
            status=WorkflowStatus.COMPLETED,
            sent_at=now,
        )
        self.message_user(request, f"{updated} prescription task(s) sent.")


@admin.register(ProviderEarningsSnapshot)
class ProviderEarningsSnapshotAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("provider_ops_admin",)
    list_display = (
        "provider",
        "status_badge",
        "period_start",
        "period_end",
        "gross_amount",
        "fee_amount",
        "net_amount",
        "payout_state",
    )
    search_fields = ("provider__provider_code", "provider__full_name")
    list_filter = ("status", "payout_state", "period_start", "period_end")
    autocomplete_fields = ("provider",)
    actions = SafeAdminActionsMixin.actions + ("queue_payout_snapshot",)

    @admin.action(description="Queue provider payout snapshot processing")
    def queue_payout_snapshot(self, request, queryset):
        created = 0
        for snapshot in queryset:
            ActionQueueItem.objects.create(
                module="provider",
                action_type=f"provider_payout_snapshot:{snapshot.id}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={"provider_code": snapshot.provider.provider_code},
            )
            created += 1
        self.message_user(request, f"{created} payout snapshot queue item(s) created.")


@admin.register(ProviderProtocol)
class ProviderProtocolAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("provider_ops_admin",)
    list_display = (
        "protocol_code",
        "title",
        "status_badge",
        "version",
        "category",
        "published_at",
    )
    search_fields = ("protocol_code", "title", "category")
    list_filter = ("status", "category", "published_at")


@admin.register(RiderProfile)
class RiderProfileAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("rider_ops_admin",)
    list_display = (
        "rider_code",
        "full_name",
        "status_badge",
        "vehicle_type",
        "zone",
        "phone",
        "is_online",
    )
    search_fields = ("rider_code", "full_name", "vehicle_type", "zone", "phone")
    list_filter = ("status", "vehicle_type", "zone", "is_online")
    actions = SafeAdminActionsMixin.actions + ("mark_online", "mark_offline")

    @admin.action(description="Mark selected riders online")
    def mark_online(self, request, queryset):
        updated = queryset.update(is_online=True, status=WorkflowStatus.CONFIRMED)
        self.message_user(request, f"{updated} rider(s) marked online.")

    @admin.action(description="Mark selected riders offline")
    def mark_offline(self, request, queryset):
        updated = queryset.update(is_online=False, status=WorkflowStatus.IDLE)
        self.message_user(request, f"{updated} rider(s) marked offline.")


@admin.register(RiderJob)
class RiderJobAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("rider_ops_admin",)
    list_display = (
        "job_ref",
        "rider",
        "booking",
        "status_badge",
        "severity",
        "sample_collected",
        "started_at",
        "completed_at",
    )
    search_fields = ("job_ref", "rider__rider_code", "pickup_location", "dropoff_location")
    list_filter = ("status", "severity", "sample_collected")
    autocomplete_fields = ("rider", "booking")
    actions = SafeAdminActionsMixin.actions + (
        "accept_jobs",
        "start_jobs",
        "complete_jobs",
        "cancel_jobs",
        "mark_sample_collected",
        "queue_dispatch_followup",
        "add_to_history",
    )

    @admin.action(description="Accept selected rider jobs")
    def accept_jobs(self, request, queryset):
        updated = queryset.filter(
            status__in=[WorkflowStatus.DRAFT, WorkflowStatus.IDLE]
        ).update(status=WorkflowStatus.CONFIRMED)
        self.message_user(request, f"{updated} rider job(s) accepted.")

    @admin.action(description="Start selected rider jobs")
    def start_jobs(self, request, queryset):
        now = timezone.now()
        updated = queryset.filter(status=WorkflowStatus.CONFIRMED).update(
            status=WorkflowStatus.IN_PROGRESS,
            started_at=now,
        )
        self.message_user(request, f"{updated} rider job(s) started.")

    @admin.action(description="Complete selected rider jobs")
    def complete_jobs(self, request, queryset):
        now = timezone.now()
        updated = queryset.filter(status=WorkflowStatus.IN_PROGRESS).update(
            status=WorkflowStatus.COMPLETED,
            completed_at=now,
        )
        self.message_user(request, f"{updated} rider job(s) completed.")

    @admin.action(description="Cancel selected rider jobs")
    def cancel_jobs(self, request, queryset):
        updated = queryset.exclude(status=WorkflowStatus.COMPLETED).update(
            status=WorkflowStatus.CANCELLED
        )
        self.message_user(request, f"{updated} rider job(s) cancelled.")

    @admin.action(description="Mark sample collected")
    def mark_sample_collected(self, request, queryset):
        updated = queryset.update(sample_collected=True)
        self.message_user(request, f"{updated} rider job(s) marked sample collected.")

    @admin.action(description="Queue dispatch follow-up")
    def queue_dispatch_followup(self, request, queryset):
        created = 0
        for job in queryset:
            ActionQueueItem.objects.create(
                module="rider",
                action_type=f"rider_dispatch_followup:{job.job_ref}",
                status=WorkflowStatus.DRAFT,
                severity=job.severity,
                assigned_to=request.user,
                payload={"job_ref": job.job_ref},
            )
            created += 1
        self.message_user(request, f"{created} dispatch follow-up queue item(s) created.")

    @admin.action(description="Write selected jobs to rider history")
    def add_to_history(self, request, queryset):
        created = 0
        for job in queryset:
            RiderHistoryEntry.objects.create(
                rider=job.rider,
                job=job,
                status=job.status,
                title=f"Job {job.job_ref}",
                details=f"Pickup: {job.pickup_location} | Dropoff: {job.dropoff_location}",
                occurred_at=job.completed_at or job.started_at or timezone.now(),
            )
            created += 1
        self.message_user(request, f"{created} rider history entry(ies) created.")


@admin.register(RiderHistoryEntry)
class RiderHistoryEntryAdmin(
    TimeStampedAdminMixin, StatusBadgeMixin, GroupScopedAdminMixin, ModelAdmin
):
    required_groups = ("rider_ops_admin",)
    list_display = (
        "rider",
        "job",
        "title",
        "status_badge",
        "occurred_at",
    )
    search_fields = ("rider__rider_code", "title", "job__job_ref")
    list_filter = ("status", "occurred_at")
    autocomplete_fields = ("rider", "job")


@admin.register(RiderEarningsSnapshot)
class RiderEarningsSnapshotAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("rider_ops_admin",)
    list_display = (
        "rider",
        "status_badge",
        "period_start",
        "period_end",
        "gross_amount",
        "bonus_amount",
        "net_amount",
        "payout_state",
    )
    search_fields = ("rider__rider_code", "rider__full_name")
    list_filter = ("status", "payout_state", "period_start", "period_end")
    autocomplete_fields = ("rider",)
    actions = SafeAdminActionsMixin.actions + ("queue_rider_payout",)

    @admin.action(description="Queue rider payout processing")
    def queue_rider_payout(self, request, queryset):
        created = 0
        for snapshot in queryset:
            ActionQueueItem.objects.create(
                module="rider",
                action_type=f"rider_payout:{snapshot.id}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={"rider_code": snapshot.rider.rider_code},
            )
            created += 1
        self.message_user(request, f"{created} rider payout queue item(s) created.")


@admin.register(Supplier)
class SupplierAdmin(
    TimeStampedAdminMixin, StatusBadgeMixin, GroupScopedAdminMixin, ModelAdmin
):
    required_groups = ("support_admin",)
    list_display = (
        "name",
        "contact_person",
        "status_badge",
        "phone",
        "email",
        "rating",
        "stock_items_count",
        "sales_volume",
    )
    search_fields = ("name", "contact_person", "phone", "email")
    list_filter = ("status",)
    actions = ("queue_supplier_review",)

    @admin.display(description="Stock items")
    def stock_items_count(self, obj):
        return obj.stock_items.count()

    @admin.display(description="Sales volume")
    def sales_volume(self, obj):
        return sum(item.sales.count() for item in obj.stock_items.all())

    @admin.action(description="Queue supplier performance review")
    def queue_supplier_review(self, request, queryset):
        created = 0
        for supplier in queryset:
            ActionQueueItem.objects.create(
                module="commerce",
                action_type=f"supplier_review:{supplier.name}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={"supplier": supplier.name},
            )
            created += 1
        self.message_user(request, f"{created} supplier review queue item(s) created.")


@admin.register(StockItem)
class StockItemAdmin(TimeStampedAdminMixin, GroupScopedAdminMixin, ModelAdmin):
    required_groups = ("support_admin",)
    list_display = (
        "sku",
        "name",
        "status",
        "quantity",
        "reorder_level",
        "supplier",
        "stock_health",
    )
    search_fields = ("sku", "name")
    list_filter = ("status", "supplier", StockHealthFilter)
    autocomplete_fields = ("supplier",)
    actions = (
        "mark_low_stock",
        "mark_out_of_stock",
        "queue_reorder",
    )

    @admin.display(description="Health")
    def stock_health(self, obj):
        if obj.quantity == 0:
            return "Out"
        if obj.quantity <= obj.reorder_level:
            return "Low"
        return "Healthy"

    @admin.action(description="Mark selected as low stock")
    def mark_low_stock(self, request, queryset):
        updated = queryset.update(status=InventoryState.LOW_STOCK)
        self.message_user(request, f"{updated} stock item(s) marked low stock.")

    @admin.action(description="Mark selected as out of stock")
    def mark_out_of_stock(self, request, queryset):
        updated = queryset.update(status=InventoryState.OUT_OF_STOCK, quantity=0)
        self.message_user(request, f"{updated} stock item(s) marked out of stock.")

    @admin.action(description="Queue reorder for selected stock items")
    def queue_reorder(self, request, queryset):
        created = 0
        for item in queryset:
            ActionQueueItem.objects.create(
                module="commerce",
                action_type=f"reorder_stock:{item.sku}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={
                    "sku": item.sku,
                    "current_quantity": item.quantity,
                    "reorder_level": item.reorder_level,
                },
            )
            created += 1
        self.message_user(request, f"{created} reorder queue item(s) created.")


@admin.register(InventoryBatch)
class InventoryBatchAdmin(TimeStampedAdminMixin, GroupScopedAdminMixin, ModelAdmin):
    required_groups = ("support_admin",)
    list_display = (
        "batch_code",
        "stock_item",
        "status",
        "quantity",
        "received_on",
        "expires_on",
        "expiry_bucket",
    )
    search_fields = ("batch_code", "stock_item__name", "stock_item__sku")
    list_filter = ("status", "received_on", "expires_on", BatchExpiryFilter)
    autocomplete_fields = ("stock_item",)
    actions = (
        "mark_expired_batches",
        "queue_expiring_batches",
    )

    @admin.display(description="Expiry")
    def expiry_bucket(self, obj):
        if not obj.expires_on:
            return "Unknown"
        today = timezone.localdate()
        if obj.expires_on < today:
            return "Expired"
        if obj.expires_on <= today + timedelta(days=30):
            return "Expiring <=30d"
        return "Safe"

    @admin.action(description="Mark selected batches as expired")
    def mark_expired_batches(self, request, queryset):
        updated = queryset.update(status=InventoryState.EXPIRED)
        self.message_user(request, f"{updated} batch(es) marked expired.")

    @admin.action(description="Queue follow-up for expiring batches")
    def queue_expiring_batches(self, request, queryset):
        created = 0
        today = timezone.localdate()
        for batch in queryset:
            if batch.expires_on and batch.expires_on <= today + timedelta(days=30):
                ActionQueueItem.objects.create(
                    module="commerce",
                    action_type=f"batch_expiry_followup:{batch.batch_code}",
                    status=WorkflowStatus.DRAFT,
                    assigned_to=request.user,
                    payload={
                        "batch_code": batch.batch_code,
                        "expires_on": batch.expires_on.isoformat(),
                    },
                )
                created += 1
        self.message_user(request, f"{created} expiring batch queue item(s) created.")


@admin.register(SaleRecord)
class SaleRecordAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("support_admin",)
    list_display = (
        "sale_number",
        "item",
        "status_badge",
        "quantity",
        "total_amount",
        "sold_at",
        "channel",
    )
    search_fields = ("sale_number", "channel", "item__name")
    list_filter = ("status", "channel", "sold_at")
    autocomplete_fields = ("item",)
    actions = SafeAdminActionsMixin.actions + ("queue_sales_reconciliation",)

    @admin.action(description="Queue sales reconciliation")
    def queue_sales_reconciliation(self, request, queryset):
        created = 0
        for sale in queryset:
            ActionQueueItem.objects.create(
                module="commerce",
                action_type=f"sales_reconcile:{sale.sale_number}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={"sale_number": sale.sale_number, "amount": str(sale.total_amount)},
            )
            created += 1
        self.message_user(
            request, f"{created} sales reconciliation queue item(s) created."
        )


@admin.register(RevenueEntry)
class RevenueEntryAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_finance_admin",)
    list_display = (
        "reference",
        "source",
        "status_badge",
        "reconciliation_state",
        "amount",
        "currency",
        "booked_at",
    )
    search_fields = ("reference", "source")
    list_filter = ("status", "reconciliation_state", "currency", "booked_at", ReconciliationFilter)
    autocomplete_fields = ("reconciled_by",)
    actions = SafeAdminActionsMixin.actions + (
        "mark_revenue_reconciled",
        "mark_revenue_exception",
        "queue_revenue_reconciliation_report",
    )

    @admin.action(description="Mark selected revenue entries reconciled")
    def mark_revenue_reconciled(self, request, queryset):
        now = timezone.now()
        updated = queryset.update(
            reconciliation_state=ReconciliationState.RECONCILED,
            reconciled_at=now,
            reconciled_by=request.user,
        )
        self.message_user(request, f"{updated} revenue entry(ies) marked reconciled.")

    @admin.action(description="Mark selected revenue entries as exceptions")
    def mark_revenue_exception(self, request, queryset):
        updated = queryset.update(reconciliation_state=ReconciliationState.EXCEPTION)
        self.message_user(request, f"{updated} revenue entry(ies) marked exception.")

    @admin.action(description="Queue finance reconciliation report")
    def queue_revenue_reconciliation_report(self, request, queryset):
        refs = list(queryset.values_list("reference", flat=True))
        ActionQueueItem.objects.create(
            module="finance",
            action_type="finance_reconciliation_report",
            status=WorkflowStatus.DRAFT,
            assigned_to=request.user,
            payload={"references": refs, "count": len(refs)},
        )
        self.message_user(request, "Finance reconciliation report queued.")


@admin.register(PayoutRequest)
class PayoutRequestAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    PayoutActionMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_finance_admin",)
    list_display = (
        "reference",
        "beneficiary_name",
        "status_badge",
        "amount",
        "currency",
        "requested_at",
        "approved_by",
    )
    search_fields = ("reference", "beneficiary_name")
    list_filter = ("status", "currency", "requested_at")
    autocomplete_fields = ("approved_by",)
    actions = PayoutActionMixin.actions + (
        "submit_for_approval",
        "queue_payout_review",
    )

    @admin.action(description="Submit selected payouts for approval")
    def submit_for_approval(self, request, queryset):
        updated = queryset.filter(status="draft").update(status="pending_approval")
        self.message_user(request, f"{updated} payout(s) submitted for approval.")

    @admin.action(description="Queue payout compliance review")
    def queue_payout_review(self, request, queryset):
        created = 0
        for payout in queryset:
            ActionQueueItem.objects.create(
                module="finance",
                action_type=f"payout_review:{payout.reference}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={"payout_reference": payout.reference, "amount": str(payout.amount)},
            )
            created += 1
        self.message_user(request, f"{created} payout review queue item(s) created.")


@admin.register(Invoice)
class InvoiceAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_finance_admin",)
    list_display = (
        "invoice_number",
        "customer_name",
        "status_badge",
        "collection_stage",
        "amount",
        "currency",
        "issued_on",
        "due_on",
    )
    search_fields = ("invoice_number", "customer_name")
    list_filter = ("status", "collection_stage", "currency", "issued_on", "due_on", InvoiceAgingFilter)
    actions = SafeAdminActionsMixin.actions + (
        "mark_due",
        "mark_overdue",
        "mark_paid",
        "queue_collection_followup",
    )

    @admin.action(description="Mark selected invoices as due")
    def mark_due(self, request, queryset):
        updated = queryset.exclude(collection_stage=CollectionStage.PAID).update(
            collection_stage=CollectionStage.DUE
        )
        self.message_user(request, f"{updated} invoice(s) marked due.")

    @admin.action(description="Mark selected invoices as overdue")
    def mark_overdue(self, request, queryset):
        updated = queryset.exclude(collection_stage=CollectionStage.PAID).update(
            collection_stage=CollectionStage.OVERDUE
        )
        self.message_user(request, f"{updated} invoice(s) marked overdue.")

    @admin.action(description="Mark selected invoices as paid")
    def mark_paid(self, request, queryset):
        today = timezone.localdate()
        updated = queryset.update(
            collection_stage=CollectionStage.PAID,
            status=WorkflowStatus.COMPLETED,
            paid_on=today,
        )
        self.message_user(request, f"{updated} invoice(s) marked paid.")

    @admin.action(description="Queue collection follow-up for selected invoices")
    def queue_collection_followup(self, request, queryset):
        created = 0
        for invoice in queryset:
            ActionQueueItem.objects.create(
                module="finance",
                action_type=f"invoice_collection:{invoice.invoice_number}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                due_at=timezone.make_aware(
                    datetime.combine(invoice.due_on or timezone.localdate(), time.min)
                )
                if invoice.due_on
                else None,
                payload={"invoice_number": invoice.invoice_number},
            )
            created += 1
        self.message_user(request, f"{created} collection follow-up queue item(s) created.")


@admin.register(TransactionLog)
class TransactionLogAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_finance_admin",)
    list_display = (
        "transaction_id",
        "transaction_type",
        "status_badge",
        "reconciliation_state",
        "amount",
        "currency",
        "processed_at",
    )
    search_fields = ("transaction_id", "transaction_type")
    list_filter = (
        "status",
        "transaction_type",
        "currency",
        "processed_at",
        "reconciliation_state",
        ReconciliationFilter,
    )
    autocomplete_fields = ("reconciled_by",)
    actions = SafeAdminActionsMixin.actions + (
        "mark_transactions_reconciled",
        "mark_transactions_exception",
        "queue_reconciliation_work",
    )

    @admin.action(description="Mark selected transactions reconciled")
    def mark_transactions_reconciled(self, request, queryset):
        now = timezone.now()
        updated = queryset.update(
            reconciliation_state=ReconciliationState.RECONCILED,
            reconciled_at=now,
            reconciled_by=request.user,
        )
        self.message_user(request, f"{updated} transaction(s) marked reconciled.")

    @admin.action(description="Mark selected transactions as exception")
    def mark_transactions_exception(self, request, queryset):
        updated = queryset.update(reconciliation_state=ReconciliationState.EXCEPTION)
        self.message_user(request, f"{updated} transaction(s) marked exception.")

    @admin.action(description="Queue transaction reconciliation work")
    def queue_reconciliation_work(self, request, queryset):
        created = 0
        for tx in queryset:
            ActionQueueItem.objects.create(
                module="finance",
                action_type=f"transaction_reconcile:{tx.transaction_id}",
                status=WorkflowStatus.DRAFT,
                assigned_to=request.user,
                payload={"transaction_id": tx.transaction_id},
            )
            created += 1
        self.message_user(request, f"{created} reconciliation queue item(s) created.")


@admin.register(ExecutiveKPI)
class ExecutiveKPIAdmin(
    TimeStampedAdminMixin,
    StatusBadgeMixin,
    SafeAdminActionsMixin,
    GroupScopedAdminMixin,
    ModelAdmin,
):
    required_groups = ("control_finance_admin",)
    list_display = (
        "metric_name",
        "metric_code",
        "status_badge",
        "value",
        "trend_delta",
        "period_start",
        "period_end",
        "owner",
    )
    search_fields = ("metric_name", "metric_code")
    list_filter = ("status", "period_start", "period_end")
    autocomplete_fields = ("owner",)
    actions = SafeAdminActionsMixin.actions + ("queue_kpi_refresh",)

    @admin.action(description="Queue KPI refresh from finance data")
    def queue_kpi_refresh(self, request, queryset):
        codes = list(queryset.values_list("metric_code", flat=True))
        ActionQueueItem.objects.create(
            module="finance",
            action_type="kpi_refresh",
            status=WorkflowStatus.DRAFT,
            assigned_to=request.user,
            payload={"metric_codes": codes, "count": len(codes)},
        )
        self.message_user(request, "KPI refresh queued.")
