(function () {
  "use strict";

  var activeModal = null;
  var lastFocusedElement = null;

  function getFocusableElements(container) {
    return container.querySelectorAll(
      'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])'
    );
  }

  function closeModal() {
    if (!activeModal) return;
    var toRemove = activeModal;
    document.removeEventListener("keydown", onKeyDown, true);
    activeModal = null;
    toRemove.remove();
    if (lastFocusedElement && typeof lastFocusedElement.focus === "function") {
      lastFocusedElement.focus();
    }
  }

  function onKeyDown(event) {
    if (!activeModal) return;
    if (event.key === "Escape") {
      event.preventDefault();
      closeModal();
      return;
    }
    if (event.key !== "Tab") return;

    var dialog = activeModal.querySelector('[role="dialog"]');
    if (!dialog) return;
    var focusables = getFocusableElements(dialog);
    if (!focusables.length) return;

    var first = focusables[0];
    var last = focusables[focusables.length - 1];
    var current = document.activeElement;

    if (event.shiftKey && current === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && current === last) {
      event.preventDefault();
      first.focus();
    }
  }

  function openModal(options) {
    closeModal();

    var cfg = options || {};
    var title = cfg.title || "Modal";
    var bodyHTML = cfg.bodyHTML || "";
    var footerHTML = cfg.footerHTML || "";

    var overlay = document.createElement("div");
    overlay.className = "modal-overlay";
    overlay.setAttribute("data-modal-overlay", "true");
    overlay.innerHTML =
      '<div class="modal" role="dialog" aria-modal="true" aria-labelledby="gonep-modal-title">' +
      '<header class="modal-header row between center">' +
      '<h2 id="gonep-modal-title">' +
      title +
      "</h2>" +
      '<button type="button" class="btn btn-ghost" data-modal-close aria-label="Close dialog">Close</button>' +
      "</header>" +
      '<div class="modal-body">' +
      bodyHTML +
      "</div>" +
      '<footer class="modal-footer row between center">' +
      (footerHTML || '<button type="button" class="btn btn-primary" data-modal-close>Done</button>') +
      "</footer>" +
      "</div>";

    overlay.addEventListener("click", function (event) {
      if (event.target === overlay || event.target.hasAttribute("data-modal-close")) {
        closeModal();
      }
    });

    lastFocusedElement = document.activeElement;
    document.body.appendChild(overlay);
    activeModal = overlay;
    document.addEventListener("keydown", onKeyDown, true);

    var dialog = overlay.querySelector('[role="dialog"]');
    var focusables = getFocusableElements(dialog);
    if (focusables.length) focusables[0].focus();
  }

  window.GonepModal = {
    openModal: openModal,
    closeModal: closeModal,
  };
})();
