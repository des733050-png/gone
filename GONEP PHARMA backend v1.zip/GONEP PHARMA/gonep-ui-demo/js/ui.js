(function () {
  "use strict";

  function e(v) {
    return String(v == null ? "" : v)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function renderTopbar(options) {
    var c = options || {};
    return (
      '<div class="app-topbar">' +
      "<div>" +
      '<div class="topbar-title">' + e(c.title || "Page") + "</div>" +
      '<div class="topbar-subtitle">' + e(c.subtitle || "") + "</div>" +
      "</div>" +
      '<div class="row wrap center">' +
      (c.badge ? '<span class="badge badge-info">' + e(c.badge) + "</span>" : "") +
      (c.actionsHtml || "") +
      '<a class="btn btn-outline" href="' + e(c.backHref || "../index.html") + '">Main Index</a>' +
      "</div>" +
      "</div>"
    );
  }

  function renderCard(title, bodyHTML, footerHTML) {
    return (
      '<section class="card stack-sm">' +
      (title ? "<h3>" + e(title) + "</h3>" : "") +
      (bodyHTML || "") +
      (footerHTML ? "<div>" + footerHTML + "</div>" : "") +
      "</section>"
    );
  }

  function renderBadge(text, variant) {
    return '<span class="badge badge-' + e(variant || "default") + '">' + e(text) + "</span>";
  }

  function renderTable(cols, rows) {
    var head =
      "<thead><tr>" +
      cols
        .map(function (c) {
          return "<th>" + e(c.label || c.key || "") + "</th>";
        })
        .join("") +
      "</tr></thead>";
    var body =
      "<tbody>" +
      rows
        .map(function (r) {
          return (
            "<tr>" +
            cols
              .map(function (c) {
                return "<td>" + (r[c.key] == null ? "" : r[c.key]) + "</td>";
              })
              .join("") +
            "</tr>"
          );
        })
        .join("") +
      "</tbody>";
    return '<div class="table-wrap"><table>' + head + body + "</table></div>";
  }

  function renderTabs(items, active) {
    return (
      '<div class="tabs">' +
      items
        .map(function (i) {
          var cls = i.id === active ? " active" : "";
          return '<button class="tab-btn' + cls + '" data-tab="' + e(i.id) + '" type="button">' + e(i.label) + "</button>";
        })
        .join("") +
      "</div>"
    );
  }

  function renderKpiRow(items) {
    return (
      '<section class="kpi-grid">' +
      items
        .map(function (i) {
          return '<article class="card"><p class="muted">' + e(i.label) + "</p><h3>" + e(i.value) + "</h3></article>";
        })
        .join("") +
      "</section>"
    );
  }

  function renderEmptyState(title, description, actionHTML) {
    return (
      '<section class="empty-state">' +
      "<h3>" + e(title) + "</h3>" +
      '<p class="muted mt-2">' + e(description) + "</p>" +
      (actionHTML ? '<div class="mt-3">' + actionHTML + "</div>" : "") +
      "</section>"
    );
  }

  function renderFooter() {
    return '<p class="footer-note">Frontend-only preview. Actions are simulated with local state.</p>';
  }

  window.GonepUI = {
    renderTopbar: renderTopbar,
    renderCard: renderCard,
    renderBadge: renderBadge,
    renderTable: renderTable,
    renderTabs: renderTabs,
    renderKpiRow: renderKpiRow,
    renderEmptyState: renderEmptyState,
    renderFooter: renderFooter,
  };
})();
