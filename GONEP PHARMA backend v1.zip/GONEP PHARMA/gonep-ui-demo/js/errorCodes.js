(function () {
  "use strict";

  var codes = {
    "GONEP-E-INIT-001": {
      title: "Module runtime unavailable",
      description: "Page runtime script failed to initialize.",
      fix: "Refresh the page and verify pageRuntime.js and pageRegistry.js are loading.",
    },
    "GONEP-E-STATE-001": {
      title: "State initialization failure",
      description: "State provider could not initialize from storage.",
      fix: "Reset storage from Main Index or clear browser site data.",
    },
    "GONEP-E-PAGE-001": {
      title: "Page definition missing",
      description: "Requested module/page definition could not be found.",
      fix: "Check page registry mapping and page definition files.",
    },
    "GONEP-E-RENDER-001": {
      title: "Page render failure",
      description: "Page definition threw an exception while rendering.",
      fix: "Inspect browser console and update the failing page renderer.",
    },
    "GONEP-E-ACTION-001": {
      title: "Action handler failure",
      description: "A button action failed during execution.",
      fix: "Inspect action attributes and state update paths.",
    },
    "GONEP-E-DEPS-001": {
      title: "Required dependency missing",
      description: "One or more required runtime dependencies were not available.",
      fix: "Verify script load order and failed network script requests.",
    },
  };

  function esc(value) {
    return String(value == null ? "" : value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function resolve(code) {
    return (
      codes[code] || {
        title: "Unknown runtime error",
        description: "An unexpected runtime error occurred.",
        fix: "Check console output and runtime logs.",
      }
    );
  }

  function record(code, details) {
    var payload = {
      code: code,
      details: details || "",
      path: window.location.pathname,
      at: new Date().toISOString(),
    };
    try {
      var key = "gonep_errors";
      var currentRaw = sessionStorage.getItem(key);
      var current = currentRaw ? JSON.parse(currentRaw) : [];
      current.unshift(payload);
      sessionStorage.setItem(key, JSON.stringify(current.slice(0, 30)));
    } catch (error) {
      // no-op fallback if session storage is blocked
    }
    return payload;
  }

  function getErrorHost() {
    return document.getElementById("page-content") || document.querySelector("main") || document.body;
  }

  function renderPageError(code, details) {
    var meta = resolve(code);
    record(code, details);
    var host = getErrorHost();
    if (!host) return;

    host.innerHTML =
      '<section class="card stack-sm">' +
      '<span class="badge badge-danger">' +
      esc(code) +
      "</span>" +
      "<h3>" +
      esc(meta.title) +
      "</h3>" +
      "<p>" +
      esc(meta.description) +
      "</p>" +
      '<p class="muted"><strong>Fix:</strong> ' +
      esc(meta.fix) +
      "</p>" +
      (details ? '<p class="muted"><strong>Details:</strong> ' + esc(details) + "</p>" : "") +
      '<div class="row wrap"><a class="btn btn-outline" href="../index.html">Back to Main Index</a><button type="button" class="btn btn-primary" data-error-reload>Reload Page</button></div>' +
      "</section>";

    var reloadBtn = host.querySelector("[data-error-reload]");
    if (reloadBtn) {
      reloadBtn.addEventListener("click", function () {
        window.location.reload();
      });
    }
  }

  window.GonepErrorCodes = {
    codes: codes,
    resolve: resolve,
    record: record,
    renderPageError: renderPageError,
  };
})();
