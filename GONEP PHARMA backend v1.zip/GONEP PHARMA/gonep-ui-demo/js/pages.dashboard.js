(function () {
  "use strict";

  var s = window.GonepPageShared;

  function buildCommandPage(configKey, cfg, ctx) {
    var rows = cfg.rows ? cfg.rows(ctx) : [];
    var kpis = cfg.kpis ? cfg.kpis(ctx) : [];
    return (
      (kpis.length ? window.GonepUI.renderKpiRow(kpis) : "") +
      s.card(cfg.sectionTitle || "Overview", s.table(cfg.columns, rows)) +
      s.card("Actions", s.renderActions(cfg.actions || [{ label: "Refresh", flowPage: configKey, flowStatus: "in_progress", toast: "View refreshed." }]))
    );
  }

  var configs = {
    dashboard: {
      title: "Command Dashboard Home",
      subtitle: "Operational control center across bookings, providers, riders, finance, and governance.",
      render: function (ctx) {
        var counts = ctx.data.getActiveCounts ? ctx.data.getActiveCounts() : { bookings: 0, providers: 0, riders: 0 };
        return (
          window.GonepUI.renderKpiRow([
            { label: "Bookings", value: String(counts.bookings) },
            { label: "Providers Online", value: String(counts.providers) },
            { label: "Riders Online", value: String(counts.riders) },
            { label: "Revenue Today", value: s.formatCurrency(6200) },
            { label: "Stock Alerts", value: "2" },
            { label: "Open Complaints", value: String((ctx.data.complaints || []).length) },
          ]) +
          s.card(
            "Quick Navigation",
            s.renderActions([
              { label: "Bookings", href: "./bookings.html" },
              { label: "Providers", href: "./providers.html", className: "btn-outline" },
              { label: "Riders", href: "./riders.html", className: "btn-outline" },
              { label: "Incidents", href: "./incidents.html", className: "btn-outline" },
              { label: "Revenue", href: "./revenue.html", className: "btn-outline" },
              { label: "Executive", href: "./executive.html", className: "btn-outline" },
            ])
          )
        );
      },
    },
    bookings: {
      title: "Dashboard Bookings",
      subtitle: "Queue, urgency, status monitoring, and assignment overview.",
      columns: [
        { key: "id", label: "Booking" },
        { key: "patient", label: "Patient" },
        { key: "service", label: "Service" },
        { key: "status", label: "Status" },
        { key: "assigned", label: "Assigned" },
      ],
      rows: function (ctx) {
        return (ctx.data.bookings || []).map(function (b) {
          return {
            id: s.esc(b.id),
            patient: s.esc(b.patientName),
            service: s.esc(b.serviceType),
            status: s.statusBadge(b.status),
            assigned: s.esc(b.providerName) + " / " + s.esc(b.riderName),
          };
        });
      },
      actions: [{ label: "Refresh Queue", flowPage: "bookings", flowStatus: "in_progress", toast: "Booking queue refreshed." }],
    },
    providers: {
      title: "Dashboard Providers",
      subtitle: "Provider roster, availability, and active assignments.",
      columns: [
        { key: "id", label: "Provider ID" },
        { key: "name", label: "Name" },
        { key: "speciality", label: "Speciality" },
        { key: "status", label: "Status" },
      ],
      rows: function (ctx) {
        return (ctx.data.providers || []).map(function (p) {
          return { id: s.esc(p.id), name: s.esc(p.name), speciality: s.esc(p.specialisation), status: s.statusBadge(p.online ? "online" : "offline") };
        });
      },
      actions: [{ label: "Set Roster Synced", flowPage: "providers", flowStatus: "completed", toast: "Provider roster synced." }],
    },
    riders: {
      title: "Dashboard Riders",
      subtitle: "Dispatch board with rider status and active delivery context.",
      columns: [
        { key: "id", label: "Rider ID" },
        { key: "name", label: "Name" },
        { key: "status", label: "Status" },
        { key: "activity", label: "Activity" },
      ],
      rows: function (ctx) {
        return (ctx.data.riders || []).map(function (r) {
          return { id: s.esc(r.id), name: s.esc(r.name), status: s.statusBadge(r.online ? "online" : "offline"), activity: s.esc(r.active ? "On Delivery" : "Idle") };
        });
      },
      actions: [{ label: "Update Dispatch State", flowPage: "riders", flowStatus: "in_progress", toast: "Dispatch status updated." }],
    },
    incidents: {
      title: "Dashboard Incidents",
      subtitle: "Incident logging, severity, and escalation tracking.",
      columns: [
        { key: "id", label: "Incident ID" },
        { key: "severity", label: "Severity" },
        { key: "subject", label: "Subject" },
        { key: "status", label: "Status" },
      ],
      rows: function () {
        return [
          { id: "INC-001", severity: s.statusBadge("warning"), subject: "Delayed rider handoff", status: s.statusBadge("in_review") },
          { id: "INC-002", severity: s.statusBadge("danger"), subject: "Stock mismatch at dispatch", status: s.statusBadge("open") },
        ];
      },
      actions: [{ label: "Log Incident", flowPage: "incidents", flowStatus: "confirmed", toast: "Incident logged." }],
    },
    performance: {
      title: "Dashboard Performance",
      subtitle: "Provider performance metrics and quality thresholds.",
      columns: [
        { key: "provider", label: "Provider" },
        { key: "consults", label: "Consultations" },
        { key: "rating", label: "Rating" },
        { key: "flag", label: "Performance Flag" },
      ],
      rows: function (ctx) {
        return (ctx.data.providers || []).map(function (p, idx) {
          return { provider: s.esc(p.name), consults: String(12 + idx * 4), rating: String(p.rating), flag: s.statusBadge(p.rating < 4.7 ? "warning" : "completed") };
        });
      },
      actions: [{ label: "Publish Snapshot", flowPage: "performance", flowStatus: "completed", toast: "Performance snapshot published." }],
    },
    audits: {
      title: "Dashboard Audits",
      subtitle: "Consultation audit queue and review state tracking.",
      columns: [
        { key: "audit", label: "Audit ID" },
        { key: "booking", label: "Booking" },
        { key: "owner", label: "Owner" },
        { key: "status", label: "Status" },
      ],
      rows: function (ctx) {
        return (ctx.data.bookings || []).slice(0, 3).map(function (b, idx) {
          return { audit: "AUD-00" + (idx + 1), booking: s.esc(b.id), owner: s.esc(b.providerName), status: s.statusBadge("in_review") };
        });
      },
      actions: [{ label: "Mark Reviewed", flowPage: "audits", flowStatus: "completed", toast: "Audit marked as reviewed." }],
    },
    complaints: {
      title: "Dashboard Complaints",
      subtitle: "Complaint queue, SLA, and resolution workflow.",
      columns: [
        { key: "id", label: "Complaint" },
        { key: "patient", label: "Patient" },
        { key: "issue", label: "Issue" },
        { key: "sla", label: "SLA (hrs)" },
        { key: "status", label: "Status" },
      ],
      rows: function (ctx) {
        return (ctx.data.complaints || []).map(function (c) {
          return { id: s.esc(c.id), patient: s.esc(c.patientName), issue: s.esc(c.issueType), sla: String(c.slaHoursLeft), status: s.statusBadge(c.status) };
        });
      },
      actions: [{ label: "Resolve Complaint", flowPage: "complaints", flowStatus: "completed", toast: "Complaint moved to resolved state." }],
    },
    flags: {
      title: "Dashboard Flags",
      subtitle: "Flagged provider review and risk status.",
      columns: [
        { key: "entity", label: "Entity" },
        { key: "reason", label: "Reason" },
        { key: "risk", label: "Risk" },
        { key: "state", label: "State" },
      ],
      rows: function () {
        return [
          { entity: "Dr. Limo", reason: "Repeated late consultation start", risk: s.statusBadge("warning"), state: s.statusBadge("in_review") },
          { entity: "Nurse Wanjiku", reason: "Documentation backlog", risk: s.statusBadge("warning"), state: s.statusBadge("in_review") },
        ];
      },
      actions: [{ label: "Trigger Retraining", flowPage: "flags", flowStatus: "confirmed", toast: "Retraining trigger recorded." }],
    },
    stock: {
      title: "Dashboard Stock",
      subtitle: "Stock levels and reorder indicators for pharmacy operations.",
      columns: [
        { key: "sku", label: "SKU" },
        { key: "name", label: "Name" },
        { key: "qty", label: "Qty" },
        { key: "reorder", label: "Reorder Level" },
        { key: "status", label: "Status" },
      ],
      rows: function (ctx) {
        return (ctx.data.pharmacyStock || []).map(function (stock) {
          return { sku: s.esc(stock.sku), name: s.esc(stock.name), qty: String(stock.qty), reorder: String(stock.reorderLevel), status: s.statusBadge(stock.status) };
        });
      },
      actions: [{ label: "Create Reorder Request", flowPage: "stock", flowStatus: "confirmed", toast: "Reorder request created." }],
    },
    inventory: {
      title: "Dashboard Inventory",
      subtitle: "Batch-level inventory details and expiry alerts.",
      columns: [
        { key: "sku", label: "SKU" },
        { key: "batch", label: "Batch" },
        { key: "expiry", label: "Expiry Date" },
        { key: "qty", label: "Qty" },
      ],
      rows: function (ctx) {
        return (ctx.data.pharmacyBatches || []).map(function (b) {
          return { sku: s.esc(b.sku), batch: s.esc(b.batchNo), expiry: s.esc(b.expiryDate), qty: String(b.qty) };
        });
      },
      actions: [{ label: "Run Expiry Check", flowPage: "inventory", flowStatus: "in_progress", toast: "Expiry check completed." }],
    },
    sales: {
      title: "Dashboard Sales",
      subtitle: "Medication sales log with order-linked records and export concept.",
      columns: [
        { key: "id", label: "Sale ID" },
        { key: "name", label: "Medication" },
        { key: "qty", label: "Qty" },
        { key: "amount", label: "Amount" },
        { key: "date", label: "Date" },
      ],
      rows: function (ctx) {
        return (ctx.data.pharmacySales || []).map(function (sale) {
          return { id: s.esc(sale.id), name: s.esc(sale.name), qty: String(sale.qty), amount: s.formatCurrency(sale.amount), date: s.esc(sale.date) };
        });
      },
      actions: [{ label: "Export Sales Log", flowPage: "sales", flowStatus: "completed", toast: "Sales export prepared." }],
    },
    suppliers: {
      title: "Dashboard Suppliers",
      subtitle: "Supplier directory with contact, lead time, and procurement status.",
      columns: [
        { key: "name", label: "Supplier" },
        { key: "contact", label: "Contact" },
        { key: "lead", label: "Lead Time" },
        { key: "status", label: "Status" },
      ],
      rows: function () {
        return [
          { name: "MediLink Distributors", contact: "+2547XXXXXXXX", lead: "2 days", status: s.statusBadge("active") },
          { name: "Kenya Pharma Central", contact: "+2547XXXXXXXX", lead: "4 days", status: s.statusBadge("active") },
        ];
      },
      actions: [{ label: "Add Supplier", flowPage: "suppliers", flowStatus: "confirmed", toast: "Supplier profile added." }],
    },
    revenue: {
      title: "Dashboard Revenue",
      subtitle: "Revenue totals, payment method split, and trend summary.",
      columns: [
        { key: "tx", label: "Transaction" },
        { key: "method", label: "Method" },
        { key: "amount", label: "Amount" },
        { key: "status", label: "Status" },
      ],
      rows: function (ctx) {
        return (ctx.data.transactions || []).map(function (tx) {
          return { tx: s.esc(tx.id), method: s.esc(tx.method), amount: s.formatCurrency(tx.amount), status: s.statusBadge(tx.status) };
        });
      },
      actions: [{ label: "Refresh Revenue", flowPage: "revenue", flowStatus: "in_progress", toast: "Revenue snapshot refreshed." }],
    },
    payouts: {
      title: "Dashboard Payouts",
      subtitle: "Payout queue with approve/reject flow and settlement summary.",
      columns: [
        { key: "batch", label: "Batch" },
        { key: "beneficiary", label: "Beneficiary" },
        { key: "amount", label: "Amount" },
        { key: "status", label: "Status" },
      ],
      rows: function () {
        return [
          { batch: "PO-0001", beneficiary: "Provider Pool A", amount: s.formatCurrency(104000), status: s.statusBadge("pending") },
          { batch: "PO-0002", beneficiary: "Rider Pool A", amount: s.formatCurrency(48300), status: s.statusBadge("in_review") },
        ];
      },
      actions: [
        { label: "Approve Selected", flowPage: "payouts", flowStatus: "completed", toast: "Payout approved." },
        { label: "Reject Selected", flowPage: "payouts", flowStatus: "cancelled", className: "btn-outline", toast: "Payout rejected." },
      ],
    },
    invoices: {
      title: "Dashboard Invoices",
      subtitle: "Invoice generation, preview, and history tracking.",
      columns: [
        { key: "id", label: "Invoice ID" },
        { key: "client", label: "Client" },
        { key: "amount", label: "Amount" },
        { key: "state", label: "State" },
      ],
      rows: function () {
        return [
          { id: "INV-101", client: "Utawala Pilot Cluster", amount: s.formatCurrency(128000), state: s.statusBadge("completed") },
          { id: "INV-102", client: "Partner Pharmacy", amount: s.formatCurrency(62000), state: s.statusBadge("pending") },
        ];
      },
      actions: [{ label: "Generate Invoice", flowPage: "invoices", flowStatus: "confirmed", toast: "Invoice generated." }],
    },
    transactions: {
      title: "Dashboard Transactions",
      subtitle: "Transaction records with filtering and export-ready view.",
      columns: [
        { key: "id", label: "Transaction" },
        { key: "booking", label: "Booking" },
        { key: "method", label: "Method" },
        { key: "amount", label: "Amount" },
        { key: "status", label: "Status" },
      ],
      rows: function (ctx) {
        return (ctx.data.transactions || []).map(function (tx) {
          return { id: s.esc(tx.id), booking: s.esc(tx.bookingId), method: s.esc(tx.method), amount: s.formatCurrency(tx.amount), status: s.statusBadge(tx.status) };
        });
      },
      actions: [{ label: "Export Transactions", flowPage: "transactions", flowStatus: "completed", toast: "Transaction export prepared." }],
    },
    executive: {
      title: "Dashboard Executive",
      subtitle: "Top-level KPI view for leadership decisions.",
      render: function () {
        return (
          window.GonepUI.renderKpiRow([
            { label: "Consultations (MTD)", value: "421" },
            { label: "Fulfillment Rate", value: "94%" },
            { label: "Avg Response Time", value: "22 min" },
            { label: "Revenue (MTD)", value: s.formatCurrency(1842000) },
            { label: "Complaint Closure", value: "91%" },
            { label: "Stock Health", value: "88%" },
          ]) +
          s.card(
            "Executive Summary",
            s.renderTimeline([
              { title: "Service Mix", description: "Home visits remain the highest volume service." },
              { title: "Geography", description: "Utawala remains the dominant demand cluster." },
              { title: "Pilot Focus", description: "Priority is reducing response times and improving completion consistency." },
            ])
          )
        );
      },
    },
  };

  var pages = {};
  Object.keys(configs).forEach(function (key) {
    var cfg = configs[key];
    if (typeof cfg.render === "function") {
      pages[key] = { title: cfg.title, subtitle: cfg.subtitle, render: cfg.render };
    } else {
      pages[key] = {
        title: cfg.title,
        subtitle: cfg.subtitle,
        render: (function (k) {
          return function (ctx) {
            return buildCommandPage(k, configs[k], ctx);
          };
        })(key),
      };
    }
  });

  window.GonepDashboardPages = pages;
})();
