(function () {
  "use strict";

  var bookings = [
    {
      id: "BK-UT-001",
      patientName: "Amina Yusuf",
      serviceType: "Home GP Visit",
      status: "en_route",
      providerName: "Dr. Njoroge",
      riderName: "Brian (Rider)",
      eta: "18 min",
      fee: 2000,
      createdAt: "2026-03-05T08:15:00+03:00",
      address: "Utawala, Githunguri Road, Nairobi",
      symptoms: "Fever, sore throat, fatigue",
    },
    {
      id: "BK-UT-002",
      patientName: "Kevin Mutua",
      serviceType: "Nurse Follow-up",
      status: "completed",
      providerName: "Nurse Wanjiku",
      riderName: "Mercy (Rider)",
      eta: "Arrived",
      fee: 1500,
      createdAt: "2026-03-04T14:40:00+03:00",
      address: "Utawala, Astrol Petrol Station area",
      symptoms: "Wound dressing review",
    },
    {
      id: "BK-UT-003",
      patientName: "Faith Achieng",
      serviceType: "Teleconsult",
      status: "awaiting_provider",
      providerName: "Dr. Limo",
      riderName: "-",
      eta: "N/A",
      fee: 1200,
      createdAt: "2026-03-05T11:05:00+03:00",
      address: "Utawala, Shooters stage",
      symptoms: "Headache, mild dizziness",
    },
  ];

  var providers = [
    { id: "PR-001", name: "Dr. Njoroge", rating: 4.8, online: true, specialisation: "General Practice" },
    { id: "PR-002", name: "Dr. Limo", rating: 4.6, online: true, specialisation: "Internal Medicine" },
    { id: "PR-003", name: "Nurse Wanjiku", rating: 4.7, online: false, specialisation: "Community Nursing" },
  ];

  var riders = [
    { id: "RD-001", name: "Brian (Rider)", online: true, lat: -1.285, lng: 36.988, active: true },
    { id: "RD-002", name: "Mercy (Rider)", online: true, lat: -1.282, lng: 36.995, active: false },
    { id: "RD-003", name: "Maina (Rider)", online: false, lat: -1.279, lng: 36.981, active: false },
  ];

  var prescriptions = [
    {
      id: "RX-001",
      bookingId: "BK-UT-001",
      providerName: "Dr. Njoroge",
      meds: [
        { name: "Amoxil", dose: "500mg", duration: "5 days", instructions: "1 capsule after meals, 3x daily" },
        { name: "Panadol", dose: "1g", duration: "3 days", instructions: "1 tablet every 8 hours PRN" },
      ],
      createdAt: "2026-03-05T09:10:00+03:00",
    },
    {
      id: "RX-002",
      bookingId: "BK-UT-002",
      providerName: "Nurse Wanjiku",
      meds: [{ name: "Mupirocin Ointment", dose: "2%", duration: "7 days", instructions: "Apply thin layer twice daily" }],
      createdAt: "2026-03-04T15:25:00+03:00",
    },
  ];

  var pharmacyStock = [
    { sku: "MED-001", name: "Amoxil 500mg", qty: 120, reorderLevel: 40, status: "ok", category: "Antibiotic" },
    { sku: "MED-002", name: "Panadol Extra", qty: 75, reorderLevel: 30, status: "ok", category: "Analgesic" },
    { sku: "MED-003", name: "Ventolin Inhaler", qty: 18, reorderLevel: 20, status: "low", category: "Respiratory" },
    { sku: "MED-004", name: "ORS Sachets", qty: 0, reorderLevel: 25, status: "out", category: "Hydration" },
  ];

  var pharmacyBatches = [
    { sku: "MED-001", batchNo: "BT-AMX-2401", expiryDate: "2027-01-12", qty: 80 },
    { sku: "MED-001", batchNo: "BT-AMX-2402", expiryDate: "2027-04-30", qty: 40 },
    { sku: "MED-003", batchNo: "BT-VEN-2320", expiryDate: "2026-11-08", qty: 18 },
    { sku: "MED-004", batchNo: "BT-ORS-2307", expiryDate: "2026-07-21", qty: 0 },
  ];

  var pharmacySales = [
    { id: "PHS-001", sku: "MED-001", name: "Amoxil 500mg", qty: 15, bookingId: "BK-UT-001", date: "2026-03-05", amount: 2250 },
    { id: "PHS-002", sku: "MED-002", name: "Panadol Extra", qty: 10, bookingId: "BK-UT-001", date: "2026-03-05", amount: 950 },
    { id: "PHS-003", sku: "MED-003", name: "Ventolin Inhaler", qty: 2, bookingId: "BK-UT-003", date: "2026-03-05", amount: 1400 },
  ];

  var complaints = [
    { id: "CMP-001", bookingId: "BK-UT-002", patientName: "Kevin Mutua", issueType: "Late arrival", status: "open", slaHoursLeft: 12 },
    { id: "CMP-002", bookingId: "BK-UT-003", patientName: "Faith Achieng", issueType: "Billing query", status: "in_review", slaHoursLeft: 21 },
  ];

  var transactions = [
    { id: "TX-001", bookingId: "BK-UT-001", method: "M-Pesa", amount: 2000, status: "paid", date: "2026-03-05T08:18:00+03:00" },
    { id: "TX-002", bookingId: "BK-UT-002", method: "Card", amount: 1500, status: "paid", date: "2026-03-04T14:45:00+03:00" },
    { id: "TX-003", bookingId: "BK-UT-003", method: "M-Pesa", amount: 1200, status: "pending", date: "2026-03-05T11:08:00+03:00" },
  ];

  var labResults = [
    { id: "LAB-001", bookingId: "BK-UT-001", fileName: "cbc_result_amina.pdf", fileType: "PDF", uploadedAt: "2026-03-05T10:02:00+03:00" },
    { id: "LAB-002", bookingId: "BK-UT-002", fileName: "wound_swab_report.jpg", fileType: "JPG", uploadedAt: "2026-03-04T16:15:00+03:00" },
  ];

  function getBookingById(id) {
    return bookings.find(function (item) {
      return item.id === id;
    }) || null;
  }

  function getActiveCounts() {
    return {
      bookings: bookings.length,
      providers: providers.filter(function (p) { return p.online; }).length,
      riders: riders.filter(function (r) { return r.online; }).length,
    };
  }

  window.GonepData = {
    bookings: bookings,
    providers: providers,
    riders: riders,
    prescriptions: prescriptions,
    pharmacyStock: pharmacyStock,
    pharmacyBatches: pharmacyBatches,
    pharmacySales: pharmacySales,
    complaints: complaints,
    transactions: transactions,
    labResults: labResults,
    getBookingById: getBookingById,
    getActiveCounts: getActiveCounts,
  };
})();
