(function () {
  "use strict";

  var s = window.GonepPageShared;

  var pages = {
    dashboard: {
      title: "Provider Dashboard",
      subtitle: "Clinical work hub for appointments, active consultations, and earnings snapshot.",
      render: function (ctx) {
        var bookings = ctx.data.bookings || [];
        return (
          window.GonepUI.renderKpiRow([
            { label: "Today's Requests", value: String(bookings.length) },
            { label: "Active Consultation", value: ctx.state.provider.activeBookingId || "None" },
            { label: "Online Status", value: ctx.state.provider.online ? "Online" : "Offline" },
            { label: "Consultation Fee", value: s.formatCurrency(ctx.state.provider.fee) },
          ]) +
          s.card(
            "Work Queue",
            s.table(
              [
                { key: "id", label: "Booking" },
                { key: "patient", label: "Patient" },
                { key: "type", label: "Service" },
                { key: "status", label: "Status" },
              ],
              bookings.slice(0, 4).map(function (item) {
                return {
                  id: s.esc(item.id),
                  patient: s.esc(item.patientName),
                  type: s.esc(item.serviceType),
                  status: s.statusBadge(item.status),
                };
              })
            ) +
              s.renderActions([
                { label: "Open Appointments", href: "./appointments.html" },
                { label: "Open Consultations", href: "./consultations.html", className: "btn-outline" },
                { label: "Open Earnings", href: "./earnings.html", className: "btn-outline" },
              ])
          )
        );
      },
    },
    consultations: {
      title: "Provider Consultations",
      subtitle: "Patient summary, visit details, vitals capture, SOAP notes, and care plan.",
      render: function (ctx) {
        var active = s.sampleBooking(ctx.data, 0);
        var sections = [
          {
            id: "patient_summary",
            label: "Patient Summary",
            body: s.renderKeyRows([
              { label: "Patient", value: active ? s.esc(active.patientName) : "-" },
              { label: "Visit", value: active ? s.esc(active.serviceType) : "-" },
              { label: "Symptoms", value: active ? s.esc(active.symptoms) : "-" },
            ]),
          },
          {
            id: "vitals",
            label: "Vitals",
            body:
              s.renderKeyRows([
                { label: "Temperature", value: "37.9 C" },
                { label: "Pulse", value: "86 bpm" },
                { label: "Blood Pressure", value: "118/76" },
              ]) +
              s.renderActions([
                { label: "Save Vitals", flowPage: "consultations", flowStatus: "in_progress", nextSection: "soap", toast: "Vitals saved." },
              ]),
          },
          {
            id: "soap",
            label: "SOAP Notes",
            body:
              s.renderTimeline([
                { title: "Subjective", description: "Persistent sore throat and mild fever." },
                { title: "Objective", description: "No respiratory distress, mild tonsillar inflammation." },
                { title: "Assessment", description: "Likely bacterial upper airway infection." },
                { title: "Plan", description: "Start oral antibiotics and follow up in 72 hours." },
              ]) +
              s.renderActions([
                { label: "Save Consultation", flowPage: "consultations", flowStatus: "confirmed", nextSection: "next_steps", toast: "Consultation notes saved." },
              ]),
          },
          {
            id: "next_steps",
            label: "Next Steps",
            body: s.renderActions([
              { label: "Generate Prescription", flowPage: "consultations", flowStatus: "completed", nextPage: "./prescriptions.html", toast: "Proceeding to prescription creation." },
            ]),
          },
        ];
        return s.renderFlowPanel({ flow: ctx.flow, pageKey: "consultations" }, sections);
      },
    },
    appointments: {
      title: "Provider Appointments",
      subtitle: "Incoming, upcoming, active, and completed appointment queue.",
      render: function (ctx) {
        var sections = [
          {
            id: "incoming",
            label: "Incoming",
            body:
              s.table(
                [
                  { key: "booking", label: "Booking" },
                  { key: "patient", label: "Patient" },
                  { key: "service", label: "Service" },
                  { key: "action", label: "Action" },
                ],
                (ctx.data.bookings || [])
                  .filter(function (item) {
                    return item.status === "awaiting_provider";
                  })
                  .map(function (item) {
                    return {
                      booking: s.esc(item.id),
                      patient: s.esc(item.patientName),
                      service: s.esc(item.serviceType),
                      action:
                        '<button class="btn btn-outline" type="button" data-action="update_flow" data-flow-page="appointments" data-flow-status="confirmed" data-next-section="upcoming" data-toast="Request accepted.">Accept</button>',
                    };
                  })
              ) || '<p class="muted">No incoming requests.</p>',
          },
          {
            id: "upcoming",
            label: "Upcoming",
            body:
              '<p class="muted">Confirmed appointments ready for consultation.</p>' +
              s.renderActions([{ label: "Move to Active", flowPage: "appointments", flowStatus: "in_progress", nextSection: "active", toast: "Appointment moved to active." }]),
          },
          {
            id: "active",
            label: "Active",
            body: s.renderActions([
              { label: "Open Active Consultation", flowPage: "appointments", flowStatus: "in_progress", nextPage: "./consultations.html", toast: "Opening consultation workspace." },
              { label: "Mark Completed", flowPage: "appointments", flowStatus: "completed", nextSection: "completed", className: "btn-outline", toast: "Appointment completed." },
            ]),
          },
          {
            id: "completed",
            label: "Completed",
            body: '<p class="muted">Completed appointments are available for review and records linkage.</p>',
          },
        ];
        return s.renderFlowPanel({ flow: ctx.flow, pageKey: "appointments" }, sections);
      },
    },
    prescriptions: {
      title: "Provider Prescriptions",
      subtitle: "Create prescriptions, sign digitally, and send to patient.",
      render: function (ctx) {
        var rx = (ctx.data.prescriptions || [])[0];
        return (
          s.card(
            "Prescription Draft",
            s.renderKeyRows([
              { label: "Booking", value: rx ? s.esc(rx.bookingId) : "BK-UT-001" },
              { label: "Provider", value: rx ? s.esc(rx.providerName) : ctx.state.provider.name },
              { label: "Draft State", value: s.statusBadge(ctx.flow.status) },
            ]) +
              s.table(
                [
                  { key: "name", label: "Medication" },
                  { key: "dose", label: "Dose" },
                  { key: "duration", label: "Duration" },
                ],
                (rx && rx.meds ? rx.meds : []).map(function (med) {
                  return { name: s.esc(med.name), dose: s.esc(med.dose), duration: s.esc(med.duration) };
                })
              ) +
              s.renderActions([
                { label: "Save Draft", flowPage: "prescriptions", flowStatus: "draft", toast: "Prescription draft saved." },
                { label: "Sign Prescription", flowPage: "prescriptions", flowStatus: "confirmed", toast: "Prescription signed successfully." },
                { label: "Send to Patient", flowPage: "prescriptions", flowStatus: "completed", toast: "Prescription sent to patient." },
              ])
          ) +
          s.card("Next Step", s.renderActions([{ label: "Open Earnings", href: "./earnings.html", className: "btn-outline" }]))
        );
      },
    },
    earnings: {
      title: "Provider Earnings",
      subtitle: "Revenue snapshot, payouts, and fee configuration.",
      render: function (ctx) {
        var totalPaid = (ctx.data.transactions || [])
          .filter(function (tx) {
            return tx.status === "paid";
          })
          .reduce(function (sum, tx) {
            return sum + Number(tx.amount || 0);
          }, 0);
        return (
          window.GonepUI.renderKpiRow([
            { label: "Today's Earnings", value: s.formatCurrency(totalPaid) },
            { label: "Weekly Settlement", value: s.formatCurrency(totalPaid * 3) },
            { label: "Pending Payout", value: s.formatCurrency(totalPaid * 0.35) },
            { label: "Current Fee", value: s.formatCurrency(ctx.state.provider.fee) },
          ]) +
          s.card(
            "Fee Configuration",
            s.renderActions([
              { label: "Set Fee KES 2,000", statePath: "provider.fee", stateValue: 2000, flowPage: "earnings", flowStatus: "confirmed", toast: "Fee updated to KES 2,000." },
              { label: "Set Fee KES 2,500", className: "btn-outline", statePath: "provider.fee", stateValue: 2500, flowPage: "earnings", flowStatus: "confirmed", toast: "Fee updated to KES 2,500." },
            ])
          )
        );
      },
    },
    profile: {
      title: "Provider Profile",
      subtitle: "Credentials, specialization, verification status, and payout details.",
      render: function (ctx) {
        return s.card(
          "Provider Details",
          s.renderKeyRows([
            { label: "Name", value: s.esc(ctx.state.provider.name) },
            { label: "Specialization", value: "General Practice" },
            { label: "Qualifications", value: "MBChB, BLS Certified" },
            { label: "Verification", value: s.statusBadge("completed") },
            { label: "Payout Number", value: "+2547XXXXXXXX" },
          ]) + s.renderActions([{ label: "Open Protocols", href: "./protocols.html", className: "btn-outline" }])
        );
      },
    },
    protocols: {
      title: "Provider Protocols",
      subtitle: "Read-only SOPs, training references, and clinical guidance.",
      render: function () {
        return s.card(
          "Protocol Library",
          s.table(
            [
              { key: "name", label: "Protocol" },
              { key: "domain", label: "Domain" },
              { key: "version", label: "Version" },
              { key: "status", label: "Status" },
            ],
            [
              { name: "Teleconsult SOP", domain: "Consultation", version: "v1.4", status: s.statusBadge("active") },
              { name: "Antibiotic Stewardship Guide", domain: "Medication", version: "v2.0", status: s.statusBadge("active") },
              { name: "Escalation Checklist", domain: "Operations", version: "v1.2", status: s.statusBadge("active") },
            ]
          ) +
            s.renderActions([
              { label: "Preview Selected Protocol", flowPage: "protocols", flowStatus: "in_progress", toast: "Protocol preview opened." },
              { label: "Back to Dashboard", href: "./dashboard.html", className: "btn-outline" },
            ])
        );
      },
    },
  };

  window.GonepProviderPages = pages;
})();
