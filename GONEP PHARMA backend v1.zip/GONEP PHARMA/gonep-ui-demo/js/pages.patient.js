(function () {
  "use strict";

  var s = window.GonepPageShared;

  var pages = {
    dashboard: {
      title: "Patient Dashboard",
      subtitle: "Control center for care requests, consultations, prescriptions, and diagnostics.",
      render: function (ctx) {
        var state = ctx.state.patient;
        var active = s.sampleBooking(ctx.data, 0);
        var recentRx = (ctx.data.prescriptions || [])[0];
        var lab = (ctx.data.labResults || [])[0];
        return (
          window.GonepUI.renderKpiRow([
            { label: "Active Booking", value: state.activeBookingId || "None" },
            { label: "Current Language", value: state.language },
            { label: "Coverage", value: state.locationInCoverage ? "In Coverage" : "Out of Coverage" },
            { label: "Flow State", value: s.toTitleCase(ctx.flow.status) },
          ]) +
          s.card(
            "Quick Actions",
            s.renderActions([
              { label: "Book Consultation", href: "./bookings.html" },
              { label: "Diagnostics", href: "./diagnostics.html", className: "btn-outline" },
              { label: "Prescriptions", href: "./prescriptions.html", className: "btn-outline" },
              { label: "Records", href: "./records.html", className: "btn-outline" },
            ])
          ) +
          '<section class="content-columns">' +
          s.card(
            "Active Booking Summary",
            active
              ? s.renderKeyRows([
                  { label: "Booking ID", value: s.esc(active.id) },
                  { label: "Service", value: s.esc(active.serviceType) },
                  { label: "Provider", value: s.esc(active.providerName) },
                  { label: "Status", value: s.statusBadge(active.status) },
                  { label: "ETA", value: s.esc(active.eta) },
                ]) +
                  s.renderActions([{ label: "Open Booking Flow", href: "./bookings.html" }])
              : '<p class="muted">No active booking available.</p>'
          ) +
          s.card(
            "Latest Activity",
            s.renderKeyRows([
              { label: "Consultation", value: active ? s.esc(active.symptoms) : "-" },
              { label: "Prescription", value: recentRx ? s.esc(recentRx.id) : "-" },
              { label: "Lab Result", value: lab ? s.esc(lab.fileName) : "-" },
            ]) +
              s.renderActions([
                { label: "Open Consultations", href: "./consultations.html", className: "btn-outline" },
                { label: "Open Support", href: "./support.html", className: "btn-outline" },
              ])
          ) +
          "</section>"
        );
      },
    },
    bookings: {
      title: "Patient Bookings",
      subtitle: "End-to-end booking, payment, active care, and delivery tracking in one workflow.",
      render: function (ctx) {
        var active = s.sampleBooking(ctx.data, 0);
        var sections = [
          {
            id: "new_booking",
            label: "New Booking",
            body:
              s.renderKeyRows([
                { label: "Requested Service", value: "Home GP Visit" },
                { label: "Preferred Slot", value: "Today 4:30 PM" },
                { label: "Symptoms", value: "Fever, sore throat, fatigue" },
              ]) +
              s.renderActions([
                {
                  label: "Continue to Confirmation",
                  flowPage: "bookings",
                  flowStatus: "draft",
                  nextSection: "confirmation",
                  toast: "Booking details captured.",
                },
              ]),
          },
          {
            id: "confirmation",
            label: "Confirmation",
            body:
              s.renderKeyRows([
                { label: "Provider", value: active ? s.esc(active.providerName) : "Dr. Njoroge" },
                { label: "Slot", value: "Today 5:00 PM" },
                { label: "Consultation Fee", value: s.formatCurrency(active ? active.fee : 2000) },
              ]) +
              s.renderActions([
                {
                  label: "Proceed to Payment",
                  flowPage: "bookings",
                  flowStatus: "confirmed",
                  nextSection: "payment",
                  toast: "Booking confirmed.",
                },
              ]),
          },
          {
            id: "payment",
            label: "Payment",
            body:
              '<p class="muted">Choose any payment method to continue. No blocking validation is applied in this frontend flow.</p>' +
              s.renderActions([
                {
                  label: "Pay with M-Pesa",
                  flowPage: "bookings",
                  flowStatus: "in_progress",
                  nextSection: "active_booking",
                  toast: "Payment successful.",
                },
                {
                  label: "Pay with Card",
                  flowPage: "bookings",
                  flowStatus: "in_progress",
                  nextSection: "active_booking",
                  className: "btn-outline",
                  toast: "Payment successful.",
                },
              ]),
          },
          {
            id: "active_booking",
            label: "Active Booking",
            body:
              (active
                ? s.renderKeyRows([
                    { label: "Booking", value: s.esc(active.id) },
                    { label: "Provider", value: s.esc(active.providerName) },
                    { label: "Rider", value: s.esc(active.riderName) },
                    { label: "Current Status", value: s.statusBadge("in_progress") },
                  ])
                : "") +
              s.renderActions([
                {
                  label: "Advance to Delivery Tracking",
                  flowPage: "bookings",
                  flowStatus: "in_progress",
                  nextSection: "delivery_tracking",
                  toast: "Booking moved to delivery tracking.",
                },
                {
                  label: "Continue to Consultation",
                  flowPage: "bookings",
                  flowStatus: "completed",
                  nextPage: "./consultations.html",
                  toast: "Proceeding to consultation summary.",
                },
              ]),
          },
          {
            id: "delivery_tracking",
            label: "Delivery Tracking",
            body:
              s.renderKeyRows([
                { label: "Medication Order", value: "RX-001" },
                { label: "Delivery Stage", value: s.statusBadge("en_route") },
                { label: "Expected Arrival", value: "18 min" },
              ]) +
              s.renderActions([
                {
                  label: "Mark Delivered",
                  flowPage: "bookings",
                  flowStatus: "completed",
                  toast: "Delivery marked complete.",
                },
              ]),
          },
        ];

        return s.renderFlowPanel({ flow: ctx.flow, pageKey: "bookings" }, sections);
      },
    },
    consultations: {
      title: "Patient Consultations",
      subtitle: "Consultation summary, SOAP overview, vitals, and next actions.",
      render: function (ctx) {
        var active = s.sampleBooking(ctx.data, 0);
        return (
          s.card(
            "Visit Summary",
            s.renderKeyRows([
              { label: "Provider", value: active ? s.esc(active.providerName) : "-" },
              { label: "Visit Type", value: active ? s.esc(active.serviceType) : "-" },
              { label: "Primary Complaint", value: active ? s.esc(active.symptoms) : "-" },
              { label: "Consultation State", value: s.statusBadge("completed") },
            ])
          ) +
          '<section class="grid-2">' +
          s.card(
            "SOAP Overview",
            s.renderTimeline([
              { title: "Subjective", description: "Patient reports fever for two days with mild fatigue." },
              { title: "Objective", description: "Vitals stable; temperature elevated at 37.9 C." },
              { title: "Assessment", description: "Upper respiratory tract infection likely." },
              { title: "Plan", description: "Medication + hydration + follow-up in 72 hours." },
            ])
          ) +
          s.card(
            "Next Actions",
            s.renderActions([
              { label: "Open Prescriptions", href: "./prescriptions.html" },
              { label: "Open Diagnostics", href: "./diagnostics.html", className: "btn-outline" },
              { label: "Send to Records", href: "./records.html", className: "btn-outline" },
            ])
          ) +
          "</section>"
        );
      },
    },
    prescriptions: {
      title: "Patient Prescriptions",
      subtitle: "Medication instructions, current delivery status, and history.",
      render: function (ctx) {
        var current = (ctx.data.prescriptions || [])[0];
        var meds = (current && current.meds) || [];
        return (
          s.card(
            "Current Prescription",
            current
              ? s.renderKeyRows([
                  { label: "Prescription ID", value: s.esc(current.id) },
                  { label: "Provider", value: s.esc(current.providerName) },
                  { label: "Order Status", value: s.statusBadge("in_progress") },
                ]) +
                  s.table(
                    [
                      { key: "medication", label: "Medication" },
                      { key: "dosage", label: "Dosage" },
                      { key: "duration", label: "Duration" },
                      { key: "instructions", label: "Instructions" },
                    ],
                    meds.map(function (med) {
                      return {
                        medication: s.esc(med.name),
                        dosage: s.esc(med.dose),
                        duration: s.esc(med.duration),
                        instructions: s.esc(med.instructions),
                      };
                    })
                  )
              : '<p class="muted">No prescriptions available.</p>'
          ) +
          s.card(
            "Actions",
            s.renderActions([
              { label: "Request Delivery Update", flowPage: "prescriptions", flowStatus: "in_progress", toast: "Delivery status refreshed." },
              { label: "Open Records", href: "./records.html", className: "btn-outline" },
            ])
          )
        );
      },
    },
    diagnostics: {
      title: "Patient Diagnostics",
      subtitle: "Book tests, upload results, view reports, and track uploaded files.",
      render: function (ctx) {
        var labs = (ctx.data.labResults || []).map(function (item) {
          return { id: s.esc(item.id), file: s.esc(item.fileName), type: s.esc(item.fileType), uploaded: s.esc(item.uploadedAt.split("T")[0]) };
        });
        var sections = [
          {
            id: "book_test",
            label: "Book Test",
            body:
              s.renderKeyRows([
                { label: "Test Type", value: "Complete Blood Count" },
                { label: "Preferred Date", value: "Tomorrow 9:00 AM" },
                { label: "Location", value: "Home sample collection" },
              ]) +
              s.renderActions([{ label: "Confirm Test Booking", flowPage: "diagnostics", flowStatus: "confirmed", nextSection: "upload_result", toast: "Diagnostic booking confirmed." }]),
          },
          {
            id: "upload_result",
            label: "Upload Result",
            body:
              '<p class="muted">File uploads are represented as UI placeholders and always proceed.</p>' +
              s.renderActions([{ label: "Upload Lab File", flowPage: "diagnostics", flowStatus: "in_progress", nextSection: "view_results", toast: "File uploaded successfully." }]),
          },
          {
            id: "view_results",
            label: "View Results",
            body:
              s.table(
                [
                  { key: "id", label: "Result ID" },
                  { key: "file", label: "File Name" },
                  { key: "type", label: "Type" },
                  { key: "uploaded", label: "Uploaded" },
                ],
                labs
              ) + s.renderActions([{ label: "Open Records", href: "./records.html", className: "btn-outline" }]),
          },
          {
            id: "uploaded_files",
            label: "Uploaded Files",
            body:
              '<p class="muted">Recent diagnostic uploads are listed above and can be reviewed in records.</p>' +
              s.renderActions([{ label: "Mark Diagnostics Complete", flowPage: "diagnostics", flowStatus: "completed", toast: "Diagnostics marked complete." }]),
          },
        ];
        return s.renderFlowPanel({ flow: ctx.flow, pageKey: "diagnostics" }, sections);
      },
    },
    records: {
      title: "Patient Records",
      subtitle: "Long-term timeline across consultations, prescriptions, and diagnostics.",
      render: function (ctx) {
        var booking = s.sampleBooking(ctx.data, 0);
        var prescription = (ctx.data.prescriptions || [])[0];
        var lab = (ctx.data.labResults || [])[0];
        return s.card(
          "Health Timeline",
          s.renderTimeline([
            { title: "Consultation Completed", meta: booking ? booking.id + " • " + booking.providerName : "Consultation", description: booking ? booking.symptoms : "General consultation notes available." },
            { title: "Prescription Issued", meta: prescription ? prescription.id : "Medication plan", description: "Medication instructions are available in prescriptions." },
            { title: "Diagnostics Uploaded", meta: lab ? lab.id : "Lab entry", description: "Latest lab evidence synced for future visits." },
          ]) +
            s.renderActions([
              { label: "Open Consultations", href: "./consultations.html", className: "btn-outline" },
              { label: "Open Prescriptions", href: "./prescriptions.html", className: "btn-outline" },
              { label: "Open Diagnostics", href: "./diagnostics.html", className: "btn-outline" },
            ])
        );
      },
    },
    profile: {
      title: "Patient Profile",
      subtitle: "Profile details, settings, emergency contact, language, and exit controls.",
      render: function (ctx) {
        return (
          s.card(
            "Profile Settings",
            s.renderKeyRows([
              { label: "Name", value: s.esc(ctx.state.patient.name) },
              { label: "Phone", value: s.esc(ctx.state.patient.phone) },
              { label: "Language", value: s.esc(ctx.state.patient.language) },
              { label: "Emergency Contact", value: "Mary Yusuf • 07XXXXXXXX" },
            ]) +
              s.renderActions([
                { label: "Set Language to EN", flowPage: "profile", statePath: "patient.language", stateValue: "EN", toast: "Language updated to EN." },
                { label: "Set Language to SW", flowPage: "profile", statePath: "patient.language", stateValue: "SW", className: "btn-outline", toast: "Language updated to SW." },
              ])
          ) +
          s.card(
            "Session Controls",
            s.renderActions([
              { label: "Toggle Theme", action: "toggle_theme", className: "btn-outline" },
              { label: "Open Support", href: "./support.html", className: "btn-outline" },
              { label: "Exit to Main Index", href: "../index.html", className: "btn-primary" },
            ])
          )
        );
      },
    },
    support: {
      title: "Patient Support",
      subtitle: "FAQ and support channels for issue resolution and guidance.",
      render: function () {
        return (
          s.card(
            "Support Channels",
            s.renderKeyRows([
              { label: "Phone", value: "+254 700 000 000" },
              { label: "WhatsApp", value: "WhatsApp support placeholder" },
              { label: "Email", value: "help@gonep.health" },
              { label: "Command Centre", value: "Escalation Desk - 24/7" },
            ]) +
              s.renderActions([
                { label: "Submit Support Request", flowPage: "support", flowStatus: "in_progress", toast: "Support request submitted." },
                { label: "Back to Dashboard", href: "./dashboard.html", className: "btn-outline" },
              ])
          ) +
          s.card(
            "FAQ",
            s.renderTimeline([
              { title: "How do I book care?", description: "Use the Bookings page and proceed through each section." },
              { title: "How do I track medication?", description: "Use Prescriptions and Delivery Tracking in Bookings." },
              { title: "How do I upload diagnostics?", description: "Use Diagnostics and choose Upload Result." },
            ])
          )
        );
      },
    },
  };

  window.GonepPatientPages = pages;
})();
