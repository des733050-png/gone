(function () {
  "use strict";

  var cfg = {
    patient: [
      ["Dashboard", "./dashboard.html"],
      ["Bookings", "./bookings.html"],
      ["Consultations", "./consultations.html"],
      ["Prescriptions", "./prescriptions.html"],
      ["Diagnostics", "./diagnostics.html"],
      ["Records", "./records.html"],
      ["Profile", "./profile.html"],
      ["Support", "./support.html"],
    ],
    provider: [
      ["Dashboard", "./dashboard.html"],
      ["Consultations", "./consultations.html"],
      ["Appointments", "./appointments.html"],
      ["Prescriptions", "./prescriptions.html"],
      ["Earnings", "./earnings.html"],
      ["Profile", "./profile.html"],
      ["Protocols", "./protocols.html"],
    ],
    rider: [
      ["Dashboard", "./dashboard.html"],
      ["Jobs", "./jobs.html"],
      ["History", "./history.html"],
      ["Earnings", "./earnings.html"],
    ],
    dashboard: [
      ["Dashboard", "./dashboard.html"],
      ["Bookings", "./bookings.html"],
      ["Providers", "./providers.html"],
      ["Riders", "./riders.html"],
      ["Incidents", "./incidents.html"],
      ["Performance", "./performance.html"],
      ["Audits", "./audits.html"],
      ["Complaints", "./complaints.html"],
      ["Flags", "./flags.html"],
      ["Stock", "./stock.html"],
      ["Inventory", "./inventory.html"],
      ["Sales", "./sales.html"],
      ["Suppliers", "./suppliers.html"],
      ["Revenue", "./revenue.html"],
      ["Payouts", "./payouts.html"],
      ["Invoices", "./invoices.html"],
      ["Transactions", "./transactions.html"],
      ["Executive", "./executive.html"],
    ],
  };

  function normalize(pathname) {
    return (pathname || "/").replace(/\/+$/, "") || "/";
  }

  function getModuleConfig(module) {
    return cfg[module] || [];
  }

  function renderSidebar(module) {
    var links = getModuleConfig(module);
    var moduleLabel = module === "dashboard" ? "Command Dashboard" : module.charAt(0).toUpperCase() + module.slice(1);
    return (
      '<aside class="card app-sidebar">' +
      "<h2>GONEP Healthcare</h2>" +
      '<p class="muted">' + moduleLabel + "</p>" +
      '<div class="sidebar-group-title">Navigation</div>' +
      '<nav class="sidebar-links">' +
      links
        .map(function (item) {
          return '<a href="' + item[1] + '">' + item[0] + "</a>";
        })
        .join("") +
      "</nav>" +
      '<div class="sidebar-group-title">Utility</div>' +
      '<nav class="sidebar-links"><a href="../index.html">Back to Main Index</a><a href="../core/index.html">Core Entry</a></nav>' +
      "</aside>"
    );
  }

  function highlightActiveLinks(selector) {
    var links = document.querySelectorAll(selector || "a[href]");
    var currentPath = normalize(window.location.pathname);
    links.forEach(function (link) {
      var href = link.getAttribute("href");
      if (!href || href.startsWith("#") || href.startsWith("javascript:")) return;
      var candidate = normalize(new URL(href, window.location.href).pathname);
      if (candidate === currentPath) {
        link.classList.add("active");
        link.setAttribute("aria-current", "page");
      }
    });
  }

  function wireBackToMain(selector) {
    document.querySelectorAll(selector || "[data-back-main]").forEach(function (el) {
      el.addEventListener("click", function () {
        window.location.href = "../index.html";
      });
    });
  }

  function setBreadcrumbs(host, text) {
    var target = typeof host === "string" ? document.querySelector(host) : host;
    if (target) target.textContent = text || "";
  }

  window.GonepNavigation = {
    getModuleConfig: getModuleConfig,
    renderSidebar: renderSidebar,
    highlightActiveLinks: highlightActiveLinks,
    wireBackToMain: wireBackToMain,
    setBreadcrumbs: setBreadcrumbs,
  };

  // compatibility bridge
  window.GonepRouter = {
    highlightActiveLinks: highlightActiveLinks,
  };
})();
