(function () {
  "use strict";

  var s = window.GonepPageShared;

  var pages = {
    dashboard: {
      title: "Rider Dashboard",
      subtitle: "Status hub for availability, active job, and daily delivery summary.",
      render: function (ctx) {
        var firstJob = (ctx.data.bookings || [])[0];
        return (
          window.GonepUI.renderKpiRow([
            { label: "Availability", value: ctx.state.rider.online ? "Online" : "Offline" },
            { label: "Active Job", value: ctx.state.rider.activeJobId || "None" },
            { label: "Completed Today", value: "4" },
            { label: "Pending Pickup", value: "1" },
          ]) +
          s.card(
            "Current Job Preview",
            firstJob
              ? s.renderKeyRows([
                  { label: "Booking", value: s.esc(firstJob.id) },
                  { label: "Patient", value: s.esc(firstJob.patientName) },
                  { label: "Address", value: s.esc(firstJob.address) },
                  { label: "Status", value: s.statusBadge(firstJob.status) },
                ])
              : '<p class="muted">No active job selected.</p>'
          ) +
          s.card(
            "Quick Actions",
            s.renderActions([
              {
                label: ctx.state.rider.online ? "Go Offline" : "Go Online",
                statePath: "rider.online",
                stateValue: ctx.state.rider.online ? "false" : "true",
                flowPage: "dashboard",
                flowStatus: "in_progress",
                toast: "Availability updated.",
              },
              { label: "Open Jobs", href: "./jobs.html", className: "btn-outline" },
              { label: "Open Earnings", href: "./earnings.html", className: "btn-outline" },
            ])
          )
        );
      },
    },
    jobs: {
      title: "Rider Jobs",
      subtitle: "Available jobs, active route progress, delivery proof, and sample collection.",
      render: function (ctx) {
        var sections = [
          {
            id: "available_jobs",
            label: "Available Jobs",
            body:
              s.table(
                [
                  { key: "id", label: "Booking" },
                  { key: "patient", label: "Patient" },
                  { key: "address", label: "Address" },
                  { key: "status", label: "Status" },
                ],
                (ctx.data.bookings || []).slice(0, 3).map(function (item) {
                  return {
                    id: s.esc(item.id),
                    patient: s.esc(item.patientName),
                    address: s.esc(item.address),
                    status: s.statusBadge(item.status),
                  };
                })
              ) +
              s.renderActions([
                {
                  label: "Accept Selected Job",
                  flowPage: "jobs",
                  flowStatus: "confirmed",
                  statePath: "rider.activeJobId",
                  stateValue: "JOB-001",
                  nextSection: "active_job",
                  toast: "Job accepted and activated.",
                },
              ]),
          },
          {
            id: "active_job",
            label: "Active Job",
            body:
              s.renderKeyRows([
                { label: "Route Stage", value: s.statusBadge("en_route") },
                { label: "Pickup Type", value: "Medication + Lab Sample" },
                { label: "ETA", value: "18 min" },
              ]) +
              s.renderActions([
                { label: "Next: Delivery Proof", flowPage: "jobs", flowStatus: "in_progress", nextSection: "delivery_proof", toast: "Moved to delivery proof stage." },
              ]),
          },
          {
            id: "delivery_proof",
            label: "Delivery Proof",
            body:
              '<p class="muted">Proof capture is represented as a placeholder action in this frontend flow.</p>' +
              s.renderActions([
                { label: "Submit Delivery Proof", flowPage: "jobs", flowStatus: "completed", nextSection: "sample_collection", toast: "Delivery proof submitted." },
              ]),
          },
          {
            id: "sample_collection",
            label: "Sample Collection",
            body:
              '<p class="muted">Sample handoff confirmation is simulated and completes immediately.</p>' +
              s.renderActions([
                { label: "Submit Collection Confirmation", flowPage: "jobs", flowStatus: "completed", nextPage: "./history.html", toast: "Sample collection completed." },
              ]),
          },
        ];
        return s.renderFlowPanel({ flow: ctx.flow, pageKey: "jobs" }, sections);
      },
    },
    history: {
      title: "Rider History",
      subtitle: "Completed and cancelled job archive with delivery metrics.",
      render: function (ctx) {
        return (
          window.GonepUI.renderKpiRow([
            { label: "Completed Jobs", value: "42" },
            { label: "Cancelled Jobs", value: "3" },
            { label: "On-Time Rate", value: "93%" },
            { label: "Avg Completion", value: "34 min" },
          ]) +
          s.card(
            "Recent History",
            s.table(
              [
                { key: "id", label: "Booking" },
                { key: "patient", label: "Patient" },
                { key: "status", label: "Status" },
                { key: "date", label: "Date" },
              ],
              (ctx.data.bookings || []).map(function (item) {
                return {
                  id: s.esc(item.id),
                  patient: s.esc(item.patientName),
                  status: s.statusBadge(item.status === "completed" ? "completed" : "in_progress"),
                  date: s.esc(item.createdAt.split("T")[0]),
                };
              })
            ) +
              s.renderActions([{ label: "Open Earnings", href: "./earnings.html", className: "btn-outline" }])
          )
        );
      },
    },
    earnings: {
      title: "Rider Earnings",
      subtitle: "Daily, weekly, and monthly earnings with payout schedule.",
      render: function () {
        return (
          window.GonepUI.renderKpiRow([
            { label: "Today", value: s.formatCurrency(2800) },
            { label: "This Week", value: s.formatCurrency(18900) },
            { label: "This Month", value: s.formatCurrency(74200) },
            { label: "Next Payout", value: "Monday" },
          ]) +
          s.card(
            "Payout Actions",
            s.renderActions([
              { label: "Refresh Earnings", flowPage: "earnings", flowStatus: "in_progress", toast: "Earnings refreshed." },
              { label: "Export Statement", flowPage: "earnings", flowStatus: "completed", className: "btn-outline", toast: "Statement export prepared." },
            ])
          )
        );
      },
    },
  };

  window.GonepRiderPages = pages;
})();
