(function () {
  "use strict";

  var currentContext = null;
  var actionsBound = false;

  function parseValue(raw) {
    if (raw == null) return raw;
    if (raw === "true") return true;
    if (raw === "false") return false;
    if (raw === "null") return null;
    if (raw !== "" && !isNaN(Number(raw))) return Number(raw);
    return raw;
  }

  function fail(code, details) {
    if (window.GonepErrorCodes && typeof window.GonepErrorCodes.renderPageError === "function") {
      window.GonepErrorCodes.renderPageError(code, details || "");
    }
    if (details) {
      try {
        console.error(code + ": " + details);
      } catch (error) {
        // no-op
      }
    }
  }

  function assertDependencies() {
    if (!window.GonepState) throw new Error("Missing GonepState");
    if (!window.GonepUI) throw new Error("Missing GonepUI");
    if (!window.GonepNavigation) throw new Error("Missing GonepNavigation");
    if (!window.GonepPageRegistry) throw new Error("Missing GonepPageRegistry");
    if (!window.GonepToast) throw new Error("Missing GonepToast");
  }

  function actionToast(message) {
    if (!message) return;
    window.GonepToast.showToast("success", message);
  }

  function applySectionVisibility(container, currentSection) {
    if (!container) return;
    var sections = container.querySelectorAll("[data-section-id]");
    if (!sections.length) return;

    var activeSection = currentSection || sections[0].getAttribute("data-section-id");
    var exists = false;
    sections.forEach(function (section) {
      if (section.getAttribute("data-section-id") === activeSection) exists = true;
    });
    if (!exists) activeSection = sections[0].getAttribute("data-section-id");

    sections.forEach(function (section) {
      section.hidden = section.getAttribute("data-section-id") !== activeSection;
    });

    container.querySelectorAll(".tab-btn[data-next-section]").forEach(function (tab) {
      tab.classList.toggle("active", tab.getAttribute("data-next-section") === activeSection);
    });
  }

  function renderModulePage() {
    try {
      if (!currentContext) return;
      assertDependencies();

      var module = currentContext.module;
      var page = currentContext.page;
      var pageDefinition = window.GonepPageRegistry.getPage(module, page);
      var host = document.getElementById("page-content");
      var sidebar = document.getElementById("sidebar");
      var topbar = document.getElementById("topbar");

      if (!pageDefinition) return fail("GONEP-E-PAGE-001", module + "/" + page);
      if (!host || !sidebar || !topbar) return fail("GONEP-E-DEPS-001", "Missing page host elements.");

      try {
        window.GonepState.ensureState();
        window.GonepState.applyStoredTheme();
      } catch (error) {
        return fail("GONEP-E-STATE-001", String(error && error.message ? error.message : error));
      }

      window.GonepState.setCurrentRole(module);

      var state = window.GonepState.getState();
      var flow = window.GonepState.getFlow(module, page);

      sidebar.innerHTML = window.GonepNavigation.renderSidebar(module);
      topbar.innerHTML = window.GonepUI.renderTopbar({
        title: pageDefinition.title || currentContext.title || "Page",
        subtitle: pageDefinition.subtitle || "",
        badge: module,
        actionsHtml: '<button type="button" class="btn btn-outline" data-action="toggle_theme">Toggle Theme</button>',
        backHref: "../index.html",
      });

      try {
        host.innerHTML = pageDefinition.render({
          module: module,
          page: page,
          state: state,
          flow: flow,
          data: window.GonepData || {},
        });
      } catch (error) {
        return fail("GONEP-E-RENDER-001", module + "/" + page + " :: " + String(error && error.message ? error.message : error));
      }

      applySectionVisibility(host, flow.currentSection);
      window.GonepNavigation.highlightActiveLinks(".sidebar-links a");
    } catch (error) {
      fail("GONEP-E-DEPS-001", String(error && error.message ? error.message : error));
    }
  }

  function handleAction(button) {
    if (!button || !currentContext) return;

    try {
      var action = button.getAttribute("data-action") || "update_flow";
      var targetModule = button.getAttribute("data-target-module") || currentContext.module;
      var flowPage = button.getAttribute("data-flow-page") || currentContext.page;
      var nextSection = button.getAttribute("data-next-section");
      var nextPage = button.getAttribute("data-next-page");
      var flowStatus = button.getAttribute("data-flow-status");
      var statePath = button.getAttribute("data-state-path");
      var stateValue = button.getAttribute("data-state-value");
      var toastText = button.getAttribute("data-toast");

      if (action === "toggle_theme") {
        window.GonepState.toggleTheme();
        window.GonepToast.showToast("info", "Theme updated.");
        renderModulePage();
        return;
      }

      if (action === "switch_section") {
        window.GonepState.updateFlow(targetModule, flowPage, { currentSection: nextSection || "overview" });
        renderModulePage();
        return;
      }

      if (statePath) {
        window.GonepState.setStateByPath(statePath, parseValue(stateValue));
      }

      if (flowStatus || nextSection) {
        var currentFlow = window.GonepState.getFlow(targetModule, flowPage);
        window.GonepState.updateFlow(targetModule, flowPage, {
          status: flowStatus || currentFlow.status,
          currentSection: nextSection || currentFlow.currentSection,
        });
      }

      actionToast(toastText || "Action completed.");

      if (nextPage) {
        window.location.href = nextPage;
        return;
      }

      renderModulePage();
    } catch (error) {
      fail("GONEP-E-ACTION-001", String(error && error.message ? error.message : error));
    }
  }

  function bindActions() {
    if (actionsBound) return;
    actionsBound = true;
    document.addEventListener("click", function (event) {
      var button = event.target.closest("[data-action]");
      if (!button) return;
      event.preventDefault();
      handleAction(button);
    });
  }

  function initModulePage(options) {
    try {
      currentContext = {
        module: options.module,
        page: options.page,
        title: options.title || "",
      };
      bindActions();
      renderModulePage();
    } catch (error) {
      fail("GONEP-E-INIT-001", String(error && error.message ? error.message : error));
    }
  }

  window.GonepPageRuntime = {
    initModulePage: initModulePage,
    renderModulePage: renderModulePage,
  };
})();
