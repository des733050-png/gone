(function () {
  "use strict";

  function getToastRoot() {
    var root = document.getElementById("toast-root");
    if (!root) {
      root = document.createElement("div");
      root.id = "toast-root";
      root.className = "toast-root";
      root.setAttribute("aria-live", "polite");
      root.setAttribute("aria-atomic", "true");
      document.body.appendChild(root);
    }
    return root;
  }

  function showToast(type, message) {
    var safeType = ["success", "info", "warn", "error"].includes(type) ? type : "info";
    var toast = document.createElement("div");
    toast.className = "toast toast-" + safeType;
    toast.setAttribute("role", "status");
    toast.innerHTML =
      '<div class="stack-sm">' +
      '<strong style="text-transform:capitalize;">' +
      safeType +
      "</strong>" +
      "<p>" +
      String(message || "") +
      "</p>" +
      "</div>" +
      '<button class="btn btn-ghost" aria-label="Dismiss notification" type="button">Dismiss</button>';

    var root = getToastRoot();
    root.appendChild(toast);

    function dismiss() {
      if (toast.parentNode) toast.remove();
    }

    var timer = setTimeout(dismiss, 3000);
    toast.querySelector("button").addEventListener("click", function () {
      clearTimeout(timer);
      dismiss();
    });
  }

  window.GonepToast = {
    showToast: showToast,
  };
})();
