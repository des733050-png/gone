(function () {
  "use strict";

  var STATE_KEY = "gonep_state";
  var THEME_KEY = "gonep_theme";
  var memoryStore = {};

  var modulePages = {
    patient: ["dashboard", "bookings", "consultations", "prescriptions", "diagnostics", "records", "profile", "support"],
    provider: ["dashboard", "consultations", "appointments", "prescriptions", "earnings", "profile", "protocols"],
    rider: ["dashboard", "jobs", "history", "earnings"],
    dashboard: [
      "dashboard",
      "bookings",
      "providers",
      "riders",
      "incidents",
      "performance",
      "audits",
      "complaints",
      "flags",
      "stock",
      "inventory",
      "sales",
      "suppliers",
      "revenue",
      "payouts",
      "invoices",
      "transactions",
      "executive",
    ],
  };

  function storageAvailable() {
    try {
      var probe = "__gonep_probe__";
      localStorage.setItem(probe, "1");
      localStorage.removeItem(probe);
      return true;
    } catch (error) {
      return false;
    }
  }

  function readItem(key) {
    if (storageAvailable()) {
      try {
        return localStorage.getItem(key);
      } catch (error) {
        return memoryStore[key] || null;
      }
    }
    return memoryStore[key] || null;
  }

  function writeItem(key, value) {
    memoryStore[key] = value;
    if (storageAvailable()) {
      try {
        localStorage.setItem(key, value);
      } catch (error) {
        // fallback stays in memory
      }
    }
  }

  function deleteItem(key) {
    delete memoryStore[key];
    if (storageAvailable()) {
      try {
        localStorage.removeItem(key);
      } catch (error) {
        // ignore
      }
    }
  }

  function defaultFlows(pages) {
    var result = {};
    pages.forEach(function (page) {
      result[page] = {
        status: "idle",
        currentSection: "overview",
        updatedAt: null,
      };
    });
    return result;
  }

  var defaultState = {
    schemaVersion: 2,
    currentRole: null,
    patient: {
      name: "Amina Yusuf",
      phone: "07XXXXXXXX",
      language: "EN",
      locationInCoverage: true,
      activeBookingId: "BK-UT-001",
      flows: defaultFlows(modulePages.patient),
    },
    provider: {
      name: "Dr. Njoroge",
      online: true,
      fee: 2000,
      activeBookingId: "BK-UT-001",
      flows: defaultFlows(modulePages.provider),
    },
    rider: {
      name: "Brian (Rider)",
      online: true,
      activeJobId: "JOB-001",
      flows: defaultFlows(modulePages.rider),
    },
    dashboard: {
      role: "ops",
      flows: defaultFlows(modulePages.dashboard),
    },
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function isObject(value) {
    return value && typeof value === "object" && !Array.isArray(value);
  }

  function mergeDeep(base, incoming) {
    var output = clone(base);
    Object.keys(incoming || {}).forEach(function (key) {
      var fromIncoming = incoming[key];
      if (isObject(fromIncoming) && isObject(output[key])) {
        output[key] = mergeDeep(output[key], fromIncoming);
      } else {
        output[key] = fromIncoming;
      }
    });
    return output;
  }

  function getParsed(key) {
    try {
      var raw = readItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      return null;
    }
  }

  function ensureModuleFlows(state) {
    Object.keys(modulePages).forEach(function (module) {
      var holder = state[module] || (state[module] = {});
      var flowDefaults = defaultFlows(modulePages[module]);
      holder.flows = mergeDeep(flowDefaults, holder.flows || {});
    });
  }

  function migrateState(state) {
    var next = mergeDeep(defaultState, state || {});
    var legacyBookingId = readItem("gonep_active_booking_id");
    if (legacyBookingId && !next.patient.activeBookingId) next.patient.activeBookingId = legacyBookingId;
    next.schemaVersion = 2;
    ensureModuleFlows(next);
    return next;
  }

  function persist(state) {
    writeItem(STATE_KEY, JSON.stringify(state));
    return state;
  }

  function getState() {
    var stored = getParsed(STATE_KEY);
    return migrateState(stored);
  }

  function setState(partial) {
    return persist(mergeDeep(getState(), partial || {}));
  }

  function setStateByPath(path, value) {
    if (!path) return getState();
    var next = getState();
    var parts = String(path).split(".").filter(Boolean);
    var ref = next;
    for (var i = 0; i < parts.length - 1; i += 1) {
      var key = parts[i];
      if (!isObject(ref[key])) ref[key] = {};
      ref = ref[key];
    }
    ref[parts[parts.length - 1]] = value;
    return persist(next);
  }

  function getStateByPath(path, fallback) {
    if (!path) return fallback;
    var state = getState();
    var parts = String(path).split(".").filter(Boolean);
    var ref = state;
    for (var i = 0; i < parts.length; i += 1) {
      if (!isObject(ref) && i < parts.length - 1) return fallback;
      ref = ref[parts[i]];
      if (ref == null) return fallback;
    }
    return ref;
  }

  function getFlow(module, page) {
    var state = getState();
    if (!state[module] || !state[module].flows) return { status: "idle", currentSection: "overview", updatedAt: null };
    return state[module].flows[page] || { status: "idle", currentSection: "overview", updatedAt: null };
  }

  function updateFlow(module, page, patch) {
    if (!module || !page) return getState();
    var state = getState();
    if (!state[module]) state[module] = {};
    if (!state[module].flows) state[module].flows = {};
    var current = state[module].flows[page] || { status: "idle", currentSection: "overview", updatedAt: null };
    state[module].flows[page] = Object.assign({}, current, patch || {}, { updatedAt: new Date().toISOString() });
    return persist(state);
  }

  function setCurrentRole(role) {
    return setState({ currentRole: role || null });
  }

  function resetState() {
    return persist(clone(defaultState));
  }

  function ensureState() {
    var hasState = !!readItem(STATE_KEY);
    if (!hasState) {
      resetState();
      return;
    }
    persist(migrateState(getParsed(STATE_KEY)));
  }

  function getTheme() {
    var theme = readItem(THEME_KEY);
    return theme === "dark" ? "dark" : "light";
  }

  function setTheme(theme) {
    var normalized = theme === "dark" ? "dark" : "light";
    writeItem(THEME_KEY, normalized);
    document.documentElement.setAttribute("data-theme", normalized);
    return normalized;
  }

  function applyStoredTheme() {
    setTheme(getTheme());
  }

  function toggleTheme() {
    return setTheme(getTheme() === "dark" ? "light" : "dark");
  }

  function resetTheme() {
    deleteItem(THEME_KEY);
    setTheme("light");
  }

  function resetAll() {
    deleteItem(STATE_KEY);
    deleteItem(THEME_KEY);
    resetState();
    setTheme("light");
  }

  window.GonepState = {
    STATE_KEY: STATE_KEY,
    THEME_KEY: THEME_KEY,
    defaultState: clone(defaultState),
    modulePages: clone(modulePages),
    getState: getState,
    setState: setState,
    setStateByPath: setStateByPath,
    getStateByPath: getStateByPath,
    getFlow: getFlow,
    updateFlow: updateFlow,
    setCurrentRole: setCurrentRole,
    resetState: resetState,
    ensureState: ensureState,
    getTheme: getTheme,
    setTheme: setTheme,
    applyStoredTheme: applyStoredTheme,
    toggleTheme: toggleTheme,
    resetTheme: resetTheme,
    resetAll: resetAll,
  };
})();
