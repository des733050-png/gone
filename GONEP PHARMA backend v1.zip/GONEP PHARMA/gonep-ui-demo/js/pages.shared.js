(function () {
  "use strict";

  function esc(value) {
    return String(value == null ? "" : value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  function formatCurrency(value) {
    var amount = Number(value || 0);
    return "KES " + amount.toLocaleString();
  }

  function toTitleCase(value) {
    return String(value || "")
      .replaceAll("_", " ")
      .replace(/\b\w/g, function (m) {
        return m.toUpperCase();
      });
  }

  function statusBadge(value) {
    var key = String(value || "idle").toLowerCase();
    var variant = "default";
    if (key === "completed" || key === "paid" || key === "online" || key === "available" || key === "active") variant = "success";
    if (key === "pending" || key === "in_progress" || key === "en_route" || key === "in_review") variant = "info";
    if (key === "confirmed" || key === "awaiting_provider" || key === "warning" || key === "low" || key === "open") variant = "warning";
    if (key === "cancelled" || key === "rejected" || key === "failed" || key === "out" || key === "danger") variant = "danger";
    return '<span class="badge badge-' + variant + '">' + esc(toTitleCase(key)) + "</span>";
  }

  function card(title, body, extraClass) {
    return (
      '<section class="card stack-sm ' +
      esc(extraClass || "") +
      '">' +
      (title ? "<h3>" + esc(title) + "</h3>" : "") +
      body +
      "</section>"
    );
  }

  function renderActions(actions) {
    return (
      '<div class="row wrap">' +
      actions
        .map(function (action) {
          if (action.href) {
            return (
              '<a class="btn ' +
              esc(action.className || "btn-primary") +
              '" href="' +
              esc(action.href) +
              '">' +
              esc(action.label) +
              "</a>"
            );
          }

          var attrs = [
            'type="button"',
            'class="btn ' + esc(action.className || "btn-primary") + '"',
            'data-action="' + esc(action.action || "update_flow") + '"',
          ];

          if (action.targetModule) attrs.push('data-target-module="' + esc(action.targetModule) + '"');
          if (action.flowPage) attrs.push('data-flow-page="' + esc(action.flowPage) + '"');
          if (action.flowStatus) attrs.push('data-flow-status="' + esc(action.flowStatus) + '"');
          if (action.nextSection) attrs.push('data-next-section="' + esc(action.nextSection) + '"');
          if (action.nextPage) attrs.push('data-next-page="' + esc(action.nextPage) + '"');
          if (action.statePath) attrs.push('data-state-path="' + esc(action.statePath) + '"');
          if (typeof action.stateValue !== "undefined") attrs.push('data-state-value="' + esc(String(action.stateValue)) + '"');
          if (action.toast) attrs.push('data-toast="' + esc(action.toast) + '"');
          return "<button " + attrs.join(" ") + ">" + esc(action.label) + "</button>";
        })
        .join("") +
      "</div>"
    );
  }

  function renderKeyRows(rows) {
    return (
      '<div class="key-list">' +
      rows
        .map(function (row) {
          return (
            '<div class="key-row">' +
            "<span>" +
            esc(row.label) +
            "</span>" +
            "<strong>" +
            (row.value == null ? "-" : row.value) +
            "</strong>" +
            "</div>"
          );
        })
        .join("") +
      "</div>"
    );
  }

  function renderFlowPanel(ctx, sections) {
    var current = ctx.flow.currentSection || sections[0].id;
    var tabs =
      '<div class="tabs">' +
      sections
        .map(function (section) {
          return (
            '<button type="button" class="tab-btn' +
            (section.id === current ? " active" : "") +
            '" data-action="switch_section" data-flow-page="' +
            esc(ctx.pageKey) +
            '" data-next-section="' +
            esc(section.id) +
            '">' +
            esc(section.label) +
            "</button>"
          );
        })
        .join("") +
      "</div>";

    var content =
      '<div class="flow-sections">' +
      sections
        .map(function (section) {
          return (
            '<div class="flow-section stack-sm" data-section-id="' +
            esc(section.id) +
            '"' +
            (section.id === current ? "" : " hidden") +
            ">" +
            section.body +
            "</div>"
          );
        })
        .join("") +
      "</div>";

    return card(
      "Workflow",
      '<div class="row between center"><p class="muted">Status</p>' + statusBadge(ctx.flow.status) + "</div>" + tabs + content
    );
  }

  function renderTimeline(items) {
    return (
      '<div class="timeline">' +
      items
        .map(function (item) {
          return (
            '<article class="timeline-item stack-sm">' +
            "<strong>" +
            esc(item.title) +
            "</strong>" +
            '<p class="muted">' +
            esc(item.meta || "") +
            "</p>" +
            (item.description ? "<p>" + esc(item.description) + "</p>" : "") +
            "</article>"
          );
        })
        .join("") +
      "</div>"
    );
  }

  function table(cols, rows) {
    return window.GonepUI.renderTable(cols, rows);
  }

  function sampleBooking(data, index) {
    var bookings = (data && data.bookings) || [];
    return bookings[index || 0] || null;
  }

  window.GonepPageShared = {
    esc: esc,
    formatCurrency: formatCurrency,
    toTitleCase: toTitleCase,
    statusBadge: statusBadge,
    card: card,
    renderActions: renderActions,
    renderKeyRows: renderKeyRows,
    renderFlowPanel: renderFlowPanel,
    renderTimeline: renderTimeline,
    table: table,
    sampleBooking: sampleBooking,
  };
})();
