﻿(function(){
  "use strict";
  function summaryCards(items){return '<section class="kpi-grid">'+items.map(function(i){return '<article class="card"><p class="muted">'+i.label+'</p><h3>'+i.value+'</h3></article>';}).join('')+'</section>';}
  function infoRows(rows){return '<div class="stack-sm">'+rows.map(function(r){return '<div class="row between"><span class="muted">'+r.label+'</span><strong>'+r.value+'</strong></div>';}).join('')+'</div>';}
  function statusSteps(steps,current){return '<div class="tabs">'+steps.map(function(s,i){return '<span class="tab-btn'+(i<=current?' active':'')+'">'+s+'</span>';}).join('')+'</div>';}
  function section(title,body){return '<section class="card stack-sm"><h3>'+title+'</h3>'+body+'</section>';}
  window.GonepModuleHelpers={summaryCards:summaryCards,infoRows:infoRows,statusSteps:statusSteps,section:section};
})();
