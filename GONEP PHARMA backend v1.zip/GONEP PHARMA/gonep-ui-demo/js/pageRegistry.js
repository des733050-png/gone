(function () {
  "use strict";

  var pageMaps = {
    patient: window.GonepPatientPages || {},
    provider: window.GonepProviderPages || {},
    rider: window.GonepRiderPages || {},
    dashboard: window.GonepDashboardPages || {},
  };

  function getPage(module, page) {
    if (!pageMaps[module]) return null;
    return pageMaps[module][page] || null;
  }

  window.GonepPageRegistry = {
    getPage: getPage,
    pageMaps: pageMaps,
  };
})();
