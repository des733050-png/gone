# Pages and Navigation Map

## Main and Core
1. `/index.html`
2. `/core/index.html`
3. `/core/auth.html`
4. `/core/overview.html`

## Patient Pages
1. `/patient/dashboard.html`
2. `/patient/bookings.html`
3. `/patient/consultations.html`
4. `/patient/prescriptions.html`
5. `/patient/diagnostics.html`
6. `/patient/records.html`
7. `/patient/profile.html`
8. `/patient/support.html`

## Provider Pages
1. `/provider/dashboard.html`
2. `/provider/consultations.html`
3. `/provider/appointments.html`
4. `/provider/prescriptions.html`
5. `/provider/earnings.html`
6. `/provider/profile.html`
7. `/provider/protocols.html`

## Rider Pages
1. `/rider/dashboard.html`
2. `/rider/jobs.html`
3. `/rider/history.html`
4. `/rider/earnings.html`

## Command Dashboard Pages
1. `/dashboard/dashboard.html`
2. `/dashboard/bookings.html`
3. `/dashboard/providers.html`
4. `/dashboard/riders.html`
5. `/dashboard/incidents.html`
6. `/dashboard/performance.html`
7. `/dashboard/audits.html`
8. `/dashboard/complaints.html`
9. `/dashboard/flags.html`
10. `/dashboard/stock.html`
11. `/dashboard/inventory.html`
12. `/dashboard/sales.html`
13. `/dashboard/suppliers.html`
14. `/dashboard/revenue.html`
15. `/dashboard/payouts.html`
16. `/dashboard/invoices.html`
17. `/dashboard/transactions.html`
18. `/dashboard/executive.html`

## Flow Map
1. Main index -> core entry/auth -> selected module dashboard
2. Patient dashboard -> bookings -> consultations -> prescriptions or diagnostics -> records
3. Provider dashboard -> appointments -> consultations -> prescriptions -> earnings
4. Rider dashboard -> jobs -> history -> earnings
5. Command dashboard -> section pages through sidebar navigation
