# Flow Specs (Non-Blocking)

## Required Behavior
1. Every action button must either update local state, switch section, or route to the next page.
2. OTP, coverage, payment, uploads, and verification are informational only and never block progression.
3. Use hybrid next-step behavior:
   - update flow state in-page
   - move to next section
   - optionally route to next page where cross-page handoff is expected

## Action Contract
1. `data-action`
2. `data-target-module`
3. `data-flow-page`
4. `data-flow-status`
5. `data-next-section`
6. `data-next-page`
7. `data-state-path`
8. `data-state-value`
9. `data-toast`

## Flow Status Vocabulary
1. `idle`
2. `draft`
3. `confirmed`
4. `in_progress`
5. `completed`
6. `cancelled`
