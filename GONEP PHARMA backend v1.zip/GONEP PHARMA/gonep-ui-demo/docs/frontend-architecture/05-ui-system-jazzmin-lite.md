# UI System (Jazzmin-Lite)

## Layout Standard
1. Left sidebar for module navigation.
2. Topbar with page title, subtitle, module badge, and utility action.
3. Main content as cards, tables, tabs, key-value rows, and timelines.

## Design Rules
1. Simple internal-tool visual style.
2. Structured data-first cards.
3. Minimal text with action-heavy content.
4. Responsive behavior for desktop and mobile.

## Shared Assets
1. `css/base.css`
2. `css/theme.css`
3. `css/layout.css`
4. `css/components.css`
5. `css/modules.css`

## Shared Runtime
1. `js/pages.shared.js`
2. `js/pages.patient.js`
3. `js/pages.provider.js`
4. `js/pages.rider.js`
5. `js/pages.dashboard.js`
6. `js/pageRegistry.js`
7. `js/pageRuntime.js`
