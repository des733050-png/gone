# Codex Phase Prompt Pack

Use one prompt per phase with the structure below.

## Prompt Template
1. Scope: list exact files allowed for this phase.
2. Responsibilities source: `03-screen-responsibilities.md`.
3. Flow rules source: `04-flow-specs-nonblocking.md`.
4. State rules source: `06-state-schema-localstorage.md`.
5. Guardrails:
   - frontend only
   - no backend calls
   - non-blocking interactions
   - remove old demo wording in action content
6. Post-step requirement:
   - update `07-phase-checklist-gap-matrix.md`
   - run navigation and action sanity checks

## Example Prompt (Module Phase)
```text
Implement only the Patient module pages in /patient using the architecture docs in docs/frontend-architecture.
Respect the shared action contract and localStorage schema v2.
Do not introduce backend calls.
Ensure every primary action moves to the expected next section or page without blocking.
After implementation, update docs/frontend-architecture/07-phase-checklist-gap-matrix.md with gaps fixed and any remaining gaps.
```
