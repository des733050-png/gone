# Objective, Users, Modules

## Objective
Build a frontend-only healthcare platform shell that behaves like a real multi-role system without backend dependencies. Every module must support expected task progression with non-blocking interactions.

## Users
1. Patient
2. Provider
3. Rider
4. Command Dashboard user

## Top-Level Surfaces
1. Main Index (global launcher)
2. Patient module
3. Provider module
4. Rider module
5. Command Dashboard module

## Rules
1. No backend API calls.
2. No hard validation blockers.
3. All primary actions must progress status or route to the expected next step.
4. Sidebar and topbar structure is mandatory for module pages.
