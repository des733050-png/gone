# State Schema (LocalStorage)

## Storage Keys
1. `gonep_state`
2. `gonep_theme`

## State Version
`schemaVersion: 2`

## Core Shape
```json
{
  "schemaVersion": 2,
  "currentRole": "patient|provider|rider|dashboard|null",
  "patient": { "flows": {} },
  "provider": { "flows": {} },
  "rider": { "flows": {} },
  "dashboard": { "flows": {} }
}
```

## Flow Entry Shape
```json
{
  "status": "idle|draft|confirmed|in_progress|completed|cancelled",
  "currentSection": "string",
  "updatedAt": "ISO timestamp or null"
}
```

## Required Helpers
1. `getState()`
2. `setState(partial)`
3. `getFlow(module,page)`
4. `updateFlow(module,page,patch)`
5. `setStateByPath(path,value)`
6. `resetAll()`
