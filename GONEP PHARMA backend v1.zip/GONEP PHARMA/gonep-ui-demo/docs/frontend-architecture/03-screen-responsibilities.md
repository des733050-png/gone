# Screen Responsibilities

## Patient
1. Dashboard: greeting, quick actions, active booking card, latest care summaries.
2. Bookings: sections for new booking, confirmation, payment, active booking, delivery tracking.
3. Consultations: provider summary, SOAP snapshot, visit actions.
4. Prescriptions: medication list, dosage/instructions, delivery status, history.
5. Diagnostics: booking section, upload section, results view, uploaded files.
6. Records: timeline for consultations, prescriptions, diagnostics.
7. Profile: personal details, language/theme controls, emergency contact, exit links.
8. Support: FAQ and contact channels.

## Provider
1. Dashboard: request queue and earnings snapshot.
2. Consultations: patient summary, vitals, SOAP, next actions.
3. Appointments: incoming, upcoming, active, completed states.
4. Prescriptions: draft, sign-off, send flow.
5. Earnings: totals, payout summary, fee controls.
6. Profile: credentials and payout details.
7. Protocols: read-only SOP/training library.

## Rider
1. Dashboard: online/offline state, active job preview, quick links.
2. Jobs: available jobs, active job, delivery proof, sample collection.
3. History: completed/cancelled jobs and metrics.
4. Earnings: time-window totals and payout intent.

## Command Dashboard
1. Dashboard: KPI overview and quick links.
2. Bookings: queue and assignment status.
3. Providers: roster and availability.
4. Riders: dispatch and activity state.
5. Incidents: issue log and severity status.
6. Performance: provider metrics and flags.
7. Audits: audit queue and review status.
8. Complaints: SLA queue and resolution status.
9. Flags: risk/flag tracking.
10. Stock: quantity and reorder status.
11. Inventory: batch and expiry view.
12. Sales: sales logs.
13. Suppliers: supplier directory and contact view.
14. Revenue: transaction totals and status split.
15. Payouts: payout queue with approve/reject actions.
16. Invoices: generation and history placeholders.
17. Transactions: payment log and export action.
18. Executive: leadership KPI summary.
