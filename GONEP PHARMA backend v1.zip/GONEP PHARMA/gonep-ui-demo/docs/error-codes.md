# GONEP Frontend Error Codes

Use this file as the runtime troubleshooting reference.

## Codes
1. `GONEP-E-INIT-001`
   - Meaning: module runtime failed at startup.
   - Typical cause: `pageRuntime.js` not loaded or blocked.
   - First check: browser Network tab for missing JS files.

2. `GONEP-E-STATE-001`
   - Meaning: state provider failed to initialize.
   - Typical cause: corrupted or blocked storage access.
   - First check: click `Reset Demo Data` on Main Index.

3. `GONEP-E-PAGE-001`
   - Meaning: page definition for module/page not found.
   - Typical cause: registry mismatch or missing page file entry.
   - First check: verify mappings in `js/pageRegistry.js`.

4. `GONEP-E-RENDER-001`
   - Meaning: page renderer threw during content build.
   - Typical cause: runtime bug in `js/pages.*.js`.
   - First check: browser console stack trace and page renderer function.

5. `GONEP-E-ACTION-001`
   - Meaning: action handler failed.
   - Typical cause: invalid `data-*` contract on a button.
   - First check: inspect clicked element attributes.

6. `GONEP-E-DEPS-001`
   - Meaning: required global dependency missing.
   - Typical cause: script load order issue.
   - First check: verify script sequence in the HTML template.

## Logging
Runtime errors are recorded in `sessionStorage` under key `gonep_errors`.
