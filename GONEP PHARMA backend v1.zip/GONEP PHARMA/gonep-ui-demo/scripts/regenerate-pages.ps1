$ErrorActionPreference = "Stop"

function Write-ModulePage {
  param(
    [string]$Path,
    [string]$Title,
    [string]$Module,
    [string]$Page
  )

  $content = @"
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>$Title</title>
  <link rel="stylesheet" href="../css/base.css">
  <link rel="stylesheet" href="../css/theme.css">
  <link rel="stylesheet" href="../css/layout.css">
  <link rel="stylesheet" href="../css/components.css">
  <link rel="stylesheet" href="../css/modules.css">
</head>
<body>
  <div id="toast-root" class="toast-root"></div>
  <div class="app-shell">
    <div class="app-grid">
      <div id="sidebar"></div>
      <main class="app-main app-content">
        <header id="topbar"></header>
        <div id="page-content" class="stack"></div>
      </main>
    </div>
  </div>

  <script src="../js/appState.js" defer></script>
  <script src="../js/demoData.js" defer></script>
  <script src="../js/errorCodes.js" defer></script>
  <script src="../js/ui.js" defer></script>
  <script src="../js/toasts.js" defer></script>
  <script src="../js/navigation.js" defer></script>
  <script src="../js/pages.shared.js" defer></script>
  <script src="../js/pages.patient.js" defer></script>
  <script src="../js/pages.provider.js" defer></script>
  <script src="../js/pages.rider.js" defer></script>
  <script src="../js/pages.dashboard.js" defer></script>
  <script src="../js/pageRegistry.js" defer></script>
  <script src="../js/pageRuntime.js" defer></script>
  <script defer>
    document.addEventListener("DOMContentLoaded", function () {
      if (!window.GonepPageRuntime || typeof window.GonepPageRuntime.initModulePage !== "function") {
        if (window.GonepErrorCodes && typeof window.GonepErrorCodes.renderPageError === "function") {
          window.GonepErrorCodes.renderPageError("GONEP-E-INIT-001", "GonepPageRuntime missing at startup.");
        }
        return;
      }
      window.GonepPageRuntime.initModulePage({ module: "$Module", page: "$Page", title: "$Title" });
    });
  </script>
</body>
</html>
"@

  Set-Content -Path $Path -Value $content
}

$patient = @{
  "dashboard.html" = "Patient Dashboard"
  "bookings.html" = "Patient Bookings"
  "consultations.html" = "Patient Consultations"
  "prescriptions.html" = "Patient Prescriptions"
  "diagnostics.html" = "Patient Diagnostics"
  "records.html" = "Patient Records"
  "profile.html" = "Patient Profile"
  "support.html" = "Patient Support"
}

$provider = @{
  "dashboard.html" = "Provider Dashboard"
  "consultations.html" = "Provider Consultations"
  "appointments.html" = "Provider Appointments"
  "prescriptions.html" = "Provider Prescriptions"
  "earnings.html" = "Provider Earnings"
  "profile.html" = "Provider Profile"
  "protocols.html" = "Provider Protocols"
}

$rider = @{
  "dashboard.html" = "Rider Dashboard"
  "jobs.html" = "Rider Jobs"
  "history.html" = "Rider History"
  "earnings.html" = "Rider Earnings"
}

$dashboard = @{
  "dashboard.html" = "Command Dashboard Home"
  "bookings.html" = "Dashboard Bookings"
  "providers.html" = "Dashboard Providers"
  "riders.html" = "Dashboard Riders"
  "incidents.html" = "Dashboard Incidents"
  "performance.html" = "Dashboard Performance"
  "audits.html" = "Dashboard Audits"
  "complaints.html" = "Dashboard Complaints"
  "flags.html" = "Dashboard Flags"
  "stock.html" = "Dashboard Stock"
  "inventory.html" = "Dashboard Inventory"
  "sales.html" = "Dashboard Sales"
  "suppliers.html" = "Dashboard Suppliers"
  "revenue.html" = "Dashboard Revenue"
  "payouts.html" = "Dashboard Payouts"
  "invoices.html" = "Dashboard Invoices"
  "transactions.html" = "Dashboard Transactions"
  "executive.html" = "Dashboard Executive"
}

foreach ($k in $patient.Keys) { Write-ModulePage -Path (Join-Path "patient" $k) -Title $patient[$k] -Module "patient" -Page ([IO.Path]::GetFileNameWithoutExtension($k)) }
foreach ($k in $provider.Keys) { Write-ModulePage -Path (Join-Path "provider" $k) -Title $provider[$k] -Module "provider" -Page ([IO.Path]::GetFileNameWithoutExtension($k)) }
foreach ($k in $rider.Keys) { Write-ModulePage -Path (Join-Path "rider" $k) -Title $rider[$k] -Module "rider" -Page ([IO.Path]::GetFileNameWithoutExtension($k)) }
foreach ($k in $dashboard.Keys) { Write-ModulePage -Path (Join-Path "dashboard" $k) -Title $dashboard[$k] -Module "dashboard" -Page ([IO.Path]::GetFileNameWithoutExtension($k)) }

Write-Output "module-pages-written"
