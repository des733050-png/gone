# GONEP Healthcare - Frontend Revamp

Pure frontend (HTML/CSS/JS) platform with 4 module-isolated surfaces:
- Patient
- Provider
- Rider
- Command Dashboard

## Run
Open `index.html` directly or run Live Server at `gonep-ui-demo`.

## Architecture
- Main launcher: `/index.html`
- Core utility pages: `/core/index.html`, `/core/auth.html`, `/core/overview.html`
- Module pages:
  - `/patient/*`
  - `/provider/*`
  - `/rider/*`
  - `/dashboard/*`

## Shared CSS
- `css/base.css`
- `css/theme.css`
- `css/layout.css`
- `css/components.css`
- `css/modules.css`

## Shared JS
- `js/appState.js`
- `js/demoData.js`
- `js/ui.js`
- `js/navigation.js`
- `js/toasts.js`
- `js/pages.shared.js`
- `js/pages.patient.js`
- `js/pages.provider.js`
- `js/pages.rider.js`
- `js/pages.dashboard.js`
- `js/pageRegistry.js`
- `js/pageRuntime.js`

## Demo State
LocalStorage keys:
- `gonep_state`
- `gonep_theme`

## Non-blocking Demo Rules
- OTP/auth/payment/coverage are visual demo concepts only.
- No backend API calls.
- All flows are freely navigable.

## Documentation
Architecture docs used as implementation source of truth:
- `docs/frontend-architecture/01-objective-users-modules.md`
- `docs/frontend-architecture/02-pages-navigation-map.md`
- `docs/frontend-architecture/03-screen-responsibilities.md`
- `docs/frontend-architecture/04-flow-specs-nonblocking.md`
- `docs/frontend-architecture/05-ui-system-jazzmin-lite.md`
- `docs/frontend-architecture/06-state-schema-localstorage.md`
- `docs/frontend-architecture/07-phase-checklist-gap-matrix.md`
- `docs/frontend-architecture/08-codex-phase-prompts.md`
- `docs/error-codes.md`

## Django Migration Readiness
The structure is module-separated with reusable shared shell/helpers, making page-to-template migration straightforward.
